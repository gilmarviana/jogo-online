# Campo Minado Online - React + Vite

Este projeto é um jogo Campo Minado com suporte a modo solo e online, feito em React + Vite.

## Como rodar localmente

```bash
npm install
npm run dev
```

## Deploy no GitHub Pages

1. Instale o plugin de deploy:
   ```bash
   npm install --save-dev gh-pages
   ```
2. No arquivo `vite.config.js`, adicione:
   ```js
   export default defineConfig({
     // ...
     base: '/NOME_DO_REPOSITORIO/',
   });
   ```
   Troque `NOME_DO_REPOSITORIO` pelo nome do seu repositório no GitHub.
3. No `package.json`, adicione:
   ```json
   "homepage": "https://SEU_USUARIO.github.io/NOME_DO_REPOSITORIO",
   "scripts": {
     "predeploy": "npm run build",
     "deploy": "gh-pages -d dist"
   }
   ```
4. Faça o deploy:
   ```bash
   npm run deploy
   ```
5. Acesse: `https://SEU_USUARIO.github.io/NOME_DO_REPOSITORIO`

## Deploy automático com Vercel (recomendado)

1. Crie uma conta em https://vercel.com
2. Clique em "New Project" e conecte seu repositório do GitHub.
3. Siga as instruções. O deploy será feito automaticamente a cada push.

## Sobre o backend
O modo online depende do Supabase. Configure as variáveis de ambiente conforme necessário.

---

Se precisar de mais detalhes ou ajuda para configurar o deploy, abra uma issue ou peça suporte!
