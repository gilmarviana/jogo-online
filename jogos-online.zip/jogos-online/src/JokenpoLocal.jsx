import React, { useState, useEffect, useRef } from 'react';

const options = [
  { name: 'Pedra', emoji: '✊' },
  { name: 'Papel', emoji: '✋' },
  { name: 'Tesoura', emoji: '✌️' },
];

export default function JokenpoLocal() {
  const [player, setPlayer] = useState(null);
  const [computer, setComputer] = useState(null);
  const [result, setResult] = useState('');
  const [score, setScore] = useState({ player: 0, computer: 0, empate: 0 });
  const [startTime, setStartTime] = useState(Date.now());
  const [elapsed, setElapsed] = useState(0);
  const timerRef = useRef();

  useEffect(() => {
    setStartTime(Date.now());
    setElapsed(0);
    timerRef.current = setInterval(() => {
      setElapsed(Math.floor((Date.now() - startTime) / 1000));
    }, 1000);
    return () => clearInterval(timerRef.current);
  }, []);

  function play(p1, p2) {
    if (p1 === p2) return 'Empate!';
    if (
      (p1 === 0 && p2 === 2) ||
      (p1 === 1 && p2 === 0) ||
      (p1 === 2 && p2 === 1)
    ) return 'Você venceu!';
    return 'Computador venceu!';
  }

  function handlePlay(p1) {
    const p2 = Math.floor(Math.random() * 3);
    setPlayer(p1);
    setComputer(p2);
    const r = play(p1, p2);
    setResult(r);
    setScore(prev => {
      if (r === 'Você venceu!') return { ...prev, player: prev.player + 1 };
      if (r === 'Computador venceu!') return { ...prev, computer: prev.computer + 1 };
      return { ...prev, empate: prev.empate + 1 };
    });
  }

  function handleRestart() {
    setPlayer(null);
    setComputer(null);
    setResult('');
  }

  function handleResetAll() {
    setPlayer(null);
    setComputer(null);
    setResult('');
    setScore({ player: 0, computer: 0, empate: 0 });
    setStartTime(Date.now());
    setElapsed(0);
  }

  function formatTime(sec) {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m > 0 ? m + 'm ' : ''}${s}s`;
  }

  return (
    <div className={window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'ion-dark' : 'ion-light'}
      style={{ minHeight: '100vh', background: 'var(--color1)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', transition: 'background 0.3s' }}>
      <h2 style={{ color: 'var(--color5)', fontWeight: 800, fontSize: 32, marginBottom: 16 }}>Jokenpô (vs Computador)</h2>
      <div style={{ background: 'var(--color2)', borderRadius: 16, padding: 24, boxShadow: '0 2px 12px #0002', border: '2px solid var(--color4)', marginBottom: 24, minWidth: 260 }}>
        <div style={{ color: 'var(--color5)', fontWeight: 700, marginBottom: 8 }}>Tempo na sala: <span style={{ color: 'var(--color4)' }}>{formatTime(elapsed)}</span></div>
        <div style={{ color: 'var(--color5)', fontWeight: 700, marginBottom: 8 }}>Placar</div>
        <div style={{ display: 'flex', gap: 24, justifyContent: 'center', marginBottom: 12 }}>
          <span style={{ color: '#22c55e', fontWeight: 700 }}>Você: {score.player}</span>
          <span style={{ color: '#e11d48', fontWeight: 700 }}>Computador: {score.computer}</span>
          <span style={{ color: '#f59e42', fontWeight: 700 }}>Empate: {score.empate}</span>
        </div>
        <div style={{ color: 'var(--color5)', fontWeight: 700, marginBottom: 8 }}>Escolha sua jogada:</div>
        <div style={{ display: 'flex', gap: 16, justifyContent: 'center' }}>
          {options.map((opt, i) => (
            <button key={i} onClick={() => handlePlay(i)} disabled={player !== null}
              style={{ fontSize: 32, padding: 12, borderRadius: 8, border: '2px solid var(--color4)', background: 'var(--color3)', color: 'var(--color5)', cursor: player !== null ? 'not-allowed' : 'pointer', margin: 2, opacity: player !== null ? 0.6 : 1 }}>
              {opt.emoji}
            </button>
          ))}
        </div>
      </div>
      {player !== null && computer !== null && (
        <div style={{ color: 'var(--color5)', fontWeight: 700, fontSize: 22, marginBottom: 16 }}>
          Você: {options[player].emoji} &nbsp;|&nbsp; Computador: {options[computer].emoji}
          <div style={{ marginTop: 12, fontWeight: 800, fontSize: 24,
            color: result === 'Você venceu!' ? '#22c55e' : result === 'Computador venceu!' ? '#e11d48' : result === 'Empate!' ? '#f59e42' : 'var(--color5)'
          }}>{result}</div>
        </div>
      )}
      <div style={{ display: 'flex', gap: 12 }}>
        <button onClick={handleRestart}
          style={{ background: 'none', color: 'var(--color5)', border: '2px solid var(--color5)', borderRadius: 8, padding: '8px 28px', fontWeight: 700, fontSize: 16, marginTop: 8, cursor: 'pointer', opacity: 0.85, transition: 'background 0.15s, border 0.2s' }}>
          Reiniciar rodada
        </button>
        <button onClick={handleResetAll}
          style={{ background: 'none', color: 'var(--color5)', border: '2px solid var(--color5)', borderRadius: 8, padding: '8px 28px', fontWeight: 700, fontSize: 16, marginTop: 8, cursor: 'pointer', opacity: 0.85, transition: 'background 0.15s, border 0.2s' }}>
          Zerar placar
        </button>
      </div>
    </div>
  );
}
