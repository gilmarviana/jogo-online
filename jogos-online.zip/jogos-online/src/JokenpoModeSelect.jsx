import React from 'react';

export default function JokenpoModeSelect({ onSelectMode, onBack }) {
  // Detecta o tema Ionic
  const [theme, setTheme] = React.useState(() => {
    if (typeof window !== 'undefined') {
      return document.body.classList.contains('theme-white') ? 'white' : 'dark';
    }
    return 'dark';
  });
  React.useEffect(() => {
    const observer = new MutationObserver(() => {
      setTheme(document.body.classList.contains('theme-white') ? 'white' : 'dark');
    });
    observer.observe(document.body, { attributes: true, attributeFilter: ['class'] });
    return () => observer.disconnect();
  }, []);

  const palette = theme === 'dark'
    ? {
        color1: '#260d33',
        color2: '#003f69',
        color3: '#106b87',
        color4: '#157a8c',
        color5: '#b3aca4',
      }
    : {
        color1: '#eaf3fa',
        color2: '#fff',
        color3: '#106b87',
        color4: '#157a8c',
        color5: '#003f69',
      };

  return (
    <div
      className={theme === 'dark' ? 'ion-dark' : 'ion-light'}
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: palette.color1,
        padding: 0,
        margin: 0,
        transition: 'background 0.3s',
      }}
    >
      <div
        style={{
          background: palette.color2,
          borderRadius: 24,
          boxShadow: theme === 'dark' ? '0 8px 32px 0 #0008' : '0 8px 32px 0 #b3aca433',
          padding: '48px 32px 32px 32px',
          maxWidth: 420,
          width: '100%',
          textAlign: 'center',
          border: `2px solid ${palette.color4}`,
        }}
      >
        <h2 style={{ fontSize: 32, fontWeight: 700, color: palette.color5, marginBottom: 8, letterSpacing: 1 }}>Jokenpô</h2>
        <p style={{ color: palette.color5, fontSize: 18, marginBottom: 32 }}>Escolha o modo de jogo:</p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
          <button
            onClick={() => onSelectMode('jokenpo-local')}
            style={{
              display: 'flex', alignItems: 'center', gap: 16,
              background: palette.color3,
              color: palette.color5,
              border: `2px solid ${palette.color4}`,
              borderRadius: 12,
              fontSize: 22,
              fontWeight: 600,
              padding: '18px 32px',
              cursor: 'pointer',
              boxShadow: '0 2px 8px #0002',
              transition: 'transform 0.08s, border 0.2s',
            }}
            onMouseDown={e => e.currentTarget.style.transform = 'scale(0.97)'}
            onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
          >
            <span style={{ fontSize: 28, display: 'flex', alignItems: 'center' }}>👥</span>
            <span style={{ textAlign: 'left' }}>
              Local<br />
              <span style={{ fontSize: 15, fontWeight: 400, color: palette.color5 }}>Dois jogadores no mesmo dispositivo</span>
            </span>
          </button>
          <button
            onClick={() => onSelectMode('jokenpo-online')}
            style={{
              display: 'flex', alignItems: 'center', gap: 16,
              background: palette.color4,
              color: palette.color2,
              border: `2px solid ${palette.color5}`,
              borderRadius: 12,
              fontSize: 22,
              fontWeight: 600,
              padding: '18px 32px',
              cursor: 'pointer',
              boxShadow: '0 2px 8px #0002',
              transition: 'transform 0.08s, border 0.2s',
            }}
            onMouseDown={e => e.currentTarget.style.transform = 'scale(0.97)'}
            onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
          >
            <span style={{ fontSize: 28, display: 'flex', alignItems: 'center' }}>🌐</span>
            <span style={{ textAlign: 'left' }}>
              Online<br />
              <span style={{ fontSize: 15, fontWeight: 400, color: palette.color2 }}>Desafie um amigo online</span>
            </span>
          </button>
        </div>
        <div style={{ marginTop: 40 }}>
          <button
            onClick={onBack}
            style={{
              color: palette.color5,
              background: 'none',
              border: `2px solid ${palette.color5}`,
              padding: '8px 28px',
              borderRadius: 8,
              fontSize: 16,
              marginTop: 8,
              cursor: 'pointer',
              opacity: 0.85,
              transition: 'background 0.15s, border 0.2s',
            }}
            onMouseOver={e => e.currentTarget.style.background = theme === 'dark' ? '#b3aca41a' : '#003f6911'}
            onMouseOut={e => e.currentTarget.style.background = 'none'}
          >
            Voltar
          </button>
        </div>
      </div>
    </div>
  );
}
