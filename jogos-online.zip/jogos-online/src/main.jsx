import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'

// Aplica o tema salvo no localStorage já no carregamento
const theme = localStorage.getItem('theme') || 'dark';
document.body.classList.remove('theme-dark', 'theme-white');
document.body.classList.add(`theme-${theme}`);

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
