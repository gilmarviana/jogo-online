import React, { useState } from 'react';
import supabase from './supabaseClient';
import './Auth.css';

export default function Auth({ onAuth }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [mode, setMode] = useState('login'); // 'login' ou 'signup'

  async function handleSignIn(e) {
    e.preventDefault();
    setLoading(true);
    setError('');
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) setError(error.message);
    else onAuth(data.user);
  }

  async function handleSignUp(e) {
    e.preventDefault();
    setLoading(true);
    setError('');
    const { data, error } = await supabase.auth.signUp({ email, password });
    setLoading(false);
    if (error) setError(error.message);
    else onAuth(data.user);
  }

  async function handleGuest() {
    setLoading(true);
    setError('');
    const { data, error } = await supabase.auth.signInAnonymously();
    setLoading(false);
    if (error) setError(error.message);
    else onAuth(data.user);
  }

  return (
    <div className="auth-box">
      {mode === 'login' ? (
        <>
          <h2>Login</h2>
          <form onSubmit={handleSignIn}>
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
            />
            <input
              type="password"
              placeholder="Senha"
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
            />
            <button type="submit" disabled={loading}>Entrar</button>
          </form>
          <button type="button" onClick={() => setMode('signup')} disabled={loading} style={{ marginTop: 8 }}>
            Cadastrar
          </button>
          <div style={{ margin: '12px 0' }}>ou</div>
          <button onClick={handleGuest} disabled={loading}>Entrar como Visitante</button>
        </>
      ) : (
        <>
          <h2>Cadastro</h2>
          <form onSubmit={handleSignUp}>
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
            />
            <input
              type="password"
              placeholder="Senha"
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
            />
            <button type="submit" disabled={loading}>Cadastrar</button>
          </form>
          <button type="button" onClick={() => setMode('login')} disabled={loading} style={{ marginTop: 8 }}>
            Voltar para Login
          </button>
        </>
      )}
      {error && <div className="status lose" style={{ marginTop: 12 }}>{error}</div>}
    </div>
  );
}
