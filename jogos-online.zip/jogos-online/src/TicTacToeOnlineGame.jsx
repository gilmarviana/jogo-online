import { useEffect, useState, useRef } from 'react';
import supabase from './supabaseClient';

const PLAYER_COLORS = ['#646cff', '#e67e22'];
const DEFAULT_AVATARS = [
  'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f600.png',
  'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f60a.png',
];

function getPlayerIndex(room, userId) {
  if (room.player1 === userId) return 0;
  if (room.player2 === userId) return 1;
  return 0;
}

export default function TicTacToeOnlineGame({ user, roomId, onLeave }) {
  const [room, setRoom] = useState(null);
  const [gameState, setGameState] = useState(null);
  const [loading, setLoading] = useState(true);
  const [startCountdown, setStartCountdown] = useState(null);
  const countdownRef = useRef(null);
  const [showRematch, setShowRematch] = useState(false);
  // Histórico e placar
  const [history, setHistory] = useState([]);
  const [placar, setPlacar] = useState({ p1: 0, p2: 0, draw: 0 });

  // Busca estado da sala e do jogo
  useEffect(() => {
    fetchRoom();
    fetchGameState();
    const channel = supabase.channel('ttt-game-' + roomId)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tic_tac_toe_rooms', filter: `id=eq.${roomId}` }, payload => {
        if (payload.new) setRoom(payload.new);
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tic_tac_toe_game_states', filter: `room_id=eq.${roomId}` }, payload => {
        if (payload.new) setGameState(payload.new.state);
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [roomId]);

  async function fetchRoom() {
    setLoading(true);
    const { data, error } = await supabase.from('tic_tac_toe_rooms').select('*').eq('id', roomId).maybeSingle();
    if (!error) setRoom(data);
    setLoading(false);
  }

  async function fetchGameState() {
    const { data, error } = await supabase.from('tic_tac_toe_game_states').select('*').eq('room_id', roomId).maybeSingle();
    if (data && data.state) setGameState(data.state);
  }

  // Lógica de contagem regressiva e início da partida (apenas player1 pode iniciar)
  useEffect(() => {
    if (!room) return;
    const slots = ['player1', 'player2'];
    const playerIdsArr = slots.map(slot => room[slot]);
    const readyArr = slots.map(slot => room[slot + '_ready']);
    const playersCount = playerIdsArr.filter(Boolean).length;
    const readyCount = readyArr.filter(Boolean).length;
    const canStart = playersCount === 2 && readyCount === 2;
    if (playersCount === 2 && canStart && !gameState) {
      if (startCountdown === null && !countdownRef.current) {
        setStartCountdown(5);
        let countdown = 5;
        countdownRef.current = setInterval(async () => {
          countdown--;
          setStartCountdown(countdown);
          if (countdown === 0) {
            clearInterval(countdownRef.current);
            countdownRef.current = null;
            setStartCountdown(null);
            // Após a contagem, player1 inicia o jogo
            if (room && user && room.player1 === user.id && !gameState) {
              const playerNamesArr = slots.map((slot, i) => room[slot + '_name'] || `Jogador ${i+1}`);
              const playerAvatarsArr = DEFAULT_AVATARS;
              const initialState = {
                board: Array(3).fill(null).map(() => Array(3).fill(null)),
                current: 'X',
                winner: null,
                playerNames: playerNamesArr,
                playerAvatars: playerAvatarsArr,
                currentPlayer: 0,
                turns: 0,
                isGameFinished: false,
              };
              await supabase.from('tic_tac_toe_game_states').upsert({ room_id: roomId, state: initialState });
            }
          }
        }, 1000);
      }
    } else {
      setStartCountdown(null);
      if (countdownRef.current) {
        clearInterval(countdownRef.current);
        countdownRef.current = null;
      }
    }
    return () => {
      if (countdownRef.current) {
        clearInterval(countdownRef.current);
        countdownRef.current = null;
      }
    };
  }, [room, user, roomId, gameState]);

  async function handlePlayerReady() {
    if (!room || !user) return;
    const playerIndex = getPlayerIndex(room, user.id);
    const isReady = room[`player${playerIndex + 1}_ready`];
    await supabase.from('tic_tac_toe_rooms').update({ [`player${playerIndex + 1}_ready`]: !isReady }).eq('id', roomId);
  }

  // Jogada online
  async function handleCellClick(i, j) {
    if (!gameState || gameState.board[i][j] || gameState.winner || gameState.isGameFinished) return;
    const myIndex = getPlayerIndex(room, user?.id);
    if (gameState.currentPlayer !== myIndex) return;
    const newBoard = gameState.board.map(row => [...row]);
    newBoard[i][j] = gameState.current;
    let winner = checkWinner(newBoard);
    let isGameFinished = false;
    if (winner) isGameFinished = true;
    else if (isFull(newBoard)) { winner = 'Empate'; isGameFinished = true; }
    const nextPlayer = (gameState.currentPlayer + 1) % 2;

    // Salva resultado no histórico ao terminar a partida
    if (isGameFinished) {
      let winner_id = null, winner_symbol = null, winner_score = 0;
      if (winner === 'Empate') {
        winner_id = null;
        winner_symbol = 'draw';
        winner_score = 0;
      } else if (winner === 'X') {
        winner_id = room.player1;
        winner_symbol = 'X';
        winner_score = 1;
      } else if (winner === 'O') {
        winner_id = room.player2;
        winner_symbol = 'O';
        winner_score = 1;
      }
      // Sempre adiciona um novo registro ao histórico ao final da partida
      const { error: insertError } = await supabase.from('tic_tac_toe_rooms_history').insert({
        room_id: roomId,
        player1_id: room.player1,
        player2_id: room.player2,
        winner: winner_id,
        winner_symbol,
        winner_score
      });
      if (insertError) {
        console.error('Erro ao inserir histórico:', insertError);
        alert('Erro ao salvar o placar: ' + insertError.message);
      }
    }

    await supabase.from('tic_tac_toe_game_states').update({
      state: {
        ...gameState,
        board: newBoard,
        current: gameState.current === 'X' ? 'O' : 'X',
        winner,
        isGameFinished,
        currentPlayer: nextPlayer,
        turns: gameState.turns + 1,
      }
    }).eq('room_id', roomId);
    if (isGameFinished) setShowRematch(true);
  }

  function checkWinner(board) {
    for (let i = 0; i < 3; i++) {
      if (board[i][0] && board[i][0] === board[i][1] && board[i][1] === board[i][2]) return board[i][0];
      if (board[0][i] && board[0][i] === board[1][i] && board[1][i] === board[2][i]) return board[0][i];
    }
    if (board[0][0] && board[0][0] === board[1][1] && board[1][1] === board[2][2]) return board[0][0];
    if (board[0][2] && board[0][2] === board[1][1] && board[1][1] === board[2][0]) return board[0][2];
    return null;
  }
  function isFull(board) {
    return board.every(row => row.every(cell => cell));
  }

  // Atualiza histórico e placar sempre que houver mudança no roomId ou no gameState (fim de partida)
  useEffect(() => {
    async function fetchHistoryAndScore() {
      const { data: hist, error } = await supabase
        .from('tic_tac_toe_rooms_history')
        .select('*')
        .eq('room_id', roomId)
        .order('id', { ascending: true });
      if (!error && hist) {
        setHistory(hist);
        // Calcula placar acumulado
        let p1 = 0, p2 = 0, draw = 0;
        hist.forEach(h => {
          if (h.winner_symbol === 'X') p1 += 1;
          else if (h.winner_symbol === 'O') p2 += 1;
          else if (h.winner_symbol === 'draw') draw += 1;
        });
        setPlacar({ p1, p2, draw });
      }
    }
    fetchHistoryAndScore();
  }, [roomId, gameState]);

  // Lobby
  if (!room || !gameState || startCountdown !== null) {
    const slots = ['player1', 'player2'];
    const playerNamesArr = slots.map((slot, i) => room && room[slot + '_name'] ? room[slot + '_name'] : (room && room[slot] ? `Jogador ${i+1}` : 'Vazio'));
    const playerIdsArr = slots.map(slot => room && room[slot]);
    const readyArr = slots.map(slot => room && room[slot + '_ready']);
    const isOwner = room && user && room.player1 === user.id;
    const mySlotIdx = playerIdsArr.findIndex(id => id === user?.id);
    const isReady = mySlotIdx !== -1 ? readyArr[mySlotIdx] : false;
    const playersCount = playerIdsArr.filter(Boolean).length;
    const readyCount = readyArr.filter(Boolean).length;
    let info = '';
    if (playersCount < 2) {
      info = 'Aguardando 2 jogadores na sala...';
    } else if (readyCount < 2) {
      info = 'Aguardando ambos ficarem prontos...';
    } else if (startCountdown !== null) {
      info = `Partida começando em ${startCountdown} segundo${startCountdown > 1 ? 's' : ''}...`;
    } else {
      info = 'Todos prontos! Aguarde o início da partida.';
    }
    async function toggleReady() {
      if (!room || mySlotIdx === -1) return;
      const field = slots[mySlotIdx] + '_ready';
      await supabase.from('tic_tac_toe_rooms').update({ [field]: !isReady }).eq('id', roomId);
    }
    async function forceStartGame() {
      if (room && user && room.player1 === user.id && room.status !== 'playing') {
        // Cria o estado inicial do jogo imediatamente
        const slots = ['player1', 'player2'];
        const playerNamesArr = slots.map((slot, i) => room[slot + '_name'] || `Jogador ${i+1}`);
        const playerAvatarsArr = DEFAULT_AVATARS;
        const initialState = {
          board: Array(3).fill(null).map(() => Array(3).fill(null)),
          current: 'X',
          winner: null,
          playerNames: playerNamesArr,
          playerAvatars: playerAvatarsArr,
          currentPlayer: 0,
          turns: 0,
          isGameFinished: false,
        };
        await supabase.from('tic_tac_toe_game_states').upsert({ room_id: roomId, state: initialState });
        await supabase.from('tic_tac_toe_rooms').update({ status: 'playing' }).eq('id', roomId);
      }
    }
    return (
      <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg, #23283a 60%, #7dd3fc 100%)' }}>
        <div style={{ background: 'rgba(35,40,58,0.98)', borderRadius: 18, padding: '36px 32px 28px', margin: '0 auto', maxWidth: 440, boxShadow: '0 4px 32px #000a', width: '100%' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18, justifyContent: 'center' }}>
            <img src="https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/274c.png" alt="TicTacToe" style={{ width: 38, height: 38 }} />
            <h2 style={{ color: '#e3e6ed', margin: 0, fontWeight: 800, fontSize: 28, letterSpacing: 1 }}>Jogo da Velha Online</h2>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16, marginBottom: 18 }}>
            {slots.map((slot, i) => (
              <div key={slot} style={{
                display: 'flex', alignItems: 'center', gap: 16, background: playerIdsArr[i] ? '#23283a' : '#23283a44',
                borderRadius: 10, padding: '10px 18px', boxShadow: playerIdsArr[i] ? `0 2px 8px ${PLAYER_COLORS[i]}22` : 'none',
                border: playerIdsArr[i] ? `2px solid ${PLAYER_COLORS[i]}55` : '2px dashed #444',
                minHeight: 54, position: 'relative',
                transition: 'box-shadow 0.2s, border 0.2s',
              }}>
                <img
                  src={playerIdsArr[i] ? DEFAULT_AVATARS[i] : 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/2753.png'}
                  alt={playerNamesArr[i]}
                  style={{ width: 36, height: 36, borderRadius: '50%', border: playerIdsArr[i] ? `2px solid ${PLAYER_COLORS[i]}` : '2px solid #444', background: '#fff', marginRight: 8 }}
                />
                <span style={{ fontWeight: 700, color: playerIdsArr[i] ? PLAYER_COLORS[i] : '#888', fontSize: 17, minWidth: 90 }}>{playerNamesArr[i]}</span>
                {playerIdsArr[i] ? (
                  <span style={{ fontSize: 17, fontWeight: 600, color: readyArr[i] ? '#22c55e' : '#f7c873', marginLeft: 6 }}>
                    {readyArr[i] ? '✅ Pronto' : '⏳ Aguardando'}
                  </span>
                ) : (
                  <span style={{ color: '#888', fontSize: 15, marginLeft: 6 }}>Vazio</span>
                )}
                {playerIdsArr[i] === user?.id && (
                  <button
                    onClick={toggleReady}
                    style={{
                      marginLeft: 'auto',
                      background: isReady ? 'linear-gradient(90deg,#7dd3fc 60%,#22c55e 100%)' : 'linear-gradient(90deg,#7dd3fc 60%,#2d8cff 100%)',
                      color: isReady ? '#23283a' : '#fff',
                      border: 'none', borderRadius: 7, padding: '7px 22px', fontSize: '1rem', fontWeight: 700, cursor: 'pointer', boxShadow: isReady ? '0 2px 8px #22c55e44' : '0 2px 8px #7dd3fc44', transition: 'background 0.2s, color 0.2s',
                    }}
                  >
                    {isReady ? 'Cancelar' : 'Estou pronto!'}
                  </button>
                )}
              </div>
            ))}
          </div>
          <div style={{ margin: '18px 0 10px', color: '#f7c873', fontWeight: 700, fontSize: 18, textAlign: 'center', letterSpacing: 0.2 }}>{info}</div>
          {/* Exibe o status da sala */}
          {room && (
            <div style={{ marginBottom: 10, color: '#7dd3fc', fontWeight: 600, fontSize: 16, textAlign: 'center' }}>
              Status da sala: <span style={{ color: '#f7c873' }}>{room.status}</span>
            </div>
          )}
          {isOwner && (
            <button
              onClick={forceStartGame}
              style={{ background: 'linear-gradient(90deg,#7dd3fc 60%,#f7c873 100%)', color: '#23283a', border: 'none', borderRadius: 8, padding: '12px 28px', fontWeight: 800, fontSize: '1.08rem', cursor: 'pointer', margin: '0 auto 10px', display: 'block', boxShadow: '0 2px 8px #7dd3fc44', letterSpacing: 0.5 }}
            >
              Forçar início
            </button>
          )}
          <button onClick={onLeave} style={{ marginTop: 8, background: 'none', color: '#e3e6ed', border: '1.5px solid #7dd3fc', borderRadius: 8, padding: '8px 22px', fontWeight: 600, fontSize: '1rem', cursor: 'pointer', width: '100%', marginBottom: 2 }}>Sair da sala</button>
        </div>
      </div>
    );
  }

  // Jogo online
  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #23283a 60%, #7dd3fc 100%)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ background: 'rgba(35,40,58,0.98)', borderRadius: 18, padding: '36px 32px 28px', maxWidth: 440, width: '100%', boxShadow: '0 4px 32px #000a', position: 'relative' }}>
        {/* Placar */}
        <div style={{ display: 'flex', justifyContent: 'center', gap: 18, marginBottom: 12 }}>
          <div style={{ color: PLAYER_COLORS[0], fontWeight: 700, fontSize: 18 }}>{room?.player1_name || 'Jogador 1'}: {placar.p1}</div>
          <div style={{ color: '#f7c873', fontWeight: 700, fontSize: 18 }}>Empates: {placar.draw}</div>
          <div style={{ color: PLAYER_COLORS[1], fontWeight: 700, fontSize: 18 }}>{room?.player2_name || 'Jogador 2'}: {placar.p2}</div>
        </div>
        <h2 style={{ color: '#7dd3fc', fontWeight: 800, fontSize: 28, marginBottom: 18, textAlign: 'center' }}>Jogo da Velha Online</h2>
        <div style={{ display: 'flex', gap: 16, marginBottom: 18, justifyContent: 'center' }}>
          {gameState.playerNames.map((name, i) => (
            <div key={i} style={{ background: '#23283a', borderRadius: 10, padding: 8, minWidth: 120, display: 'flex', flexDirection: 'column', alignItems: 'center', border: `2px solid ${PLAYER_COLORS[i]}`, boxShadow: i === gameState.currentPlayer ? `0 0 8px ${PLAYER_COLORS[i]}` : 'none', opacity: gameState.isGameFinished || i === gameState.currentPlayer ? 1 : 0.8 }}>
              <span style={{ fontWeight: 'bold', color: PLAYER_COLORS[i], fontSize: 16, marginBottom: 4 }}>{name}</span>
              <img src={gameState.playerAvatars[i]} alt={name} style={{ width: 36, height: 36, borderRadius: '50%', border: `2px solid ${PLAYER_COLORS[i]}`, marginBottom: 4 }} />
              <span style={{ color: PLAYER_COLORS[i], fontWeight: 'bold', fontSize: 18 }}>{gameState.current === (i === 0 ? 'X' : 'O') ? 'X' : 'O'}</span>
              <span style={{ fontSize: 12 }}>{i === gameState.currentPlayer && !gameState.isGameFinished ? 'Sua vez!' : ''}</span>
            </div>
          ))}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 70px)', gap: 8, justifyContent: 'center', margin: '0 auto 18px auto' }}>
          {gameState.board.map((row, i) => row.map((cell, j) => (
            <button
              key={i + '-' + j}
              onClick={() => handleCellClick(i, j)}
              style={{
                width: 70,
                height: 70,
                fontSize: 36,
                fontWeight: 800,
                background: '#181c24',
                border: '2.5px solid #7dd3fc',
                borderRadius: 10,
                cursor: cell || gameState.winner ? 'not-allowed' : 'pointer',
                transition: 'background 0.15s',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                padding: 0,
              }}
            >
              {cell === 'X' && (
                <span style={{ color: '#ff3333', fontWeight: 900, fontSize: 38, lineHeight: 1 }}>X</span>
              )}
              {cell === 'O' && (
                <svg width="38" height="38" viewBox="0 0 38 38" style={{ display: 'block' }}>
                  <circle cx="19" cy="19" r="14" fill="#232323" />
                </svg>
              )}
            </button>
          )))}
        </div>
        <div style={{ textAlign: 'center', minHeight: 32, fontSize: 20, fontWeight: 700, marginTop: 12 }}>
          {gameState.winner ? (
            gameState.winner === 'Empate' ? 'Empate!' : `Vencedor: ${gameState.winner}`
          ) : (
            gameState.currentPlayer === getPlayerIndex(room, user?.id) ? 'Sua vez!' : 'Aguarde sua vez...'
          )}
        </div>
        {/* Botão de rematch */}
        {gameState.isGameFinished && (
          <div style={{ display: 'flex', justifyContent: 'center', marginTop: 18 }}>
            <button onClick={async () => {
              const initialState = {
                board: Array(3).fill(null).map(() => Array(3).fill(null)),
                current: 'X',
                winner: null,
                playerNames: gameState.playerNames,
                playerAvatars: gameState.playerAvatars,
                currentPlayer: 0,
                turns: 0,
                isGameFinished: false,
              };
              // Atualiza o estado do jogo no Supabase (isso dispara o realtime para ambos)
              const { error } = await supabase.from('tic_tac_toe_game_states').update({
                state: initialState
              }).eq('room_id', roomId);
              if (error) {
                alert('Erro ao reiniciar a partida: ' + error.message);
              }
              // Não faz setShowRematch(false) aqui, pois o realtime vai atualizar o estado
            }} style={{ background: '#38bdf8', color: '#23283a', border: 'none', borderRadius: 8, padding: '8px 22px', fontWeight: 700, fontSize: '1rem', cursor: 'pointer', marginRight: 8 }}>Jogar novamente</button>
            <button onClick={onLeave} style={{ background: '#f59e42', color: '#23283a', border: 'none', borderRadius: 8, padding: '8px 22px', fontWeight: 700, fontSize: '1rem', cursor: 'pointer' }}>Sair da sala</button>
          </div>
        )}
        {/* Histórico detalhado - agora no final da página */}
        <div style={{ margin: '32px 0 0 0', color: '#fff', fontSize: 15, textAlign: 'center' }}>
          {history.length > 0 && (
            <div>
              <div style={{ fontWeight: 700, marginBottom: 4 }}>Histórico de partidas:</div>
              {history.map((h, idx) => (
                <div key={h.id || idx}>
                  Partida {idx + 1}: {h.winner_symbol === 'draw' ? 'Empate' : h.winner_symbol === 'X' ? (room?.player1_name || 'Jogador 1') : (room?.player2_name || 'Jogador 2')} venceu
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
