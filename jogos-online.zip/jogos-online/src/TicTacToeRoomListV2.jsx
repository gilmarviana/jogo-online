import React, { useState, useEffect } from 'react';
import supabase from './supabaseClient';

function ConfirmDialog({ open, onConfirm, onCancel, roomId }) {
  if (!open) return null;
  return (
    <div style={{
      position: 'fixed',
      top: 0, left: 0, right: 0, bottom: 0,
      background: 'rgba(0,0,0,0.35)',
      zIndex: 1000,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <div style={{
        background: '#232634',
        color: '#fff',
        borderRadius: 12,
        padding: '32px 28px',
        minWidth: 320,
        boxShadow: '0 4px 24px #000a',
        textAlign: 'center',
      }}>
        <div style={{ fontSize: 20, fontWeight: 600, marginBottom: 16 }}>Excluir sala #{roomId}?</div>
        <div style={{ marginBottom: 24 }}>Tem certeza que deseja excluir esta sala? Esta ação não pode ser desfeita.</div>
        <button
          onClick={onConfirm}
          style={{
            background: 'linear-gradient(90deg, #e11d48 0%, #f472b6 100%)',
            color: '#fff',
            border: 'none',
            borderRadius: 8,
            fontSize: 16,
            fontWeight: 600,
            padding: '8px 28px',
            marginRight: 12,
            cursor: 'pointer',
          }}
        >
          Excluir
        </button>
        <button
          onClick={onCancel}
          style={{
            background: 'none',
            color: '#fff',
            border: '1.5px solid #fff',
            borderRadius: 8,
            fontSize: 16,
            fontWeight: 600,
            padding: '8px 28px',
            cursor: 'pointer',
          }}
        >
          Cancelar
        </button>
      </div>
    </div>
  );
}

export default function TicTacToeRoomListV2({ user, onJoinRoom }) {
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [roomToDelete, setRoomToDelete] = useState(null);

  useEffect(() => {
    fetchRooms();
    const channel = supabase.channel('tic-tac-toe-rooms-v2').on('postgres_changes', { event: '*', schema: 'public', table: 'tic_tac_toe_rooms' }, fetchRooms).subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  async function fetchRooms() {
    setLoading(true);
    const { data, error } = await supabase.from('tic_tac_toe_rooms').select('*').order('created_at', { ascending: false });
    if (!error) setRooms(data);
    setLoading(false);
  }

  async function handleCreateRoom() {
    setCreating(true);
    // Criação simples, sem restrição de múltiplas salas
    const playerName = user.user_metadata?.name || user.email;
    const roomData = {
      name: `Sala de ${playerName}`,
      owner_id: user.id, // campo extra para evitar erro se a tabela exigir
      player1: user.id,
      player1_name: playerName,
      status: 'waiting',
      player1_ready: false,
      player2_ready: false
    };
    const { data, error } = await supabase.from('tic_tac_toe_rooms').insert(roomData).select().maybeSingle();
    setCreating(false);
    if (error) {
      alert('Erro ao criar sala: ' + (error.message || JSON.stringify(error)));
      console.error('Erro ao criar sala:', error);
      return;
    }
    if (data && !error) onJoinRoom(data.id);
  }

  async function handleJoinRoom(room) {
    // Permite reentrar se já está em algum slot
    if ([room.player1, room.player2].includes(user.id)) {
      onJoinRoom(room.id);
      return;
    }
    // Entra apenas se status for waiting e houver slot
    if (room.status !== 'waiting') return;
    let slot = !room.player2 ? 'player2' : null;
    if (!slot) return;
    let nameSlot = slot + '_name';
    await supabase.from('tic_tac_toe_rooms').update({ [slot]: user.id, [nameSlot]: user.user_metadata?.name || user.email }).eq('id', room.id);
    onJoinRoom(room.id);
  }

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #23283a 60%, #7dd3fc 100%)',
      padding: 0,
      margin: 0,
    }}>
      <div style={{
        background: 'rgba(255,255,255,0.07)',
        borderRadius: 24,
        boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.25)',
        padding: '48px 32px 32px 32px',
        maxWidth: 420,
        width: '100%',
        textAlign: 'center',
      }}>
        <h2 style={{ fontSize: 28, fontWeight: 700, color: '#fff', marginBottom: 8, letterSpacing: 1 }}>Salas do Jogo da Velha</h2>
        <button
          onClick={handleCreateRoom}
          disabled={creating}
          style={{
            marginBottom: 24,
            background: 'linear-gradient(90deg, #38bdf8 0%, #0ea5e9 100%)',
            color: '#fff',
            border: 'none',
            borderRadius: 12,
            fontSize: 18,
            fontWeight: 600,
            padding: '12px 32px',
            cursor: 'pointer',
            boxShadow: '0 2px 8px rgba(14,165,233,0.15)',
            transition: 'transform 0.08s',
          }}
          onMouseDown={e => e.currentTarget.style.transform = 'scale(0.97)'}
          onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
        >
          {creating ? 'Criando...' : 'Criar nova sala'}
        </button>
        {loading ? <div style={{ color: '#fff' }}>Carregando...</div> : (
          <div style={{ marginTop: 16 }}>
            {rooms.length === 0 && <div style={{ color: '#fff' }}>Nenhuma sala disponível.</div>}
            {rooms.map(room => (
              <div key={room.id} style={{
                background: '#232634',
                color: '#fff',
                borderRadius: 10,
                margin: '12px 0',
                padding: 16,
                boxShadow: '0 2px 8px #000a',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                opacity: room.status !== 'waiting' ? 0.7 : 1,
              }}>
                <div style={{ fontWeight: 600, fontSize: 18 }}>Sala #{room.id}</div>
                <div style={{ margin: '8px 0' }}>
                  Jogadores: {[room.player1_name, room.player2_name].filter(Boolean).join(', ')}
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button
                    onClick={() => handleJoinRoom(room)}
                    disabled={room.status !== 'waiting' && ![room.player1, room.player2].includes(user.id) || (room.player2 && ![room.player1, room.player2].includes(user.id))}
                    style={{
                      background: 'linear-gradient(90deg, #4ade80 0%, #22d3ee 100%)',
                      color: '#fff',
                      border: 'none',
                      borderRadius: 8,
                      fontSize: 16,
                      fontWeight: 600,
                      padding: '8px 28px',
                      marginTop: 8,
                      cursor: (room.status !== 'waiting' && ![room.player1, room.player2].includes(user.id)) || (room.player2 && ![room.player1, room.player2].includes(user.id)) ? 'not-allowed' : 'pointer',
                      opacity: (room.status !== 'waiting' && ![room.player1, room.player2].includes(user.id)) || (room.player2 && ![room.player1, room.player2].includes(user.id)) ? 0.7 : 1,
                    }}
                  >
                    {[room.player1, room.player2].includes(user.id) ? 'Voltar' : 'Entrar'}
                  </button>
                  {/* Botão de excluir sala, só para o criador */}
                  {room.player1 === user.id && (
                    <button
                      onClick={() => {
                        setRoomToDelete(room.id);
                        setConfirmOpen(true);
                      }}
                      style={{
                        color: '#fff',
                        background: 'linear-gradient(90deg, #e11d48 0%, #f472b6 100%)',
                        border: 'none',
                        borderRadius: 8,
                        fontSize: 16,
                        marginTop: 8,
                        padding: '8px 18px',
                        cursor: 'pointer',
                        opacity: 0.95,
                        fontWeight: 600,
                        boxShadow: '0 2px 8px rgba(225,29,72,0.13)',
                      }}
                    >
                      Excluir
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      {/* Popup de confirmação de exclusão */}
      <ConfirmDialog
        open={confirmOpen}
        roomId={roomToDelete}
        onConfirm={async () => {
          await supabase.from('tic_tac_toe_rooms').delete().eq('id', roomToDelete);
          await supabase.from('tic_tac_toe_game_states').delete().eq('room_id', roomToDelete);
          setConfirmOpen(false);
          setRoomToDelete(null);
          fetchRooms();
        }}
        onCancel={() => { setConfirmOpen(false); setRoomToDelete(null); }}
      />
    </div>
  );
}
