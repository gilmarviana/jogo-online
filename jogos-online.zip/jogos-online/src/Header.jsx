import React, { useState, useRef, useEffect } from 'react';
import supabase from './supabaseClient';
import './App.css';

export default function Header({ user, onLogout, onUpdateName }) {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const dropdownRef = useRef(null);
  const avatarUrl = user?.user_metadata?.avatar_url;
  const initials = (user?.user_metadata?.name || user?.email || 'U')[0].toUpperCase();
  const [editName, setEditName] = useState(user?.user_metadata?.name || '');
  const [editEmail, setEditEmail] = useState(user?.email || '');
  const [editPassword, setEditPassword] = useState('');
  const [editAvatar, setEditAvatar] = useState(avatarUrl || '');
  // Tema: dark/white
  const [theme, setTheme] = useState(() => localStorage.getItem('theme') || 'dark');

  useEffect(() => {
    document.body.classList.remove('theme-dark', 'theme-white');
    document.body.classList.add(`theme-${theme}`);
    localStorage.setItem('theme', theme);
  }, [theme]);

  // Cores dinâmicas do header
  const headerBg = theme === 'dark' ? '#003f69' : '#eaf3fa'; // color2
  const headerColor = theme === 'dark' ? '#b3aca4' : '#003f69'; // color5
  const borderColor = theme === 'dark' ? '#260d33' : '#b3aca4'; // color1
  const avatarBg = theme === 'dark' ? '#106b87' : '#b3aca4';
  const avatarBorder = theme === 'dark' ? '#157a8c' : '#003f69';
  const dropdownBg = theme === 'dark' ? '#260d33' : '#fff';
  const dropdownBorder = theme === 'dark' ? '#157a8c' : '#b3aca4';
  const dropdownText = theme === 'dark' ? '#b3aca4' : '#003f69';
  const logoutColor = theme === 'dark' ? '#157a8c' : '#106b87';

  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  function handleOpenProfile() {
    setEditName(user?.user_metadata?.name || '');
    setEditEmail(user?.email || '');
    setEditPassword('');
    setEditAvatar(avatarUrl || '');
    setShowProfileModal(true);
  }

  async function handleSaveProfile(e) {
    e.preventDefault();
    if (onUpdateName) onUpdateName(editName);
    // Atualiza avatar no Supabase
    if (editAvatar && user) {
      await supabase.auth.updateUser({ data: { avatar_url: editAvatar } });
      // Atualiza avatar localmente para refletir imediatamente
      setEditAvatar(editAvatar);
    }
    setShowProfileModal(false);
  }

  // avatarUrl agora depende do editAvatar se diferente do user
  const currentAvatarUrl = editAvatar !== (user?.user_metadata?.avatar_url || '') ? editAvatar : user?.user_metadata?.avatar_url;

  return (
    <>
    <header style={{
      background: headerBg,
      color: headerColor,
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '10px 20px',
      boxShadow: '0 2px 5px rgba(0,0,0,0.18)',
      borderBottom: `2px solid ${borderColor}`,
      zIndex: 10
    }}>
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <div style={{ marginRight: 15 }}>
          <img src="https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f3ae.png" alt="Logo" style={{ height: 30, filter: theme === 'dark' ? 'brightness(0) invert(1)' : 'none', cursor: 'pointer' }} />
        </div>
        <nav style={{ display: 'flex', alignItems: 'center' }}>
        </nav>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        {/* Botão de alternância de tema estilo Ionic */}
        <button
          aria-label="Alternar tema"
          onClick={() => setTheme(theme === 'dark' ? 'white' : 'dark')}
          style={{
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            padding: 0,
            marginRight: 8,
            display: 'flex',
            alignItems: 'center',
            height: 35,
            width: 35,
            justifyContent: 'center',
          }}
        >
          {theme === 'dark' ? (
            // Ícone Sol (modo claro)
            <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 512 512" fill="#ffd600"><path d="M256 352a96 96 0 1 0 0-192 96 96 0 0 0 0 192Zm0 64c-17.7 0-32 14.3-32 32v16a16 16 0 0 0 32 0v-16c0-17.7-14.3-32-32-32Zm0-352c17.7 0 32-14.3 32-32V16a16 16 0 0 0-32 0v16c0 17.7 14.3 32 32 32Zm192 192c0-17.7 14.3-32 32-32h16a16 16 0 0 0 0 32h-16c-17.7 0-32-14.3-32-32ZM64 256c0 17.7-14.3 32-32 32H16a16 16 0 0 0 0-32h16c17.7 0 32 14.3 32 32Zm304.97 119.03a16 16 0 0 0 22.63 0l11.31-11.31a16 16 0 0 0-22.63-22.63l-11.31 11.31a16 16 0 0 0 0 22.63ZM119.03 119.03a16 16 0 0 0 0-22.63l-11.31-11.31a16 16 0 0 0-22.63 22.63l11.31 11.31a16 16 0 0 0 22.63 0Zm273.94-22.63a16 16 0 0 0-22.63 0l-11.31 11.31a16 16 0 0 0 22.63 22.63l11.31-11.31a16 16 0 0 0 0-22.63ZM119.03 392.97a16 16 0 0 0-22.63 0l-11.31 11.31a16 16 0 0 0 22.63 22.63l11.31-11.31a16 16 0 0 0 0-22.63Z"/></svg>
          ) : (
            // Ícone Lua (modo escuro)
            <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 512 512" fill="#003f69"><path d="M264.6 480c-63.6 0-123.2-24.8-168.1-69.9C51.4 365.1 26.6 305.5 26.6 241.9c0-49.2 15.2-96.1 44-135.7 6.2-8.5 18.2-9.7 25.6-2.3 5.7 5.7 6.6 14.6 2.1 21-23.2 32.2-35.5 70.2-35.5 111 0 106.1 86.3 192.4 192.4 192.4 40.8 0 78.8-12.3 111-35.5 6.4-4.5 15.3-3.6 21 2.1 7.4 7.4 6.2 19.4-2.3 25.6-39.6 28.8-86.5 44-135.7 44z"/></svg>
          )}
        </button>
        <div ref={dropdownRef} style={{ position: 'relative', display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
          <div onClick={() => setDropdownOpen(v => !v)} style={{ display: 'flex', alignItems: 'center' }}>
            <img
              src={currentAvatarUrl || undefined}
              alt="User Avatar"
              style={{ height: 35, width: 35, borderRadius: '50%', marginRight: 8, objectFit: 'cover', background: avatarBg, display: currentAvatarUrl ? 'block' : 'none', cursor: 'pointer', border: `2px solid ${avatarBorder}` }}
              onClick={handleOpenProfile}
            />
            {!avatarUrl && (
              <div
                style={{ height: 35, width: 35, borderRadius: '50%', marginRight: 8, background: avatarBg, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 18, cursor: 'pointer', border: `2px solid ${avatarBorder}` }}
                onClick={handleOpenProfile}
              >
                {initials}
              </div>
            )}
            <span style={{ color: headerColor, fontSize: 16, marginRight: 2 }}><i className="fas fa-caret-down" /></span>
          </div>
          {dropdownOpen && (
            <div style={{ position: 'absolute', background: dropdownBg, minWidth: 120, boxShadow: '0px 8px 16px 0px rgba(0,0,0,0.18)', zIndex: 1, top: '100%', right: 0, borderRadius: 7, overflow: 'hidden', border: `1.5px solid ${dropdownBorder}` }}>
              <a style={{ color: dropdownText, padding: '12px 16px', textDecoration: 'none', display: 'block', fontSize: 14, cursor: 'pointer' }} onClick={() => { setDropdownOpen(false); handleOpenProfile(); }}>Perfil</a>
              <a style={{ color: dropdownText, padding: '12px 16px', textDecoration: 'none', display: 'block', fontSize: 14, cursor: 'pointer' }}>Configurações</a>
              <button onClick={onLogout} style={{ width: '100%', background: 'none', border: 'none', color: logoutColor, padding: '12px 16px', textAlign: 'left', fontSize: 14, cursor: 'pointer', fontWeight: 700 }}>Sair</button>
            </div>
          )}
        </div>
      </div>
    </header>
    {/* Modal de edição de perfil */}
    {showProfileModal && (
      <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: '#000a', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <form onSubmit={handleSaveProfile} style={{ background: headerBg, padding: 32, borderRadius: 12, minWidth: 320, boxShadow: `0 4px 24px ${borderColor}`, color: headerColor, display: 'flex', flexDirection: 'column', gap: 18, position: 'relative' }}>
          <button type="button" onClick={() => setShowProfileModal(false)} style={{ position: 'absolute', top: 12, right: 16, background: 'none', border: 'none', color: '#fff', fontSize: 22, cursor: 'pointer' }}>×</button>
          <h2 style={{ margin: 0, fontSize: 22, fontWeight: 800 }}>Editar Perfil</h2>
          <label style={{ fontWeight: 600 }}>Nome
            <input value={editName} onChange={e => setEditName(e.target.value)} style={{ width: '100%', padding: 8, borderRadius: 6, border: `1px solid ${avatarBorder}`, marginTop: 4, background: theme === 'dark' ? '#260d33' : '#fff', color: headerColor }} />
          </label>
          <label style={{ fontWeight: 600 }}>Email
            <input value={editEmail} onChange={e => setEditEmail(e.target.value)} style={{ width: '100%', padding: 8, borderRadius: 6, border: `1px solid ${avatarBorder}`, marginTop: 4, background: theme === 'dark' ? '#260d33' : '#fff', color: headerColor }} />
          </label>
          <label style={{ fontWeight: 600 }}>Nova senha
            <input type="password" value={editPassword} onChange={e => setEditPassword(e.target.value)} style={{ width: '100%', padding: 8, borderRadius: 6, border: `1px solid ${avatarBorder}`, marginTop: 4, background: theme === 'dark' ? '#260d33' : '#fff', color: headerColor }} />
          </label>
          <label style={{ fontWeight: 600 }}>Imagem de perfil (URL)
            <input value={editAvatar} onChange={e => setEditAvatar(e.target.value)} style={{ width: '100%', padding: 8, borderRadius: 6, border: `1px solid ${avatarBorder}`, marginTop: 4, background: theme === 'dark' ? '#260d33' : '#fff', color: headerColor }} />
          </label>
          <button type="submit" style={{ background: `linear-gradient(90deg,${avatarBorder} 60%,${avatarBg} 100%)`, color: '#fff', border: 'none', borderRadius: 8, padding: '10px 0', fontWeight: 800, fontSize: '1.08rem', cursor: 'pointer', marginTop: 8 }}>Salvar</button>
        </form>
      </div>
    )}
    </>
  );
}
