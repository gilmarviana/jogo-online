import React, { useEffect, useState } from 'react';
import supabase from './supabaseClient';

export default function MemoryRoom({ user, roomId, onLeave, onStart }) {
  const [room, setRoom] = useState(null);
  const [loading, setLoading] = useState(true);

  // Busca dados da sala e escuta mudanças em tempo real
  useEffect(() => {
    fetchRoom();
    const channel = supabase.channel('memory-room-' + roomId)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'memory_rooms', filter: `id=eq.${roomId}` }, payload => {
        if (payload.new) setRoom(payload.new);
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
    // eslint-disable-next-line
  }, [roomId]);

  async function fetchRoom() {
    setLoading(true);
    const { data, error } = await supabase.from('memory_rooms').select('*').eq('id', roomId).maybeSingle();
    if (!error) setRoom(data);
    setLoading(false);
  }

  // Se a sala estiver em status 'playing', inicia o jogo
  useEffect(() => {
    if (room && room.status === 'playing') {
      onStart();
    }
    // eslint-disable-next-line
  }, [room?.status]);

  if (loading || !room) return <div style={{ color: 'var(--color5)', textAlign: 'center', marginTop: 40 }}>Carregando sala...</div>;

  const players = ['player1', 'player2', 'player3', 'player4'].map(slot => ({
    id: room[slot],
    name: room[slot + '_name'],
  })).filter(p => p.id);

  const isOwner = room && user && room.player1 === user.id;

  return (
    <div
      style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--color1)', padding: 0, margin: 0, transition: 'background 0.3s' }}
      className={window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'ion-dark' : 'ion-light'}
    >
      <div style={{ background: 'var(--color2)', borderRadius: 24, boxShadow: '0 8px 32px 0 var(--color3)44', padding: '48px 32px 32px 32px', maxWidth: 420, width: '100%', textAlign: 'center', color: 'var(--color5)', transition: 'background 0.3s, color 0.3s' }}>
        <h2 style={{ fontSize: 28, fontWeight: 700, color: 'var(--color5)', marginBottom: 8, letterSpacing: 1 }}>Sala #{roomId}</h2>
        <div style={{ marginBottom: 18, color: 'var(--color5)', fontSize: 18 }}>
          Jogadores: {players.map(p => p.name).join(', ')}
        </div>
        <div style={{ display: 'flex', gap: 16, justifyContent: 'center', marginBottom: 24 }}>
          <button
            onClick={onLeave}
            style={{
              background: 'none',
              color: 'var(--color5)',
              border: '2px solid var(--color5)',
              borderRadius: 8,
              fontSize: 16,
              fontWeight: 600,
              padding: '8px 28px',
              cursor: 'pointer',
              transition: 'background 0.15s, color 0.15s, border 0.2s',
            }}
          >
            Sair da sala
          </button>
          {isOwner && (
            <button
              onClick={async () => {
                await supabase.from('memory_rooms').update({ status: 'playing' }).eq('id', roomId);
              }}
              style={{
                background: 'linear-gradient(90deg, var(--color3) 0%, var(--color4) 100%)',
                color: 'var(--color1)',
                border: '2px solid var(--color5)',
                borderRadius: 8,
                fontSize: 16,
                fontWeight: 700,
                padding: '8px 28px',
                cursor: 'pointer',
                boxShadow: '0 2px 8px var(--color3)22',
                transition: 'background 0.2s, border 0.2s',
              }}
            >
              Iniciar Jogo
            </button>
          )}
        </div>
        <div style={{ color: 'var(--color5)', fontSize: 15, marginTop: 18 }}>
          Aguarde todos os jogadores entrarem antes de iniciar.
        </div>
      </div>
    </div>
  );
}
