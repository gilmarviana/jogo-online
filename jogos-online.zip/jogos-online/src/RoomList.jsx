import React, { useEffect, useState } from 'react';
import supabase from './supabaseClient';
import './RoomList.css';

export default function RoomList({ user, onJoinRoom }) {
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [roomIdInput, setRoomIdInput] = useState('');
  const [actionRoomId, setActionRoomId] = useState(null); // Para loading individual

  useEffect(() => {
    fetchRooms();
    // Subscribe para updates em tempo real
    const subscription = supabase
      .channel('rooms-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'rooms' }, payload => {
        fetchRooms();
      })
      .subscribe();
    return () => { supabase.removeChannel(subscription); };
  }, []);

  async function fetchRooms() {
    setLoading(true);
    const { data, error } = await supabase
      .from('rooms')
      .select('*')
      .order('created_at', { ascending: false });
    setRooms(data || []);
    setError(error ? error.message : '');
    setLoading(false);
  }

  async function handleCreateRoom() {
    setLoading(true);
    setActionRoomId('creating');
    // Usa o nome do Header (user.user_metadata.name) se existir, senão o email
    const playerName = user.user_metadata?.name || user.email;
    const { data, error } = await supabase
      .from('rooms')
      .insert([{ player1: user.id, player1_name: playerName }])
      .select();
    setLoading(false);
    setActionRoomId(null);
    if (error || !data || !data[0]) {
      setError(error ? error.message : 'Erro ao criar sala');
    } else {
      // Busca a sala criada pelo id
      const roomId = data[0].id;
      const { data: roomData, error: fetchError } = await supabase
        .from('rooms')
        .select('*')
        .eq('id', roomId)
        .maybeSingle();
      if (fetchError || !roomData) setError('Erro ao buscar sala criada');
      else onJoinRoom(roomData.id);
    }
  }

  async function handleJoinRoom(room) {
    setActionRoomId(room.id);
    // Permite reentrar se o usuário for player1 ou player2
    if (room.player1 === user.id || room.player2 === user.id) {
      onJoinRoom(room.id);
      setActionRoomId(null);
      return;
    }
    if (room.player2) {
      setActionRoomId(null);
      return;
    }
    setLoading(true);
    const { data, error } = await supabase
      .from('rooms')
      .update({ player2: user.id, player2_name: user.user_metadata?.name || user.email, status: 'playing', current_turn: room.player1 })
      .eq('id', room.id)
      .select();
    setLoading(false);
    setActionRoomId(null);
    if (error || !data || !data[0]) {
      setError(error ? error.message : 'Erro ao entrar na sala');
    } else {
      // Busca a sala atualizada pelo id
      const roomId = data[0].id;
      const { data: roomData, error: fetchError } = await supabase
        .from('rooms')
        .select('*')
        .eq('id', roomId)
        .maybeSingle();
      if (fetchError || !roomData) setError('Erro ao buscar sala');
      else onJoinRoom(roomData.id);
    }
  }

  async function handleJoinById() {
    if (!roomIdInput) return;
    setLoading(true);
    setActionRoomId('byid');
    const { data, error } = await supabase
      .from('rooms')
      .select('*')
      .eq('id', roomIdInput)
      .maybeSingle(); // Permite zero ou um resultado
    setLoading(false);
    setActionRoomId(null);
    if (error || !data) {
      setError('Sala não encontrada!');
      return;
    }
    handleJoinRoom(data);
  }

  async function handleDeleteRoom(roomId) {
    setActionRoomId('delete-' + roomId);
    await supabase.from('rooms').delete().eq('id', roomId);
    setActionRoomId(null);
    fetchRooms();
  }

  function getStatusLabel(status) {
    if (status === 'waiting') return 'Aguardando jogador';
    if (status === 'playing') return 'Em andamento';
    if (status === 'finished') return 'Finalizada';
    return status;
  }

  function isUserInRoom(room) {
    return room.player1 === user.id || room.player2 === user.id;
  }

  return (
    <div className="room-list-container" style={{ background: 'var(--color1)', minHeight: '100vh', padding: 0, margin: 0 }}>
      <h2 style={{ color: 'var(--color5)' }}>Salas Online</h2>
      <div style={{ marginBottom: 12 }}>
        <button onClick={handleCreateRoom} disabled={loading || actionRoomId === 'creating'}
          style={{ background: 'var(--color4)', color: 'var(--color1)', border: 'none', borderRadius: 8, padding: '8px 22px', fontWeight: 700, fontSize: 16, cursor: 'pointer', boxShadow: '0 2px 8px var(--color4)33', marginRight: 8 }}>
          {actionRoomId === 'creating' ? 'Criando...' : 'Criar Sala'}
        </button>
        <span style={{ marginLeft: 12, color: 'var(--color5)', fontSize: 13 }}>
          Crie uma sala para desafiar outro jogador!
        </span>
      </div>
      {error && <div className="status lose" style={{ color: 'var(--color4)', fontWeight: 700 }}>{error}</div>}
      <div className="room-list">
        {loading ? <div style={{ color: 'var(--color5)' }}>Carregando salas...</div> :
          rooms.length === 0 ? <div style={{ color: 'var(--color5)' }}>Nenhuma sala disponível no momento.</div> :
          rooms.map(room => {
            const userInRoom = isUserInRoom(room);
            return (
              <div key={room.id} className={`room-card${userInRoom ? ' highlight-room' : ''}`}
                title={userInRoom ? 'Você está nesta sala' : ''}
                style={{
                  background: 'var(--color2)',
                  color: 'var(--color5)',
                  borderRadius: 14,
                  boxShadow: userInRoom ? '0 2px 12px var(--color4)44' : '0 2px 8px var(--color3)22',
                  marginBottom: 18,
                  padding: '18px 18px 12px 18px',
                  border: userInRoom ? '2px solid var(--color4)' : '1.5px solid var(--color3)',
                  fontSize: 15
                }}>
                <div style={{ fontSize: 13, color: 'var(--color3)', marginBottom: 2 }}>
                  ID da Sala:
                  <span style={{ fontWeight: 600, color: 'var(--color5)', marginLeft: 4 }}>{room.id}</span>
                </div>
                <div>
                  <b>Jogador 1:</b> {room.player1_name ? (room.player1 === user.id ? 'Você' : room.player1_name) : (room.player1 ? room.player1.slice(0, 8) : 'Aguardando')}
                </div>
                <div>
                  <b>Jogador 2:</b> {room.player2_name ? (room.player2 === user.id ? 'Você' : room.player2_name) : (room.player2 ? room.player2.slice(0, 8) : 'Aguardando')}
                </div>
                <div style={{ margin: '6px 0' }}>
                  <b>Status:</b> <span style={{ color: room.status === 'waiting' ? 'var(--color4)' : room.status === 'playing' ? '#6cf78a' : 'var(--color3)' }}>{getStatusLabel(room.status)}</span>
                </div>
                {room.player1 === user.id && (
                  <button onClick={() => handleDeleteRoom(room.id)} disabled={loading || actionRoomId === 'delete-' + room.id} style={{ marginRight: 8, background: '#e11d48', color: '#fff', border: 'none', borderRadius: 4, padding: '4px 12px', cursor: 'pointer', fontWeight: 700 }}>
                    {actionRoomId === 'delete-' + room.id ? 'Excluindo...' : 'Excluir'}
                  </button>
                )}
                {userInRoom && room.status === 'playing' ? (
                  <button onClick={() => handleJoinRoom(room)} disabled={loading || actionRoomId === room.id}
                    style={{ background: 'var(--color3)', color: 'var(--color5)', border: 'none', borderRadius: 6, padding: '6px 18px', fontWeight: 700, cursor: 'pointer' }}>
                    {actionRoomId === room.id ? 'Entrando...' : 'Continuar'}
                  </button>
                ) :
                  (!room.player2 && room.player1 !== user.id && room.status === 'waiting' && (
                    <button onClick={() => handleJoinRoom(room)} disabled={loading || actionRoomId === room.id}
                      style={{ background: 'var(--color4)', color: 'var(--color1)', border: 'none', borderRadius: 6, padding: '6px 18px', fontWeight: 700, cursor: 'pointer' }}>
                      {actionRoomId === room.id ? 'Entrando...' : 'Entrar'}
                    </button>
                  ))
                }
              </div>
            );
          })}
      </div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 16, marginTop: 18, alignItems: 'center' }}>
        <input
          type="text"
          placeholder="ID da sala"
          value={roomIdInput}
          onChange={e => setRoomIdInput(e.target.value)}
          style={{ padding: 6, borderRadius: 4, border: '1.5px solid var(--color3)', background: 'var(--color2)', color: 'var(--color5)', minWidth: 120 }}
        />
        <button onClick={handleJoinById} disabled={loading || !roomIdInput || actionRoomId === 'byid'}
          style={{ background: 'var(--color4)', color: 'var(--color1)', border: 'none', borderRadius: 6, padding: '6px 18px', fontWeight: 700, cursor: 'pointer' }}>
          {actionRoomId === 'byid' ? 'Acessando...' : 'Acessar Sala'}
        </button>
        <span style={{ color: 'var(--color5)', fontSize: 13 }}>
          Digite o ID completo para acessar diretamente uma sala
        </span>
      </div>
    </div>
  );
}
