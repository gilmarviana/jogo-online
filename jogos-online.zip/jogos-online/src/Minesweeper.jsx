import React, { useState, useEffect } from 'react';
import './Minesweeper.css';

function createEmptyBoard(size) {
  return Array(size)
    .fill()
    .map(() =>
      Array(size).fill().map(() => ({
        revealed: false,
        mine: false,
        flagged: false, // legacy, não mais usado
        flaggedBy: undefined, // legacy, não mais usado
        flags: {}, // Novo: flags por usuário
        adjacent: 0,
      }))
    );
}

function placeMines(board, mines) {
  const size = board.length;
  let placed = 0;
  while (placed < mines) {
    const x = Math.floor(Math.random() * size);
    const y = Math.floor(Math.random() * size);
    if (!board[x][y].mine) {
      board[x][y] = { ...board[x][y], mine: true };
      placed++;
    }
  }
  return board;
}

function countAdjacent(board, x, y) {
  const dirs = [
    [-1, -1], [-1, 0], [-1, 1],
    [0, -1],           [0, 1],
    [1, -1], [1, 0], [1, 1],
  ];
  let count = 0;
  for (const [dx, dy] of dirs) {
    const nx = x + dx, ny = y + dy;
    if (
      nx >= 0 && nx < board.length &&
      ny >= 0 && ny < board.length &&
      board[nx][ny].mine
    ) {
      count++;
    }
  }
  return count;
}

function fillAdjacents(board) {
  return board.map((row, x) =>
    row.map((cell, y) => ({
      ...cell,
      adjacent: cell.mine ? 0 : countAdjacent(board, x, y),
    }))
  );
}

function reveal(board, x, y, visited = {}) {
  if (
    x < 0 || x >= board.length ||
    y < 0 || y >= board.length ||
    board[x][y].revealed ||
    board[x][y].flagged
  ) {
    return;
  }
  board[x][y].revealed = true;
  if (board[x][y].adjacent === 0 && !board[x][y].mine) {
    const dirs = [
      [-1, -1], [-1, 0], [-1, 1],
      [0, -1],           [0, 1],
      [1, -1], [1, 0], [1, 1],
    ];
    for (const [dx, dy] of dirs) {
      reveal(board, x + dx, y + dy, visited);
    }
  }
}

function revealWithPlayer(board, x, y, playerId, visited = {}) {
  if (
    x < 0 || x >= board.length ||
    y < 0 || y >= board.length ||
    board[x][y].revealed ||
    board[x][y].flagged
  ) {
    return;
  }
  board[x][y].revealed = true;
  if (!board[x][y].mine) {
    board[x][y].openedBy = playerId;
  }
  if (board[x][y].adjacent === 0 && !board[x][y].mine) {
    const dirs = [
      [-1, -1], [-1, 0], [-1, 1],
      [0, -1],           [0, 1],
      [1, -1], [1, 0], [1, 1],
    ];
    for (const [dx, dy] of dirs) {
      revealWithPlayer(board, x + dx, y + dy, playerId, visited);
    }
  }
}

function checkWin(board) {
  for (let row of board) {
    for (let cell of row) {
      if (!cell.mine && !cell.revealed) return false;
    }
  }
  return true;
}

function cloneBoard(board) {
  return board.map(row => row.map(cell => ({ ...cell })));
}

export default function Minesweeper({ online, board: onlineBoard, setBoard: setOnlineBoard, user, roomId, currentTurn, room }) {
  const [size, setSize] = useState(8);
  const [mines, setMines] = useState(10);
  const [board, setBoard] = useState(() => {
    let b = createEmptyBoard(8);
    b = placeMines(b, 10);
    b = fillAdjacents(b);
    return b;
  });
  const [gameOver, setGameOver] = useState(false);
  const [win, setWin] = useState(false);
  // Modal para regras solo
  const [showRulesModal, setShowRulesModal] = useState(false);
  const [pendingSize, setPendingSize] = useState(size);
  const [pendingMines, setPendingMines] = useState(mines);

  // Inicia o cronômetro ao começar uma nova partida solo
  function startGame(newSize = size, newMines = mines) {
    if (online) return;
    let b = createEmptyBoard(newSize);
    b = placeMines(b, newMines);
    b = fillAdjacents(b);
    setBoard(b);
    setGameOver(false);
    setWin(false);
  }

  // Remove o log de debug e garanta que o board sempre é inicializado corretamente
  // Garante que o board nunca é sobrescrito por undefined/null
  useEffect(() => {
    if (online && onlineBoard && onlineBoard.board) {
      setBoard(onlineBoard.board);
      if (onlineBoard.gameOver !== undefined) setGameOver(onlineBoard.gameOver);
      if (onlineBoard.win !== undefined) setWin(onlineBoard.win);
    }
  }, [online, onlineBoard]);

  // Fallback para board inválido
  if (!Array.isArray(board) || board.length === 0 || !Array.isArray(board[0])) {
    return <div style={{ color: 'red', margin: 32 }}>Erro ao carregar o tabuleiro. Tente sair e entrar novamente na sala.<br/>Se persistir, peça para o criador da sala criar uma nova.</div>;
  }

  // Mensagem de aguarde o turno no modo online
  const isMyTurn = !online || (user && currentTurn && user.id === currentTurn);

  function startGame(newSize = size, newMines = mines) {
    if (online) return;
    let b = createEmptyBoard(newSize);
    b = placeMines(b, newMines);
    b = fillAdjacents(b);
    setBoard(b);
    setGameOver(false);
    setWin(false);
  }

  function handleCellClick(x, y) {
    // Bloqueia para qualquer jogador se o estado global do jogo online indicar gameOver ou win
    if (online && onlineBoard && (onlineBoard.gameOver || onlineBoard.win)) return;
    if (gameOver || win) return;
    if (online && user && currentTurn && user.id !== currentTurn) return;
    // Só bloqueia clique se a célula está marcada com bandeira pelo próprio jogador (apenas online)
    if (online && user && board[x][y].flags && board[x][y].flags[user.id]) return;
    if (board[x][y].mine) {
      if (online && setOnlineBoard) {
        const newBoard = cloneBoard(board);
        newBoard[x][y].revealed = true;
        // Não marca openedBy para minas
        setOnlineBoard({ board: newBoard, gameOver: true, win: false }, 0, true); // update para todos
      } else {
        setGameOver(true);
        const newBoard = cloneBoard(board);
        newBoard[x][y].revealed = true;
        setBoard(newBoard);
      }
      return;
    }
    const newBoard = cloneBoard(board);
    let revealedBefore = countRevealed(board);
    if (online && user) {
      revealWithPlayer(newBoard, x, y, user.id);
    } else {
      reveal(newBoard, x, y);
    }
    let revealedAfter = countRevealed(newBoard);
    let points = revealedAfter - revealedBefore;
    if (points === 0) return; // Não faz nada se não revelou célula nova
    if (online && setOnlineBoard) {
      const isWin = checkWin(newBoard);
      if (isWin) {
        setOnlineBoard({ board: newBoard, gameOver: true, win: true }, points);
      } else {
        setOnlineBoard({ board: newBoard, gameOver: false, win: false }, points);
      }
    } else {
      setBoard(newBoard);
      if (checkWin(newBoard)) setWin(true);
    }
  }

  function handleRightClick(e, x, y) {
    e.preventDefault();
    // Bloqueia para qualquer jogador se o estado global do jogo online indicar gameOver ou win
    if (online && onlineBoard && (onlineBoard.gameOver || onlineBoard.win)) return;
    if (gameOver || win) return;
    if (online && user && currentTurn && user.id !== currentTurn) return;
    const newBoard = cloneBoard(board);
    if (online && user) {
      // Se já tem bandeira do próprio usuário, remove
      if (newBoard[x][y].flags && newBoard[x][y].flags[user.id]) {
        delete newBoard[x][y].flags[user.id];
      } else {
        // Marca bandeira do próprio usuário
        if (!newBoard[x][y].flags) newBoard[x][y].flags = {};
        newBoard[x][y].flags[user.id] = true;
      }
      setBoard(newBoard);
    } else {
      // Solo: comportamento antigo
      if (newBoard[x][y].flagged) {
        newBoard[x][y].flagged = false;
      } else {
        newBoard[x][y].flagged = true;
      }
      setBoard(newBoard);
    }
  }

  function handleMenuSubmit(e) {
    e.preventDefault();
    if (online) return;
    startGame(Number(size), Number(mines));
  }

  // Modal de regras deve funcionar para solo e online
  function handleNewGameClick() {
    // Sempre inicializa com valores atuais ou padrão
    setPendingSize(size || 8);
    setPendingMines(mines || 10);
    setShowRulesModal(true);
  }

  function handleRulesConfirm(e) {
    e.preventDefault();
    setShowRulesModal(false);
    setSize(Number(pendingSize));
    setMines(Number(pendingMines));
    startGame(Number(pendingSize), Number(pendingMines));
  }

  function handleOnlineRulesConfirm(e) {
    e.preventDefault();
    setShowRulesModal(false);
    if (setOnlineBoard) {
      let b = createEmptyBoard(Number(pendingSize));
      b = placeMines(b, Number(pendingMines));
      b = fillAdjacents(b);
      setOnlineBoard({ board: b, gameOver: false, win: false, size: Number(pendingSize), mines: Number(pendingMines) }, 0, true);
    }
  }

  function countRevealed(b) {
    let count = 0;
    for (let row of b) for (let cell of row) if (cell.revealed) count++;
    return count;
  }

  return (
    <div className="minesweeper">
      {/* Exibe as cores e pontuação dos jogadores no topo no modo online */}
      {online && room && user && (
        <div style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          gap: 32,
          marginBottom: 16,
        }}>
          {/* Jogador atual */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontWeight: 600 }}>Você</span>
            <input
              type="color"
              value={user.id === room.player1 ? (room.color1 || '#4be04b') : (room.color2 || '#3b82f6')}
              disabled
              style={{ width: 28, height: 28, border: 'none', background: 'none', cursor: 'default' }}
              readOnly
            />
            <span style={{ fontWeight: 600 }}>
              {user.id === room.player1 ? (room.score1 ?? 0) : (room.score2 ?? 0)} pts
            </span>
          </div>
          {/* Adversário */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontWeight: 600 }}>Adversário</span>
            <input
              type="color"
              value={user.id === room.player1 ? (room.color2 || '#3b82f6') : (room.color1 || '#4be04b')}
              disabled
              style={{ width: 28, height: 28, border: 'none', background: 'none', cursor: 'default' }}
              readOnly
            />
            <span style={{ fontWeight: 600 }}>
              {user.id === room.player1 ? (room.score2 ?? 0) : (room.score1 ?? 0)} pts
            </span>
          </div>
        </div>
      )}
      {/* Menu de regras só no solo */}
      {/* Removido: exibição de tamanho e bombas na tela normal, pois agora está no modal */}
      {/* Botão Nova Partida só aparece quando acaba (apenas SOLO) */}
      {!online && (gameOver || win) && (
        <button onClick={handleNewGameClick} style={{ marginTop: 24, background: 'var(--color4)', color: 'var(--color1)', border: 'none', borderRadius: 6, padding: '10px 22px', fontSize: '1.1rem', cursor: 'pointer', fontWeight: 700 }}>
          Nova Partida
        </button>
      )}
      {/* Modal de regras, aparece ao clicar em Nova Partida após fim de jogo (solo ou online) */}
      {showRulesModal && (
        <div className="modal-overlay" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
          <div className="modal" style={{ background: 'var(--color2)', padding: 32, borderRadius: 12, minWidth: 320, color: 'var(--color5)', boxShadow: '0 2px 16px #0008' }}>
            <form onSubmit={online ? handleOnlineRulesConfirm : handleRulesConfirm}>
              <h2 style={{ color: 'var(--color5)' }}>Configurar Nova Partida</h2>
              <div style={{ margin: '18px 0' }}>
                <label>Tamanho do tabuleiro: </label>
                <input type="number" min={4} max={20} value={pendingSize} onChange={e => setPendingSize(e.target.value)} style={{ width: 60, marginLeft: 8, background: 'var(--color1)', color: 'var(--color5)', border: '1px solid var(--color4)', borderRadius: 5 }} />
              </div>
              <div style={{ margin: '18px 0' }}>
                <label>Quantidade de bombas: </label>
                <input type="number" min={1} max={pendingSize*pendingSize-1} value={pendingMines} onChange={e => setPendingMines(e.target.value)} style={{ width: 60, marginLeft: 8, background: 'var(--color1)', color: 'var(--color5)', border: '1px solid var(--color4)', borderRadius: 5 }} />
              </div>
              <div style={{ marginTop: 24, display: 'flex', gap: 16, justifyContent: 'flex-end' }}>
                <button type="button" onClick={() => setShowRulesModal(false)} style={{ background: 'var(--color3)', color: 'var(--color5)', border: 'none', borderRadius: 6, padding: '8px 18px', fontSize: '1rem', cursor: 'pointer', fontWeight: 600 }}>Cancelar</button>
                <button type="submit" style={{ background: 'var(--color4)', color: 'var(--color1)', border: 'none', borderRadius: 6, padding: '8px 18px', fontSize: '1rem', cursor: 'pointer', fontWeight: 700 }}>Iniciar</button>
              </div>
            </form>
          </div>
        </div>
      )}
      <div className="board">
        {board.map((row, x) => (
          <div className="row" key={x}>
            {row.map((cell, y) => {
              // Se a célula está com bandeira e o usuário NÃO é o dono da bandeira, ela deve parecer fechada (sem número, sem cor, sem nada)
              const isFlaggedByOther = cell.flagged && online && user && cell.flaggedBy && cell.flaggedBy !== user.id;
              // Novo: só mostra a bandeira se a célula tem flags[user.id]
              const hasMyFlag = online && user && cell.flags && cell.flags[user.id];
              // Mostra cor personalizada se célula revelada, não tem mina, modo online, e foi aberta por qualquer jogador
              let cellStyle = {};
              if (
                cell.revealed && !cell.mine && online && room && room.player1 && room.player2 && cell.openedBy
              ) {
                if (cell.openedBy === room.player1 && room.color1) {
                  cellStyle.background = room.color1;
                } else if (cell.openedBy === room.player2 && room.color2) {
                  cellStyle.background = room.color2;
                }
              }
              // Bloqueia clique se o jogo acabou (online: pelo estado global)
              const disableCell = (online && onlineBoard && (onlineBoard.gameOver || onlineBoard.win)) || gameOver || win;
              return (
                <div
                  key={y}
                  className={`cell${cell.revealed ? ' revealed' : ''}${hasMyFlag ? ' flagged' : ''}`}
                  style={cellStyle}
                  data-mine={cell.mine && cell.revealed ? 'true' : 'false'}
                  onClick={disableCell ? undefined : () => handleCellClick(x, y)}
                  onContextMenu={disableCell ? undefined : e => handleRightClick(e, x, y)}
                >
                  {cell.revealed
                    ? cell.mine
                      ? '💣'
                      : cell.adjacent > 0
                      ? cell.adjacent
                      : ''
                    : (hasMyFlag || (!online && cell.flagged))
                    ? '🚩'
                    : ''}
                </div>
              );
            })}
          </div>
        ))}
      </div>
      {/* Exibe o vencedor após explosão da bomba ou vitória no online */}
      {online && onlineBoard && (onlineBoard.gameOver || onlineBoard.win) && room && (
        <div className="status win" style={{ fontWeight: 700, fontSize: 20, marginTop: 16 }}>
          {(() => {
            // Se win, quem abriu a última célula venceu; se gameOver, o adversário venceu
            if (onlineBoard.win) {
              // Quem abriu a última célula venceu
              const winnerId = currentTurn;
              let winnerName;
              if (winnerId === room.player1) {
                winnerName = room.player1_name || room.player1_email || room.player1;
              } else {
                winnerName = room.player2_name || room.player2_email || room.player2;
              }
              return winnerId === user.id
                ? `Você venceu!`
                : `${winnerName} venceu!`;
            } else if (onlineBoard.gameOver) {
              // Quem explodiu perdeu, adversário venceu
              const loserId = currentTurn;
              const winnerId = loserId === room.player1 ? room.player2 : room.player1;
              let winnerName;
              if (winnerId === room.player1) {
                winnerName = room.player1_name || room.player1_email || room.player1;
              } else {
                winnerName = room.player2_name || room.player2_email || room.player2;
              }
              return winnerId === user.id
                ? `Você venceu!`
                : `${winnerName} venceu!`;
            }
            return null;
          })()}
        </div>
      )}
      {/* Mensagens solo */}
      {!online && gameOver && <div className="status lose">Você perdeu!</div>}
      {!online && win && <div className="status win">Você venceu!</div>}
      {online && !((onlineBoard && (onlineBoard.gameOver || onlineBoard.win)) || gameOver || win) && (
        <div className={`status ${isMyTurn ? 'turn' : 'wait'}`}>{isMyTurn ? 'É sua vez!' : 'Aguarde sua vez...'}</div>
      )}
      {/* Monitor de progresso no modo solo (sem tempo e sem recorde) */}
      {!online && (
        <div style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          gap: 24,
          marginBottom: 16,
          fontWeight: 600,
          color: '#e3e6ed',
          fontSize: 18
        }}>
          <span>Reveladas: {countRevealed(board)}</span>
          <span>Faltam: {board.length * board.length - mines - countRevealed(board)}</span>
          <span>Bombas: {mines}</span>
        </div>
      )}
    </div>
  );
}

export { createEmptyBoard, placeMines, fillAdjacents };
