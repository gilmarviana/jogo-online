import React from 'react';

export default function TicTacToeModeSelect({ onSelectMode, onBack }) {
  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'linear-gradient(135deg, var(--color1) 60%, var(--color2) 100%)',
        padding: 0,
        margin: 0,
        transition: 'background 0.3s',
      }}
    >
      <div
        style={{
          background: 'var(--color2)',
          borderRadius: 24,
          boxShadow: '0 8px 32px 0 var(--color1)',
          padding: '48px 32px 32px 32px',
          maxWidth: 420,
          width: '100%',
          textAlign: 'center',
          border: '2px solid var(--color3)',
          transition: 'background 0.3s',
        }}
      >
        <h2 style={{ fontSize: 32, fontWeight: 700, color: 'var(--color5)', marginBottom: 8, letterSpacing: 1, textShadow: '0 2px 8px var(--color1)' }}>Jogo da Velha</h2>
        <p style={{ color: 'var(--color5)', fontSize: 18, marginBottom: 32 }}>Escolha o modo de jogo:</p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
          <button
            onClick={() => onSelectMode('tic-tac-toe-local')}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 16,
              background: 'var(--color3)',
              color: 'var(--color5)',
              border: '1.5px solid var(--color4)',
              borderRadius: 12,
              fontSize: 22,
              fontWeight: 600,
              padding: '18px 32px',
              cursor: 'pointer',
              boxShadow: '0 2px 8px var(--color1)',
              transition: 'transform 0.08s, background 0.2s',
            }}
            onMouseDown={e => e.currentTarget.style.transform = 'scale(0.97)'}
            onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
            onMouseOver={e => e.currentTarget.style.background = 'var(--color4)'}
            onMouseOut={e => e.currentTarget.style.background = 'var(--color3)'}
          >
            <span style={{ fontSize: 28, display: 'flex', alignItems: 'center' }}>👤</span>
            <span style={{ textAlign: 'left' }}>
              Local<br />
              <span style={{ fontSize: 15, fontWeight: 400, color: 'var(--color5)' }}>2 jogadores ou contra o computador</span>
            </span>
          </button>
          <button
            onClick={() => onSelectMode('tic-tac-toe-online')}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 16,
              background: 'var(--color4)',
              color: 'var(--color5)',
              border: '1.5px solid var(--color3)',
              borderRadius: 12,
              fontSize: 22,
              fontWeight: 600,
              padding: '18px 32px',
              cursor: 'pointer',
              boxShadow: '0 2px 8px var(--color1)',
              transition: 'transform 0.08s, background 0.2s',
            }}
            onMouseDown={e => e.currentTarget.style.transform = 'scale(0.97)'}
            onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
            onMouseOver={e => e.currentTarget.style.background = 'var(--color3)'}
            onMouseOut={e => e.currentTarget.style.background = 'var(--color4)'}
          >
            <span style={{ fontSize: 28, display: 'flex', alignItems: 'center' }}>🌐</span>
            <span style={{ textAlign: 'left' }}>
              Online<br />
              <span style={{ fontSize: 15, fontWeight: 400, color: 'var(--color5)' }}>Jogue com outra pessoa pela internet</span>
            </span>
          </button>
        </div>
        <div style={{ marginTop: 40 }}>
          <button
            onClick={onBack}
            style={{
              color: 'var(--color5)',
              background: 'none',
              border: '1.5px solid var(--color5)',
              padding: '8px 28px',
              borderRadius: 8,
              fontSize: 16,
              marginTop: 8,
              cursor: 'pointer',
              opacity: 0.8,
              transition: 'background 0.15s, color 0.15s',
            }}
            onMouseOver={e => { e.currentTarget.style.background = 'var(--color1)'; e.currentTarget.style.color = 'var(--color5)'; }}
            onMouseOut={e => { e.currentTarget.style.background = 'none'; e.currentTarget.style.color = 'var(--color5)'; }}
          >
            Voltar
          </button>
        </div>
      </div>
    </div>
  );
}
