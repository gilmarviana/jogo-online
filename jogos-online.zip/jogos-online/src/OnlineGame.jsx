import React, { useEffect, useState } from 'react';
import supabase from './supabaseClient';
import Minesweeper from './Minesweeper';
import { createEmptyBoard, placeMines, fillAdjacents } from './Minesweeper';

function GameConfigModal({ show, onClose, onStart, defaultSize = 8, defaultMines = 10 }) {
  const [size, setSize] = useState(defaultSize);
  const [mines, setMines] = useState(defaultMines);
  if (!show) return null;
  return (
    <div style={{
      position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh',
      background: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000
    }}>
      <div style={{ background: 'var(--color2)', padding: 32, borderRadius: 12, minWidth: 320, color: 'var(--color5)', boxShadow: '0 2px 16px #0008' }}>
        <h2 style={{ color: 'var(--color5)' }}>Configurar Nova Partida</h2>
        <div style={{ margin: '18px 0' }}>
          <label>Tamanho do tabuleiro: </label>
          <input type="number" min={5} max={20} value={size} onChange={e => setSize(Number(e.target.value))} style={{ width: 60, marginLeft: 8, background: 'var(--color1)', color: 'var(--color5)', border: '1px solid var(--color4)', borderRadius: 5 }} />
        </div>
        <div style={{ margin: '18px 0' }}>
          <label>Quantidade de bombas: </label>
          <input type="number" min={1} max={size*size-1} value={mines} onChange={e => setMines(Number(e.target.value))} style={{ width: 60, marginLeft: 8, background: 'var(--color1)', color: 'var(--color5)', border: '1px solid var(--color4)', borderRadius: 5 }} />
        </div>
        <div style={{ marginTop: 24, display: 'flex', gap: 16, justifyContent: 'flex-end' }}>
          <button onClick={onClose} style={{ background: 'var(--color3)', color: 'var(--color5)', border: 'none', borderRadius: 6, padding: '8px 18px', fontSize: '1rem', cursor: 'pointer', fontWeight: 600 }}>Cancelar</button>
          <button onClick={() => onStart(size, mines)} style={{ background: 'var(--color4)', color: 'var(--color1)', border: 'none', borderRadius: 6, padding: '8px 18px', fontSize: '1rem', cursor: 'pointer', fontWeight: 700 }}>Iniciar</button>
        </div>
      </div>
    </div>
  );
}

export default function OnlineGame({ user, roomId, onLeave }) {
  const [gameState, setGameState] = useState(null);
  const [room, setRoom] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [victoryHistory, setVictoryHistory] = useState({});
  const [configModalVisible, setConfigModalVisible] = useState(false);
  const [defaultSize, setDefaultSize] = useState(8);
  const [defaultMines, setDefaultMines] = useState(10);
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [lastConfig, setLastConfig] = useState({ size: 8, mines: 10 });
  const [startCountdown, setStartCountdown] = useState(null);
  const [lastFinishedGame, setLastFinishedGame] = useState(null);

  // Busca o estado da sala e do jogo
  useEffect(() => {
    let ignore = false;
    async function fetchRoomAndGame() {
      setLoading(true);
      const { data: roomData } = await supabase.from('rooms').select('*').eq('id', roomId).maybeSingle();
      setRoom(roomData);
      let { data: gameData } = await supabase.from('game_states').select('*').eq('room_id', roomId).maybeSingle();
      // Só cria o tabuleiro se ambos estiverem prontos e o jogo ainda não existir
      if (!gameData && roomData && roomData.status === 'playing' && roomData.ready1 && roomData.ready2) {
        const size = defaultSize;
        const mines = defaultMines;
        let b = createEmptyBoard(size);
        b = placeMines(b, mines);
        b = fillAdjacents(b);
        const currentTurn = Math.random() < 0.5 ? roomData.player1 : roomData.player2;
        await supabase.from('rooms').update({ current_turn: currentTurn, score1: 0, score2: 0 }).eq('id', roomId);
        const { data: created } = await supabase.from('game_states').insert([{ room_id: roomId, board: b }]).select().maybeSingle();
        gameData = created;
      }
      if (!ignore) {
        setGameState(gameData);
        setLoading(false);
      }
    }
    fetchRoomAndGame();
    // Subscribe para updates em tempo real
    const roomSub = supabase
      .channel('room-status')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'rooms', filter: `id=eq.${roomId}` }, payload => {
        setRoom(prev => ({ ...prev, ...payload.new }));
      })
      .subscribe();
    const gameSub = supabase
      .channel('game-states-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'game_states', filter: `room_id=eq.${roomId}` }, payload => {
        setGameState(prev => ({ ...prev, ...payload.new }));
      })
      .subscribe();
    return () => {
      ignore = true;
      supabase.removeChannel(roomSub);
      supabase.removeChannel(gameSub);
    };
  }, [roomId]);

  // Função para marcar ou desmarcar o jogador como pronto
  async function togglePlayerReady() {
    if (!room) return;
    const field = user.id === room.player1 ? 'ready1' : 'ready2';
    const isReady = room[field];
    await supabase.from('rooms').update({ [field]: !isReady }).eq('id', roomId);
  }

  // Função para atualizar o board, alternar turno e pontuação
  async function updateBoard(newBoardObj, points = 0) {
    if (!room || room.current_turn !== user.id) return;
    setLoading(true);
    // Suporte para objeto { board, gameOver, win }
    let updates = { board: newBoardObj.board || newBoardObj, updated_at: new Date().toISOString() };
    if (typeof newBoardObj.gameOver !== 'undefined') updates.gameOver = newBoardObj.gameOver;
    if (typeof newBoardObj.win !== 'undefined') updates.win = newBoardObj.win;
    let nextTurn = room.player1 === room.current_turn ? room.player2 : room.player1;
    let scoreField = user.id === room.player1 ? 'score1' : 'score2';
    let insertHistoryError = null;
    // Se vitória, soma 1 ponto ao vencedor e registra no histórico
    if (updates.win === true) {
      // Vitória: quem abriu a última célula venceu
      const winnerId = user.id;
      let winnerScoreField = winnerId === room.player1 ? 'score1' : 'score2';
      await supabase.from('rooms').update({ [winnerScoreField]: (room[winnerScoreField] || 0) + 1 }).eq('id', roomId);
      const { error: insertError } = await supabase.from('room_history').insert({ room_id: roomId, winner_id: winnerId, played_at: new Date().toISOString() });
      if (insertError) insertHistoryError = insertError.message;
    } else if (updates.gameOver === true) {
      // Derrota: o adversário do jogador atual venceu
      const winnerId = user.id === room.player1 ? room.player2 : room.player1;
      let winnerScoreField = winnerId === room.player1 ? 'score1' : 'score2';
      await supabase.from('rooms').update({ [winnerScoreField]: (room[winnerScoreField] || 0) + 1 }).eq('id', roomId);
      const { error: insertError } = await supabase.from('room_history').insert({ room_id: roomId, winner_id: winnerId, played_at: new Date().toISOString() });
      if (insertError) insertHistoryError = insertError.message;
    } else if (points > 0) {
      await supabase.from('rooms').update({ [scoreField]: (room[scoreField] || 0) + points, current_turn: nextTurn }).eq('id', roomId);
    } else {
      await supabase.from('rooms').update({ current_turn: nextTurn }).eq('id', roomId);
    }
    const { data, error } = await supabase
      .from('game_states')
      .update(updates)
      .eq('room_id', roomId)
      .select()
      .maybeSingle();
    setGameState(data); // feedback imediato para quem jogou
    setError(error ? error.message : insertHistoryError || '');
    setLoading(false);
  }

  // Função para reiniciar a partida online
  async function restartOnlineGame(size = 8, mines = 10) {
    if (!room) return;
    let b = createEmptyBoard(size);
    b = placeMines(b, mines);
    b = fillAdjacents(b);
    const currentTurn = Math.random() < 0.5 ? room.player1 : room.player2;
    // Limpa o gameState antes de criar novo jogo
    await supabase.from('game_states').delete().eq('room_id', roomId);
    await supabase.from('rooms').update({ current_turn: currentTurn, score1: 0, score2: 0 }).eq('id', roomId);
    await supabase.from('game_states').insert({ room_id: roomId, board: b, gameOver: false, win: false });
    setLastConfig({ size, mines });
    setShowConfigModal(false);
  }

  // Fetch and aggregate room_history for the room
  useEffect(() => {
    async function fetchVictoryHistory() {
      const { data: history } = await supabase
        .from('room_history')
        .select('winner_id')
        .eq('room_id', roomId);
      if (history) {
        const counts = {};
        for (const row of history) {
          counts[row.winner_id] = (counts[row.winner_id] || 0) + 1;
        }
        setVictoryHistory(counts);
      }
    }
    fetchVictoryHistory();
    // Listen for new matches (polling or subscribe)
    const interval = setInterval(fetchVictoryHistory, 3000); // Poll every 3s
    return () => clearInterval(interval);
  }, [roomId]);

  // Inicia a partida automaticamente quando os dois jogadores estiverem prontos (ready1 e ready2).
  useEffect(() => {
    if (!room) return;
    // Se ambos estão prontos e o jogo ainda não foi criado, inicia o countdown
    if (room.ready1 && room.ready2 && (!gameState || gameState.gameOver || gameState.win)) {
      if (startCountdown === null) {
        setStartCountdown(5);
        let countdown = 5;
        const interval = setInterval(() => {
          countdown--;
          setStartCountdown(countdown);
          if (countdown === 0) {
            clearInterval(interval);
            setStartCountdown(null);
            // Só o player1 inicia a partida para evitar múltiplas criações
            if (user.id === room.player1) {
              // Limpa o gameState antes de criar novo jogo
              setGameState(null);
              setTimeout(() => {
                restartOnlineGame(lastConfig.size, lastConfig.mines);
              }, 200);
            }
          }
        }, 1000);
        return () => clearInterval(interval);
      }
    } else {
      setStartCountdown(null);
    }
  }, [room?.ready1, room?.ready2, gameState]);

  // Atualiza lastFinishedGame quando a partida termina
  useEffect(() => {
    if (gameState && (gameState.gameOver || gameState.win)) {
      setLastFinishedGame(gameState);
    }
    // Se iniciou nova partida, limpa o lastFinishedGame
    if (gameState && !gameState.gameOver && !gameState.win) {
      setLastFinishedGame(null);
    }
  }, [gameState]);

  // Adiciona log para depuração de desmontagem
  useEffect(() => {
    return () => {
      console.log('OnlineGame desmontado. Isso só deve acontecer ao sair da sala!');
    };
  }, []);

  if (loading || !room) return <div style={{ color: 'var(--color5)', textAlign: 'center', marginTop: 40 }}>Carregando jogo online...</div>;
  if (error) return <div style={{ color: 'red', textAlign: 'center', marginTop: 40 }}>{error}</div>;

  // Se ainda não estão prontos, mostra tela de confirmação com layout padronizado do MemoryOnlineGame.jsx
  if (!room.ready1 || !room.ready2 || ((!gameState || startCountdown) && !lastFinishedGame)) {
    // Layout padronizado
    const player1Name = room.player1_name || (room.player1 ? room.player1.slice(0, 8) : 'Aguardando');
    const player2Name = room.player2_name || (room.player2 ? room.player2.slice(0, 8) : 'Aguardando');
    const slots = [
      { id: room.player1, name: player1Name, ready: room.ready1 },
      { id: room.player2, name: player2Name, ready: room.ready2 }
    ];
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--color1)', padding: 0, margin: 0 }}>
        <div style={{ background: 'var(--color2)', borderRadius: 24, boxShadow: '0 8px 32px 0 var(--color3)33', padding: '48px 32px 32px 32px', maxWidth: 420, width: '100%', textAlign: 'center' }}>
          <h2 style={{ fontSize: 28, fontWeight: 700, color: 'var(--color5)', marginBottom: 8, letterSpacing: 1 }}>Sala #{room.id}</h2>
          <div style={{ marginBottom: 18, color: 'var(--color4)', fontWeight: 700, fontSize: 18 }}>Aguardando jogadores ficarem prontos...</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16, marginBottom: 18 }}>
            {slots.map((slot, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 16, background: slot.id ? 'var(--color1)' : 'var(--color1)44', borderRadius: 10, padding: '10px 18px', boxShadow: slot.id ? `0 2px 8px var(--color3)22` : 'none', border: slot.id ? `2px solid var(--color3)55` : '2px dashed #444', minHeight: 54, position: 'relative', transition: 'box-shadow 0.2s, border 0.2s' }}>
                <span style={{ fontWeight: 700, color: slot.id ? 'var(--color4)' : '#888', fontSize: 17, minWidth: 90 }}>{slot.name}</span>
                {slot.id ? (
                  <span style={{ fontSize: 17, fontWeight: 600, color: slot.ready ? '#22c55e' : 'var(--color4)', marginLeft: 6 }}>
                    {slot.ready ? '✅ Pronto' : '⏳ Aguardando'}
                  </span>
                ) : (
                  <span style={{ color: '#888', fontSize: 15, marginLeft: 6 }}>Vazio</span>
                )}
                {slot.id === user.id && (
                  <button
                    onClick={togglePlayerReady}
                    style={{ marginLeft: 'auto', background: slot.ready ? 'linear-gradient(90deg,var(--color4) 60%,#22c55e 100%)' : 'linear-gradient(90deg,var(--color4) 60%,var(--color3) 100%)', color: slot.ready ? 'var(--color1)' : 'var(--color5)', border: 'none', borderRadius: 7, padding: '7px 22px', fontSize: '1rem', fontWeight: 700, cursor: 'pointer', boxShadow: slot.ready ? '0 2px 8px #22c55e44' : '0 2px 8px var(--color4)44', transition: 'background 0.2s, color 0.2s' }}
                  >
                    {slot.ready ? 'Cancelar' : 'Estou pronto!'}
                  </button>
                )}
              </div>
            ))}
          </div>
          {startCountdown && (
            <div style={{ fontSize: 22, color: 'var(--color4)', margin: '18px 0', fontWeight: 700 }}>
              Partida começando em {startCountdown} segundo{startCountdown > 1 ? 's' : ''}...
            </div>
          )}
          <button onClick={onLeave} style={{ marginTop: 32, background: 'var(--color4)', color: 'var(--color1)', border: 'none', borderRadius: 6, padding: '8px 18px', fontWeight: 600, fontSize: '1rem', cursor: 'pointer' }}>
            Sair da Sala
          </button>
        </div>
      </div>
    );
  }

  // Ambos prontos, inicia o jogo de turnos
  // Adiciona seletores de cor para cada jogador
  const isPlayer1 = user.id === room.player1;
  const isPlayer2 = user.id === room.player2;
  const color1 = room.color1 || 'rgba(142,149,240,1)';
  const color2 = room.color2 || 'rgba(179,255,185,1)';

  async function handleColorChange(e) {
    const color = e.target.value;
    if (isPlayer1) {
      await supabase.from('rooms').update({ color1: color }).eq('id', roomId);
    } else if (isPlayer2) {
      await supabase.from('rooms').update({ color2: color }).eq('id', roomId);
    }
  }

  return (
    <div>
      <GameConfigModal
        show={showConfigModal}
        onClose={() => setShowConfigModal(false)}
        onStart={restartOnlineGame}
        defaultSize={lastConfig.size}
        defaultMines={lastConfig.mines}
      />
      <button onClick={onLeave} style={{ margin: 16, background: 'var(--color3)', color: 'var(--color5)', border: 'none', borderRadius: 6, padding: '8px 18px', fontWeight: 600, fontSize: '1rem', cursor: 'pointer' }}>Sair da Sala</button>
      <div style={{ color: 'var(--color5)', marginBottom: 12 }}>
        <b>Vez de:</b> {room.current_turn === user.id ? 'Você' : 'Oponente'}<br/>
        <b>Pontuação (sessão atual):</b> Você: {user.id === room.player1 ? room.score1 : room.score2} | Oponente: {user.id === room.player1 ? room.score2 : room.score1}<br/>
        <b>Vitórias históricas:</b> {(() => {
          const v1 = victoryHistory[room.player1] || 0;
          const v2 = victoryHistory[room.player2] || 0;
          if (v1 > v2) {
            return `${room.player1_name || 'Jogador 1'} está ganhando! (${v1} x ${v2})`;
          } else if (v2 > v1) {
            return `${room.player2_name || 'Jogador 2'} está ganhando! (${v2} x ${v1})`;
          } else if (v1 === 0 && v2 === 0) {
            return 'Nenhuma vitória ainda.';
          } else {
            return `Empate! (${v1} x ${v2})`;
          }
        })()}
      </div>
      <div style={{ marginBottom: 16 }}>
        {isPlayer1 && (
          <label style={{ marginRight: 16 }}>
            Sua cor: <input type="color" value={color1} onChange={handleColorChange} style={{ verticalAlign: 'middle', width: 32, height: 32, border: 'none', background: 'none' }} />
          </label>
        )}
        {isPlayer2 && (
          <label>
            Sua cor: <input type="color" value={color2} onChange={handleColorChange} style={{ verticalAlign: 'middle', width: 32, height: 32, border: 'none', background: 'none' }} />
          </label>
        )}
      </div>
      <Minesweeper
        online
        board={gameState || lastFinishedGame} // Usa o último gameState finalizado se não houver um ativo
        setBoard={updateBoard}
        user={user}
        roomId={roomId}
        currentTurn={room.current_turn}
        room={room}
      />
      {(gameState?.gameOver || gameState?.win || lastFinishedGame) && (
        <button onClick={() => setShowConfigModal(true)} style={{ marginTop: 24, background: 'var(--color4)', color: 'var(--color1)', border: 'none', borderRadius: 6, padding: '10px 22px', fontSize: '1.1rem', cursor: 'pointer', fontWeight: 700 }}>
          Restart 
        </button>
      )}
    </div>
  );
}
