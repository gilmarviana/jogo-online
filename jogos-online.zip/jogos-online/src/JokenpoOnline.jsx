import React, { useState, useEffect, useRef } from 'react';
import supabase from './supabaseClient';

const options = [
  { name: 'Pedra', emoji: '✊' },
  { name: 'Papel', emoji: '✋' },
  { name: 'Tesoura', emoji: '✌️' },
];

export default function JokenpoOnline({ user, roomId: propRoomId, onLeave }) {
  const [roomId, setRoomId] = useState(propRoomId || null);
  const [room, setRoom] = useState(null);
  const [choices, setChoices] = useState([null, null]);
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(true);
  const [playerIndex, setPlayerIndex] = useState(0);
  const [ready, setReady] = useState(false);
  const [startCountdown, setStartCountdown] = useState(null);
  const countdownRef = useRef(null);
  const [joining, setJoining] = useState(false);
  const [rooms, setRooms] = useState([]);
  const [lobby, setLobby] = useState(!propRoomId);
  // Timer de escolha
  const [choiceTimer, setChoiceTimer] = useState(null);
  const choiceTimerRef = useRef(null);

  // Busca salas disponíveis para entrar
  useEffect(() => {
    if (!lobby) return;
    fetchRooms();
    const channel = supabase.channel('jokenpo-rooms-list')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'jokenpo_rooms' }, fetchRooms)
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [lobby]);

  async function fetchRooms() {
    const { data, error } = await supabase.from('jokenpo_rooms').select('*').order('created_at', { ascending: false });
    if (!error) setRooms(data);
  }

  // Entra em sala existente
  async function handleJoinRoom(room) {
    setJoining(true);
    if (!room.player2) {
      await supabase.from('jokenpo_rooms').update({
        player2: user.id,
        player2_name: user.user_metadata?.name || user.email,
        player2_ready: false,
        status: 'waiting',
      }).eq('id', room.id);
    }
    setRoomId(room.id);
    setLobby(false);
    setJoining(false);
  }

  // Lógica da sala/lobby/partida
  useEffect(() => {
    if (!roomId) return;
    fetchRoom();
    const channel = supabase.channel('jokenpo-' + roomId)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'jokenpo_rooms', filter: `id=eq.${roomId}` }, payload => {
        if (payload.new) setRoom(payload.new);
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [roomId]);

  async function fetchRoom() {
    setLoading(true);
    const { data, error } = await supabase.from('jokenpo_rooms').select('*').eq('id', roomId).maybeSingle();
    if (!error) setRoom(data);
    setLoading(false);
  }

  // Ready/contagem/início
  useEffect(() => {
    if (!room || !user) return;
    setPlayerIndex(room.player1 === user.id ? 0 : 1);
    setChoices([room.choice1, room.choice2]);
    if (room.choice1 !== null && room.choice2 !== null) {
      setResult(play(room.choice1, room.choice2));
    } else {
      setResult('');
    }
    // Contagem regressiva e início
    const readyCount = (room.player1_ready ? 1 : 0) + (room.player2_ready ? 1 : 0);
    const playersCount = (room.player1 ? 1 : 0) + (room.player2 ? 1 : 0);
    const isOwner = user && room.player1 === user.id;
    // Inicia contagem para todos quando ambos estiverem prontos
    if (playersCount === 2 && readyCount === 2 && room.status === 'waiting') {
      if (startCountdown === null && !countdownRef.current) {
        setStartCountdown(3);
        let countdown = 3;
        countdownRef.current = setInterval(() => {
          countdown--;
          setStartCountdown(countdown);
          if (countdown === 0) {
            clearInterval(countdownRef.current);
            countdownRef.current = null;
            setStartCountdown(null);
          }
        }, 1000);
      }
    } else {
      setStartCountdown(null);
      if (countdownRef.current) {
        clearInterval(countdownRef.current);
        countdownRef.current = null;
      }
    }
    // Owner inicia a partida ao final da contagem
    if (playersCount === 2 && readyCount === 2 && room.status === 'waiting' && startCountdown === 0 && isOwner) {
      supabase.from('jokenpo_game_states').upsert({
        room_id: roomId,
        state: { score1: 0, score2: 0, round: 1 }
      });
      supabase.from('jokenpo_rooms').update({ status: 'playing' }).eq('id', roomId);
    }
    return () => {
      if (countdownRef.current) {
        clearInterval(countdownRef.current);
        countdownRef.current = null;
      }
    };
  }, [room, startCountdown, roomId, user]);

  // Inicia o timer de 5s quando status for 'playing' e pelo menos um dos choices for null
  useEffect(() => {
    if (room && room.status === 'playing' && (room.choice1 === null || room.choice2 === null)) {
      if (choiceTimer === null && !choiceTimerRef.current) {
        setChoiceTimer(5);
        let timer = 5;
        choiceTimerRef.current = setInterval(async () => {
          timer--;
          setChoiceTimer(timer);
          if (timer === 0) {
            clearInterval(choiceTimerRef.current);
            choiceTimerRef.current = null;
            setChoiceTimer(null);
            // Se o jogador não escolheu, ele perde automaticamente
            if (choices[playerIndex] === null) {
              // Marca derrota para quem não escolheu
              const field = playerIndex === 0 ? 'choice1' : 'choice2';
              await supabase.from('jokenpo_rooms').update({ [field]: -1 }).eq('id', roomId);
            }
          }
        }, 1000);
      }
    } else {
      setChoiceTimer(null);
      if (choiceTimerRef.current) {
        clearInterval(choiceTimerRef.current);
        choiceTimerRef.current = null;
      }
    }
    return () => {
      if (choiceTimerRef.current) {
        clearInterval(choiceTimerRef.current);
        choiceTimerRef.current = null;
      }
    };
  }, [room, choices, playerIndex]);

  async function handleReady() {
    if (!room || !user) return;
    const isPlayer1 = room.player1 === user.id;
    const field = isPlayer1 ? 'player1_ready' : 'player2_ready';
    await supabase.from('jokenpo_rooms').update({ [field]: !room[field] }).eq('id', roomId);
  }

  // Permite clicar apenas se:
  // - status é 'playing'
  // - é a sua vez de escolher (choices[playerIndex] === null)
  // - o valor no banco também está null (room[field] === null)
  // - o timer está rodando
  async function handleChoice(i) {
    if (!room) return;
    if (room.status !== 'playing') return;
    const field = playerIndex === 0 ? 'choice1' : 'choice2';
    if (choices[playerIndex] !== null) return; // impede duplo clique local
    if (room[field] !== null) return; // impede se já foi salvo no banco
    if (choiceTimer === null) return; // impede se timer não está ativo
    await supabase.from('jokenpo_rooms').update({ [field]: i }).eq('id', roomId);
  }

  async function handleRestart() {
    await supabase.from('jokenpo_rooms').update({ choice1: null, choice2: null }).eq('id', roomId);
  }

  function play(p1, p2) {
    // Se algum jogador não escolheu (valor -1), ele perde
    if (p1 === -1 && p2 === -1) return 'Ninguém escolheu!';
    if (p1 === -1) return 'Jogador 2 venceu! (Jogador 1 não escolheu)';
    if (p2 === -1) return 'Jogador 1 venceu! (Jogador 2 não escolheu)';
    if (p1 === p2) return 'Empate!';
    if (
      (p1 === 0 && p2 === 2) ||
      (p1 === 1 && p2 === 0) ||
      (p1 === 2 && p2 === 1)
    ) return 'Jogador 1 venceu!';
    return 'Jogador 2 venceu!';
  }

  // Remover lobby/lista de salas: só exibe tela de jogo
  if (loading || !room) return <div style={{ color: 'var(--color5)', textAlign: 'center', marginTop: 40 }}>Carregando sala...</div>;

  // PARTIDA
  const isPlayer1 = room.player1 === user.id;
  const isPlayer2 = room.player2 === user.id;
  const myReadyPlaying = isPlayer1 ? room.player1_ready_playing : room.player2_ready_playing;
  const otherReadyPlaying = isPlayer1 ? room.player2_ready_playing : room.player1_ready_playing;
  const otherName = isPlayer1 ? room.player2_name : room.player1_name;
  const canChoose = myReadyPlaying && otherReadyPlaying && room.status === 'playing' && choiceTimer !== null;

  async function handleReadyPlaying() {
    if (!room || !user) return;
    const field = isPlayer1 ? 'player1_ready_playing' : 'player2_ready_playing';
    await supabase.from('jokenpo_rooms').update({ [field]: !room[field] }).eq('id', roomId);
  }

  return (
    <div className={window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'ion-dark' : 'ion-light'}
      style={{ minHeight: '100vh', background: 'var(--color1)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', transition: 'background 0.3s' }}>
      <h2 style={{ color: 'var(--color5)', fontWeight: 800, fontSize: 32, marginBottom: 16 }}>Jokenpô Online</h2>
      <div style={{ background: 'var(--color2)', borderRadius: 16, padding: 24, boxShadow: '0 2px 12px #0002', border: '2px solid var(--color4)', marginBottom: 24, minWidth: 260 }}>
        <div style={{ color: 'var(--color5)', fontWeight: 700, marginBottom: 8 }}>Você é o {playerIndex === 0 ? 'Jogador 1' : 'Jogador 2'}</div>
        
          
        {/* ESCOLHA SÓ LIBERADA QUANDO AMBOS PRONTOS */}
        <div style={{ display: 'flex', gap: 16, justifyContent: 'center' }}>
          {options.map((opt, i) => (
            <button key={i} onClick={() => handleChoice(i)}
              disabled={choices[playerIndex] !== null || room.status !== 'playing' || choiceTimer === null}
              style={{ fontSize: 32, padding: 12, borderRadius: 8, border: '2px solid var(--color4)', background: 'var(--color3)', color: 'var(--color5)', cursor: (choices[playerIndex] !== null || room.status !== 'playing' || choiceTimer === null) ? 'not-allowed' : 'pointer', margin: 2, opacity: (choices[playerIndex] !== null || room.status !== 'playing' || choiceTimer === null) ? 0.6 : 1 }}>
              {opt.emoji}
            </button>
          ))}
        </div>
      </div>
      <div style={{ color: 'var(--color5)', fontWeight: 700, fontSize: 22, marginBottom: 16 }}>
        {room.status === 'playing' && (room.choice1 === null || room.choice2 === null) && (
          <div style={{ color: '#f59e42', fontWeight: 800, fontSize: 20, marginBottom: 8 }}>
            Escolha seu ícone! <span style={{ fontVariantNumeric: 'tabular-nums', fontWeight: 900 }}>{choiceTimer !== null}</span>
          </div>
        )}
        {choices[0] !== null && choices[1] !== null &&
          (choices[0] === -1 || choices[1] === -1 || (options[choices[0]] && options[choices[1]])) && (
            <>
              {choices[0] === -1 || choices[1] === -1 ? (
                <div style={{ color: '#ef4444', fontWeight: 800, fontSize: 20, marginBottom: 8 }}>
                  {choices[0] === -1 ? 'Jogador 1 não escolheu' : ''}
                  {choices[0] === -1 && choices[1] === -1 ? ' e ' : ''}
                  {choices[1] === -1 ? 'Jogador 2 não escolheu' : ''}
                </div>
              ) : (
                <>
                  Jogador 1: {options[choices[0]]?.emoji} &nbsp;|&nbsp; Jogador 2: {options[choices[1]]?.emoji}
                </>
              )}
              <div style={{ marginTop: 12 }}>{result}</div>
            </>
          )}
      </div>
      <div style={{ display: 'flex', gap: 16 }}>
        <button onClick={handleRestart}
          style={{ background: 'none', color: 'var(--color5)', border: '2px solid var(--color5)', borderRadius: 8, padding: '8px 28px', fontWeight: 700, fontSize: 16, marginTop: 8, cursor: 'pointer', opacity: 0.85, transition: 'background 0.15s, border 0.2s' }}>
          Reiniciar
        </button>
        <button onClick={onLeave}
          style={{ background: 'none', color: 'var(--color5)', border: '2px solid var(--color5)', borderRadius: 8, padding: '8px 28px', fontWeight: 700, fontSize: 16, marginTop: 8, cursor: 'pointer', opacity: 0.85, transition: 'background 0.15s, border 0.2s' }}>
          Sair
        </button>
      </div>
    </div>
  );
}
