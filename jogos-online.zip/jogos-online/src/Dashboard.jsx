import React from 'react';
import './Dashboard.css';

export default function Dashboard({ onLogout, onSelectGame }) {
  return (
    <div className="dashboard-container" style={{ minHeight: '100vh', background: 'var(--color1)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ background: 'var(--color2)', borderRadius: 18, padding: '40px 36px 32px', maxWidth: 600, width: '100%', boxShadow: '0 4px 32px var(--color3)44', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 24, justifyContent: 'center' }}>
          <img src="https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f3ae.png" alt="Jogos" style={{ width: 40, height: 40 }} />
          <h1 style={{ color: 'var(--color4)', fontWeight: 800, fontSize: 32, letterSpacing: 1, margin: 0, textShadow: '0 2px 8px var(--color1)88' }}>Seleção de Jogos</h1>
        </div>
        <div className="games-list" style={{ display: 'flex', gap: 32, flexWrap: 'wrap', justifyContent: 'center', marginBottom: 24 }}>
          <div className="game-card" onClick={() => onSelectGame('minesweeper')} style={{
            background: 'linear-gradient(135deg, var(--color2) 60%, var(--color3) 100%)', borderRadius: 16, padding: '32px 26px', minWidth: 200, maxWidth: 240, boxShadow: '0 6px 32px var(--color3)33', cursor: 'pointer', transition: 'transform 0.18s, box-shadow 0.18s',
            display: 'flex', flexDirection: 'column', alignItems: 'center', border: '2px solid var(--color3)55', position: 'relative', overflow: 'hidden',
          }}
          onMouseOver={e => { e.currentTarget.style.transform = 'scale(1.05)'; e.currentTarget.style.boxShadow = '0 12px 36px var(--color3)77'; }}
          onMouseOut={e => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.boxShadow = '0 6px 32px var(--color3)33'; }}
          >
            <div style={{ position: 'absolute', top: 0, right: 0, width: 60, height: 60, background: 'radial-gradient(circle at 80% 20%, var(--color3)44 0%, transparent 80%)', zIndex: 0 }} />
            <img src="https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f4a3.png" alt="Campo Minado" style={{ width: 52, height: 52, marginBottom: 12, zIndex: 1 }} />
            <h2 style={{ color: 'var(--color3)', fontWeight: 800, fontSize: 20, marginBottom: 6, zIndex: 1, textShadow: '0 2px 8px var(--color1)88' }}>Campo Minado</h2>
            <p style={{ color: 'var(--color5)', fontSize: 14, textAlign: 'center', zIndex: 1 }}>Encontre todas as minas sem explodir!</p>
          </div>
          <div className="game-card" onClick={() => onSelectGame('memory-mode')} style={{
            background: 'linear-gradient(135deg, var(--color2) 60%, var(--color4) 100%)', borderRadius: 16, padding: '32px 26px', minWidth: 200, maxWidth: 240, boxShadow: '0 6px 32px var(--color4)33', cursor: 'pointer', transition: 'transform 0.18s, box-shadow 0.18s',
            display: 'flex', flexDirection: 'column', alignItems: 'center', border: '2px solid var(--color4)55', position: 'relative', overflow: 'hidden',
          }}
          onMouseOver={e => { e.currentTarget.style.transform = 'scale(1.05)'; e.currentTarget.style.boxShadow = '0 12px 36px var(--color4)77'; }}
          onMouseOut={e => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.boxShadow = '0 6px 32px var(--color4)33'; }}
          >
            <div style={{ position: 'absolute', top: 0, right: 0, width: 60, height: 60, background: 'radial-gradient(circle at 80% 20%, var(--color4)44 0%, transparent 80%)', zIndex: 0 }} />
            <img src="https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f9e9.png" alt="Jogo da Memória" style={{ width: 52, height: 52, marginBottom: 12, zIndex: 1 }} />
            <h2 style={{ color: 'var(--color4)', fontWeight: 800, fontSize: 20, marginBottom: 6, zIndex: 1, textShadow: '0 2px 8px var(--color1)88' }}>Jogo da Memória</h2>
            <p style={{ color: 'var(--color5)', fontSize: 14, textAlign: 'center', zIndex: 1 }}>Encontre todos os pares de cartas antes dos outros jogadores!</p>
          </div>
          <div className="game-card" onClick={() => onSelectGame('hangman')} style={{
            background: 'linear-gradient(135deg, var(--color2) 60%, var(--color5) 100%)', borderRadius: 16, padding: '32px 26px', minWidth: 200, maxWidth: 240, boxShadow: '0 6px 32px var(--color5)33', cursor: 'pointer', transition: 'transform 0.18s, box-shadow 0.18s',
            display: 'flex', flexDirection: 'column', alignItems: 'center', border: '2px solid var(--color5)55', position: 'relative', overflow: 'hidden',
          }}
          onMouseOver={e => { e.currentTarget.style.transform = 'scale(1.05)'; e.currentTarget.style.boxShadow = '0 12px 36px var(--color5)77'; }}
          onMouseOut={e => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.boxShadow = '0 6px 32px var(--color5)33'; }}
          >
            <div style={{ position: 'absolute', top: 0, right: 0, width: 60, height: 60, background: 'radial-gradient(circle at 80% 20%, var(--color5)44 0%, transparent 80%)', zIndex: 0 }} />
            <img src="https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f3ac.png" alt="Jogo da Forca" style={{ width: 52, height: 52, marginBottom: 12, zIndex: 1 }} />
            <h2 style={{ color: 'var(--color5)', fontWeight: 800, fontSize: 20, marginBottom: 6, zIndex: 1, textShadow: '0 2px 8px var(--color1)88' }}>Jogo da Forca</h2>
            <p style={{ color: 'var(--color4)', fontSize: 14, textAlign: 'center', zIndex: 1 }}>Adivinhe a palavra antes que o boneco seja enforcado!</p>
          </div>
          <div className="game-card" onClick={() => onSelectGame('tic-tac-toe')} style={{
            background: 'linear-gradient(135deg, var(--color2) 60%, var(--color1) 100%)', borderRadius: 16, padding: '32px 26px', minWidth: 200, maxWidth: 240, boxShadow: '0 6px 32px var(--color1)33', cursor: 'pointer', transition: 'transform 0.18s, box-shadow 0.18s',
            display: 'flex', flexDirection: 'column', alignItems: 'center', border: '2px solid var(--color1)55', position: 'relative', overflow: 'hidden',
          }}
          onMouseOver={e => { e.currentTarget.style.transform = 'scale(1.05)'; e.currentTarget.style.boxShadow = '0 12px 36px var(--color1)77'; }}
          onMouseOut={e => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.boxShadow = '0 6px 32px var(--color1)33'; }}
          >
            <div style={{ position: 'absolute', top: 0, right: 0, width: 60, height: 60, background: 'radial-gradient(circle at 80% 20%, var(--color1)44 0%, transparent 80%)', zIndex: 0 }} />
            <img src="https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/274c.png" alt="Jogo da Velha" style={{ width: 52, height: 52, marginBottom: 12, zIndex: 1 }} />
            <h2 style={{ color: 'var(--color1)', fontWeight: 800, fontSize: 20, marginBottom: 6, zIndex: 1, textShadow: '0 2px 8px var(--color4)88' }}>Jogo da Velha</h2>
            <p style={{ color: 'var(--color4)', fontSize: 14, textAlign: 'center', zIndex: 1 }}>2 jogadores ou contra o computador!</p>
          </div>
        </div>
        <button onClick={onLogout} style={{ background: 'linear-gradient(90deg,var(--color4) 60%,var(--color3) 100%)', color: 'var(--color1)', border: 'none', borderRadius: 8, padding: '10px 28px', fontWeight: 700, fontSize: '1.08rem', cursor: 'pointer', boxShadow: '0 2px 8px var(--color4)44', transition: 'background 0.2s', marginTop: 8 }}>Sair</button>
      </div>
    </div>
  );
}
