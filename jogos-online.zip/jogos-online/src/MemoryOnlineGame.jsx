import { useEffect, useState, useRef } from 'react';
import supabase from './supabaseClient';
import './MemoryGame.css';

const CARD_IMAGES = [
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f436.png', matched: false },
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f431.png', matched: false },
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f42d.png', matched: false },
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f439.png', matched: false },
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f430.png', matched: false },
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f98a.png', matched: false },
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f43c.png', matched: false },
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f428.png', matched: false },
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f42f.png', matched: false },
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f981.png', matched: false },
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f42e.png', matched: false },
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f437.png', matched: false },
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f43d.png', matched: false },
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f438.png', matched: false },
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f435.png', matched: false },
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f648.png', matched: false },
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f649.png', matched: false },
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f64a.png', matched: false },
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f41d.png', matched: false },
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f41b.png', matched: false },
];

// Jogadores agora usam cores de destaque diferentes do tema
const PLAYER_COLORS = [
  '#e11d48', // vermelho destaque
  '#f59e42', // laranja destaque
  '#38bdf8', // azul claro destaque
  '#22c55e'  // verde destaque
];

const DEFAULT_AVATARS = [
  'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f600.png',
  'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f60a.png',
  'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f60e.png',
  'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f609.png',
];

function shuffleCards(pairsCount) {
  const selected = CARD_IMAGES.slice(0, pairsCount);
  const shuffled = [...selected, ...selected]
    .map(card => ({ ...card, id: Math.random() }))
    .sort(() => Math.random() - 0.5);
  return shuffled;
}

function getPlayerIndex(room, userId) {
  if (room.player1 === userId) return 0;
  if (room.player2 === userId) return 1;
  if (room.player3 === userId) return 2;
  if (room.player4 === userId) return 3;
  return 0;
}

export default function MemoryOnlineGame({ user, roomId, onLeave }) {
  const [room, setRoom] = useState(null);
  const [gameState, setGameState] = useState(null);
  const [loading, setLoading] = useState(true);
  const [disabled, setDisabled] = useState(false);
  const [choiceOne, setChoiceOne] = useState(null);
  const [choiceTwo, setChoiceTwo] = useState(null);
  const [turns, setTurns] = useState(0);
  const [currentPlayer, setCurrentPlayer] = useState(0);
  const [scores, setScores] = useState([0,0,0,0]);
  const [playerNames, setPlayerNames] = useState(['','','','']);
  const [playerAvatars, setPlayerAvatars] = useState(DEFAULT_AVATARS);
  const [isGameFinished, setIsGameFinished] = useState(false);
  const [pairsCount, setPairsCount] = useState(6);
  // Countdown para início da partida
  const [startCountdown, setStartCountdown] = useState(null);
  const countdownRef = useRef(null);
  const [showPairsModal, setShowPairsModal] = useState(false);
  const [selectedPairs, setSelectedPairs] = useState(pairsCount);

  // Busca estado da sala e do jogo
  useEffect(() => {
    fetchRoom();
    fetchGameState();
    const channel = supabase.channel('memory-game-' + roomId)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'memory_rooms', filter: `id=eq.${roomId}` }, payload => {
        if (payload.new) setRoom(payload.new);
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'memory_game_states', filter: `room_id=eq.${roomId}` }, payload => {
        if (payload.new) setGameState(payload.new.state);
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
    // eslint-disable-next-line
  }, [roomId]);

  async function fetchRoom() {
    setLoading(true);
    const { data, error } = await supabase.from('memory_rooms').select('*').eq('id', roomId).maybeSingle();
    if (!error) setRoom(data);
    setLoading(false);
  }

  async function fetchGameState() {
    const { data, error } = await supabase.from('memory_game_states').select('*').eq('room_id', roomId).maybeSingle();
    if (data && data.state) setGameState(data.state);
  }

  // Lógica de contagem regressiva e início da partida (apenas player1 pode iniciar)
  useEffect(() => {
    if (!room) return;
    const slots = ['player1', 'player2', 'player3', 'player4'];
    const playerIdsArr = slots.map(slot => room[slot]);
    const readyArr = slots.map(slot => room[slot + '_ready']);
    const playersCount = playerIdsArr.filter(Boolean).length;
    const readyCount = readyArr.filter(Boolean).length;
    // Corrigido: se mais de 2 jogadores, todos devem estar prontos para iniciar
    const canStart = playersCount === 2 ? (readyCount === 2) : (playersCount > 2 ? (readyCount === playersCount) : false);
    if (playersCount >= 2 && canStart && !gameState) {
      if (startCountdown === null && !countdownRef.current) {
        setStartCountdown(5);
        let countdown = 5;
        countdownRef.current = setInterval(async () => {
          countdown--;
          setStartCountdown(countdown);
          if (countdown === 0) {
            clearInterval(countdownRef.current);
            countdownRef.current = null;
            setStartCountdown(null);
            // Após a contagem, executa a ação do forçar entrada (apenas player1)
            if (room && user && room.player1 === user.id && !gameState) {
              const activePlayers = slots.map((slot, i) => ({
                id: room[slot],
                name: room[slot + '_name'] || `Jogador ${i+1}`,
                avatar: DEFAULT_AVATARS[i],
              })).filter(p => p.id);
              const uniquePlayers = activePlayers.filter((p, idx, arr) => arr.findIndex(x => x.id === p.id) === idx);
              const playerCount = uniquePlayers.length;
              const playerNamesArr = uniquePlayers.map(p => p.name);
              const playerAvatarsArr = uniquePlayers.map(p => p.avatar);
              const cards = shuffleCards(pairsCount);
              const initialState = {
                cards,
                turns: 0,
                currentPlayer: 0,
                scores: Array(playerCount).fill(0),
                playerNames: playerNamesArr,
                playerAvatars: playerAvatarsArr,
                choiceOne: null,
                choiceTwo: null,
                disabled: false,
                isGameFinished: false,
                pairsCount,
              };
              await supabase.from('memory_game_states').upsert({ room_id: roomId, state: initialState });
            }
          }
        }, 1000);
      }
    } else {
      setStartCountdown(null);
      if (countdownRef.current) {
        clearInterval(countdownRef.current);
        countdownRef.current = null;
      }
    }
    return () => {
      if (countdownRef.current) {
        clearInterval(countdownRef.current);
        countdownRef.current = null;
      }
    };
  }, [room, user, roomId, gameState, pairsCount]);

  async function handlePlayerReady() {
    if (!room || !user) return;
    const playerIndex = getPlayerIndex(room, user.id);
    const isReady = room[`player${playerIndex + 1}_ready`];
    await supabase.from('memory_rooms').update({ [`player${playerIndex + 1}_ready`]: !isReady }).eq('id', roomId);
  }

  async function fetchPlayerData() {
    if (!room) return;
    const slots = ['player1', 'player2', 'player3', 'player4'];
    const playerIdsArr = slots.map(slot => room[slot]);
    const activePlayers = playerIdsArr.filter(Boolean);
    const { data: playersData } = await supabase
      .from('users')
      .select('id, name, avatar')
      .in('id', activePlayers);
    const playerMap = Object.fromEntries(playersData.map(p => [p.id, p]));
    const playerNamesArr = playerIdsArr.map(id => playerMap[id]?.name || '');
    const playerAvatarsArr = playerIdsArr.map(id => playerMap[id]?.avatar || DEFAULT_AVATARS[playerIdsArr.indexOf(id)]);
    setPlayerNames(playerNamesArr);
    setPlayerAvatars(playerAvatarsArr);
  }

  // Efeito para buscar dados dos jogadores ao entrar na sala
  useEffect(() => {
    fetchPlayerData();
  }, [room]);

  // Efeito dedicado: quando a contagem chega a 0, player1 inicia o jogo
  useEffect(() => {
    if (startCountdown === 0 && room && user && room.player1 === user.id && room.status !== 'playing') {
      supabase.from('memory_rooms').update({ status: 'playing' }).eq('id', roomId);
      setStartCountdown(null); // previne múltiplas execuções
    }
  }, [startCountdown, room, user, roomId]);

  // Inicializa o jogo quando gameState não existe e sala está em playing
  useEffect(() => {
    // Garante que apenas os jogadores presentes no momento do início participem da partida
    if (room && room.status === 'playing' && !gameState) {
      // Determina jogadores ativos no momento exato do início
      const slots = ['player1', 'player2', 'player3', 'player4'];
      const activePlayers = slots.map((slot, i) => ({
        id: room[slot],
        name: room[slot + '_name'] || `Jogador ${i+1}`,
        avatar: DEFAULT_AVATARS[i],
      })).filter(p => p.id);
      // Remove duplicidade de jogadores (caso algum bug de slot)
      const uniquePlayers = activePlayers.filter((p, idx, arr) => arr.findIndex(x => x.id === p.id) === idx);
      const playerCount = uniquePlayers.length;
      const playerNamesArr = uniquePlayers.map(p => p.name);
      const playerAvatarsArr = uniquePlayers.map(p => p.avatar);
      const cards = shuffleCards(pairsCount);
      const initialState = {
        cards,
        turns: 0,
        currentPlayer: 0,
        scores: Array(playerCount).fill(0),
        playerNames: playerNamesArr,
        playerAvatars: playerAvatarsArr,
        choiceOne: null,
        choiceTwo: null,
        disabled: false,
        isGameFinished: false,
        pairsCount,
      };
      supabase.from('memory_game_states').upsert({ room_id: roomId, state: initialState });
    }
  }, [room, gameState, pairsCount, roomId]);

  // Sincroniza estado local com gameState
  useEffect(() => {
    if (!gameState) return;
    setTurns(gameState.turns);
    setCurrentPlayer(gameState.currentPlayer);
    setScores(gameState.scores);
    setPlayerNames(gameState.playerNames);
    setPlayerAvatars(gameState.playerAvatars);
    setIsGameFinished(gameState.isGameFinished);
    setPairsCount(gameState.pairsCount);
    setChoiceOne(gameState.choiceOne);
    setChoiceTwo(gameState.choiceTwo);
    setDisabled(gameState.disabled);
  }, [gameState]);

  // Sincroniza estado local com gameState em tempo real
  useEffect(() => {
    if (!roomId) return;
    // Canal realtime para gameState
    const channel = supabase.channel('memory-game-realtime-' + roomId)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'memory_game_states', filter: `room_id=eq.${roomId}` }, payload => {
        if (payload.new && payload.new.state) {
          setGameState(payload.new.state);
        }
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [roomId]);

  // Jogada: clique em carta
  async function handleChoice(card) {
    if (!gameState || disabled || isGameFinished) return;
    // Só permite ação se for a vez do usuário
    const myIndex = getPlayerIndex(room, user?.id);
    if (gameState.currentPlayer !== myIndex) return;
    // Corrige bug: compara por id, não por referência de objeto
    const flipped = card.matched || (gameState.choiceOne && card.id === gameState.choiceOne.id) || (gameState.choiceTwo && card.id === gameState.choiceTwo.id);
    if (flipped) return;
    let newState = { ...gameState };
    if (!gameState.choiceOne) {
      newState.choiceOne = card;
      await updateGameState(newState); // Atualiza imediatamente para todos verem a carta virando
      return;
    }
    if (!gameState.choiceTwo) {
      newState.choiceTwo = card;
      newState.disabled = true;
      await updateGameState(newState); // Atualiza imediatamente para todos verem a segunda carta virando
      // Verifica se é par
      if (gameState.choiceOne.src === card.src) {
        // Marca as cartas como matched e grava a cor do jogador que acertou
        const playerColor = PLAYER_COLORS[newState.currentPlayer];
        newState.cards = newState.cards.map(c =>
          c.src === card.src ? { ...c, matched: true, ownerColor: playerColor } : c
        );
        newState.scores = [...newState.scores];
        newState.scores[newState.currentPlayer] += 1;
        setTimeout(async () => {
          await updateGameState({
            ...newState,
            choiceOne: null,
            choiceTwo: null,
            disabled: false,
            isGameFinished: newState.cards.every(c => c.matched),
            turns: newState.turns + 1,
          });
        }, 800);
      } else {
        setTimeout(async () => {
          await updateGameState({
            ...newState,
            choiceOne: null,
            choiceTwo: null,
            disabled: false,
            currentPlayer: (newState.currentPlayer + 1) % newState.scores.length,
            turns: newState.turns + 1,
          });
        }, 1000);
      }
    }
  }

  async function updateGameState(state) {
    // Atualiza o estado no banco e todos recebem via realtime
    await supabase.from('memory_game_states').update({ state }).eq('room_id', roomId);
  }

  // Adiciona histórico de vitórias na sala
  async function addVictoryToHistory(winnerName, winnerId) {
    if (!room) return;
    // Cria ou atualiza o campo history (array de objetos {id, name, wins})
    let history = room.history || [];
    const idx = history.findIndex(h => h.id === winnerId);
    if (idx !== -1) {
      history[idx].wins += 1;
    } else {
      history.push({ id: winnerId, name: winnerName, wins: 1 });
    }
    await supabase.from('memory_rooms').update({ history }).eq('id', roomId);
  }

  // Exibe vencedor e atualiza histórico ao finalizar partida
  useEffect(() => {
    if (gameState && gameState.isGameFinished && room && user && room.player1 === user.id) {
      // Só o dono da sala atualiza o histórico para evitar duplicidade
      const maxScore = Math.max(...gameState.scores);
      const winnerIndexes = gameState.scores
        .map((score, i) => score === maxScore ? i : -1)
        .filter(i => i !== -1);
      // Se empate, todos recebem ponto
      winnerIndexes.forEach(i => {
        const winnerName = gameState.playerNames[i];
        const winnerId = room[`player${i+1}`];
        addVictoryToHistory(winnerName, winnerId);
      });
    }
  }, [gameState?.isGameFinished]);

  // TOPO PADRÃO DE SALA ONLINE
  if (!room) return <div style={{ color: '#fff', textAlign: 'center', marginTop: 40 }}>Carregando sala...</div>;
  // Declaração única das variáveis auxiliares
  const slots = ['player1', 'player2', 'player3', 'player4'];
  const playerNamesArr = slots.map((slot, i) => room[slot + '_name'] || (room[slot] ? `Jogador ${i+1}` : ''));
  const playerIdsArr = slots.map(slot => room[slot]);
  const readyArr = slots.map(slot => room[slot + '_ready']);
  const statusLabel = room.status === 'waiting' ? 'Aguardando jogadores' : (room.status === 'playing' ? 'Em andamento' : 'Finalizada');
  const info = '';
  const isOwner = user && room.player1 === user.id;
  const forceStartGame = () => {};
  const forceEnterGame = () => {};
  const myIndex = user ? getPlayerIndex(room, user.id) : -1;
  const isReady = myIndex >= 0 ? readyArr[myIndex] : false;

  // --- SAFEGUARD: if gameState is not ready, show waiting UI ---
  if (!gameState) {
    return (
      <div className="memory-online-game">
        <div style={{ background: '#23283a', borderRadius: 12, padding: 18, margin: '0 auto 24px', maxWidth: 480, color: '#e3e6ed', boxShadow: '0 2px 16px #0008', textAlign: 'center' }}>
          <div style={{ fontWeight: 700, fontSize: 18, marginBottom: 4 }}>Sala #{room.id}</div>
          <div style={{ marginBottom: 4 }}>
            <b>Status:</b> <span style={{ color: room.status === 'waiting' ? '#f7c873' : room.status === 'playing' ? '#6cf78a' : '#aaa' }}>{statusLabel}</span>
          </div>
          <div style={{ marginBottom: 4 }}>
            <b>Jogadores:</b> {playerNamesArr.filter(Boolean).join(', ')}
          </div>
          <button onClick={onLeave} style={{ margin: '12px 0 0 0', background: '#e11d48', color: '#fff', border: 'none', borderRadius: 6, padding: '8px 18px', fontWeight: 600, fontSize: '1rem', cursor: 'pointer' }}>
            Sair da Sala
          </button>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          {/* --- NOVO LOBBY, inspirado em OnlineGame.jsx --- */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16, marginBottom: 18, width: '100%', maxWidth: 480 }}>
            {slots.map((slot, i) => (
              <div key={slot} style={{
                display: 'flex', alignItems: 'center', gap: 16, background: playerIdsArr[i] ? '#23283a' : '#23283a44',
                borderRadius: 10, padding: '10px 18px', boxShadow: playerIdsArr[i] ? `0 2px 8px ${PLAYER_COLORS[i]}22` : 'none',
                border: playerIdsArr[i] ? `2px solid ${PLAYER_COLORS[i]}55` : '2px dashed #444',
                minHeight: 54, position: 'relative',
                transition: 'box-shadow 0.2s, border 0.2s',
              }}>
                <img
                  src={playerIdsArr[i] ? (user && user.id === playerIdsArr[i] && user.avatar ? user.avatar : DEFAULT_AVATARS[i]) : 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/2753.png'}
                  alt={playerNamesArr[i]}
                  style={{ width: 36, height: 36, borderRadius: '50%', border: playerIdsArr[i] ? `2px solid ${PLAYER_COLORS[i]}` : '2px solid #444', background: '#fff', marginRight: 8 }}
                />
                <span style={{ fontWeight: 700, color: playerIdsArr[i] ? PLAYER_COLORS[i] : '#888', fontSize: 17, minWidth: 90 }}>{playerNamesArr[i]}</span>
                {playerIdsArr[i] ? (
                  <span style={{ fontSize: 17, fontWeight: 600, color: readyArr[i] ? '#22c55e' : '#f7c873', marginLeft: 6 }}>
                    {readyArr[i] ? '✅ Pronto' : '⏳ Aguardando'}
                  </span>
                ) : (
                  <span style={{ color: '#888', fontSize: 15, marginLeft: 6 }}>Vazio</span>
                )}
                {playerIdsArr[i] === user?.id && (
                  <button
                    onClick={handlePlayerReady}
                    style={{
                      marginLeft: 'auto',
                      background: isReady ? 'linear-gradient(90deg,#38bdf8 60%,#22c55e 100%)' : 'linear-gradient(90deg,#38bdf8 60%,#2d8cff 100%)',
                      color: isReady ? '#23283a' : '#fff',
                      border: 'none', borderRadius: 7, padding: '7px 22px', fontSize: '1rem', fontWeight: 700, cursor: 'pointer', boxShadow: isReady ? '0 2px 8px #22c55e44' : '0 2px 8px #38bdf844', transition: 'background 0.2s, color 0.2s',
                    }}
                  >
                    {isReady ? 'Cancelar' : 'Estou pronto!'}
                  </button>
                )}
              </div>
            ))}
          </div>
          <div style={{ margin: '18px 0 10px', color: '#f7c873', fontWeight: 700, fontSize: 18, textAlign: 'center', letterSpacing: 0.2 }}>{info}</div>
          {isOwner && (
            <button
              onClick={forceStartGame}
              style={{ background: 'linear-gradient(90deg,#38bdf8 60%,#f7c873 100%)', color: '#23283a', border: 'none', borderRadius: 8, padding: '12px 28px', fontWeight: 800, fontSize: '1.08rem', cursor: 'pointer', margin: '0 auto 10px', display: 'block', boxShadow: '0 2px 8px #38bdf844', letterSpacing: 0.5 }}
            >
              Forçar início
            </button>
          )}
          <button onClick={onLeave} style={{ marginTop: 8, background: 'none', color: '#e3e6ed', border: '1.5px solid #38bdf8', borderRadius: 8, padding: '8px 22px', fontWeight: 600, fontSize: '1rem', cursor: 'pointer', width: '100%', marginBottom: 2 }}>Sair da sala</button>
          {room && room.status === 'playing' && !gameState && (
            <button onClick={forceEnterGame} style={{ marginTop: 16, background: 'linear-gradient(90deg,#f59e42 60%,#f7c873 100%)', color: '#23283a', border: 'none', borderRadius: 8, padding: '10px 22px', fontWeight: 700, fontSize: '1rem', cursor: 'pointer', width: '100%' }}>
              Forçar entrada
            </button>
          )}
        </div>
      </div>
    );
  }

  // --- Renderiza o jogo se gameState existe ---
  return (
    <div
      className={window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'ion-dark' : 'ion-light'}
      style={{ background: 'var(--color1)', minHeight: '100vh', transition: 'background 0.3s' }}
    >
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginTop: 24 }}>
        <h1 style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--color5)', marginBottom: 12 }}>Jogo da Memória Online</h1>
        <div style={{ marginBottom: '1rem', display: 'flex', flexWrap: 'wrap', gap: 16, justifyContent: 'center' }}>
          {gameState.playerNames.map((name, i) => (
            <div key={i} style={{
              background: 'var(--color2)',
              borderRadius: 10,
              padding: 8,
              minWidth: 120,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              border: `2px solid ${PLAYER_COLORS[i]}`,
              boxShadow: i === gameState.currentPlayer ? `0 0 8px ${PLAYER_COLORS[i]}` : 'none',
              opacity: gameState.isGameFinished || i === gameState.currentPlayer ? 1 : 0.8,
              color: PLAYER_COLORS[i],
              fontWeight: 700
            }}>
              <span style={{ fontWeight: 'bold', color: PLAYER_COLORS[i], fontSize: 16, marginBottom: 4 }}>{name}</span>
              <img
                src={gameState.playerAvatars[i]}
                alt={name}
                style={{ width: 36, height: 36, borderRadius: '50%', border: `2px solid ${PLAYER_COLORS[i]}` }}
              />
              <span style={{ fontSize: 14, color: PLAYER_COLORS[i], marginTop: 4 }}>{gameState.scores[i]} ponto{gameState.scores[i] !== 1 ? 's' : ''}</span>
            </div>
          ))}
        </div>
        <div style={{ fontSize: 18, fontWeight: 600, color: 'var(--color5)', marginBottom: 12 }}>
          {gameState.isGameFinished ? 'Partida finalizada!' : `É a vez de ${gameState.playerNames[gameState.currentPlayer]}`}
        </div>
        {/* Cartas do jogo */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, width: '100%', maxWidth: 480 }}>
          {gameState.cards.map((card, i) => {
            const flipped = (gameState.choiceOne && card.id === gameState.choiceOne.id) || (gameState.choiceTwo && card.id === gameState.choiceTwo.id) || card.matched;
            return (
              <div key={i} style={{ position: 'relative' }} onClick={() => handleChoice(card)}>
                <div style={{
                  width: '100%',
                  paddingTop: '100%',
                  borderRadius: 12,
                  overflow: 'hidden',
                  cursor: disabled || isGameFinished ? 'not-allowed' : 'pointer',
                  opacity: card.matched ? 0.6 : 1,
                  pointerEvents: card.matched ? 'none' : 'auto',
                  border: '2px solid var(--color4)',
                  background: flipped ? 'var(--color1)' : 'var(--color2)',
                  transition: 'box-shadow 0.2s, background 0.2s, transform 0.1s, border 0.2s',
                }}>
                  {flipped ? (
                    <img
                      src={card.src}
                      alt=""
                      style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', objectFit: 'cover', borderRadius: 12 }}
                    />
                  ) : (
                    <div style={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      width: '100%',
                      height: '100%',
                      background: 'var(--color3)',
                      borderRadius: 12,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: 24,
                      fontWeight: 700,
                      color: 'var(--color5)',
                      textShadow: '0 2px 4px rgba(0, 0, 0, 0.8)',
                      transition: 'transform 0.2s',
                      transform: card.matched ? 'scale(1.05)' : 'scale(1)',
                      border: '2px solid var(--color4)'
                    }}>
                      ?
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}