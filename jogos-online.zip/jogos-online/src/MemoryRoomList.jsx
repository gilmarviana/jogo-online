import React, { useState, useEffect } from 'react';
import supabase from './supabaseClient';

function ConfirmDialog({ open, onConfirm, onCancel, roomId }) {
  if (!open) return null;
  return (
    <div style={{
      position: 'fixed',
      top: 0, left: 0, right: 0, bottom: 0,
      background: 'rgba(0,0,0,0.35)',
      zIndex: 1000,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <div style={{
        background: 'var(--color2)',
        color: 'var(--color5)',
        borderRadius: 12,
        padding: '32px 28px',
        minWidth: 320,
        boxShadow: '0 4px 24px var(--color1)99',
        textAlign: 'center',
        transition: 'background 0.3s, color 0.3s',
      }}>
        <div style={{ fontSize: 20, fontWeight: 600, marginBottom: 16 }}>Excluir sala #{roomId}?</div>
        <div style={{ marginBottom: 24 }}>Tem certeza que deseja excluir esta sala? Esta ação não pode ser desfeita.</div>
        <button
          onClick={onConfirm}
          style={{
            background: 'linear-gradient(90deg, var(--color3) 0%, var(--color4) 100%)',
            color: 'var(--color1)',
            border: '2px solid var(--color5)',
            borderRadius: 8,
            fontSize: 16,
            fontWeight: 600,
            padding: '8px 28px',
            marginRight: 12,
            cursor: 'pointer',
            boxShadow: '0 2px 8px var(--color3)22',
            transition: 'background 0.2s, border 0.2s',
          }}
        >
          Excluir
        </button>
        <button
          onClick={onCancel}
          style={{
            background: 'none',
            color: 'var(--color5)',
            border: '2px solid var(--color5)',
            borderRadius: 8,
            fontSize: 16,
            fontWeight: 600,
            padding: '8px 28px',
            cursor: 'pointer',
            transition: 'background 0.15s, color 0.15s, border 0.2s',
          }}
        >
          Cancelar
        </button>
      </div>
    </div>
  );
}

export default function MemoryRoomList({ user, onJoinRoom }) {
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [roomToDelete, setRoomToDelete] = useState(null);
  const [roomIdInput, setRoomIdInput] = useState("");
  const [actionRoomId, setActionRoomId] = useState(null); // Para loading individual

  useEffect(() => {
    fetchRooms();
    const channel = supabase.channel('memory-rooms').on('postgres_changes', { event: '*', schema: 'public', table: 'memory_rooms' }, fetchRooms).subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  async function fetchRooms() {
    setLoading(true);
    const { data, error } = await supabase.from('memory_rooms').select('*').order('created_at', { ascending: false });
    if (!error) setRooms(data);
    setLoading(false);
  }

  async function handleCreateRoom() {
    setCreating(true);
    // Garante que as colunas de ready existem (para evitar erro na criação)
    const roomData = {
      player1: user.id,
      player1_name: user.user_metadata?.name || user.email,
      status: 'waiting',
      player1_ready: false,
      player2_ready: false,
      player3_ready: false,
      player4_ready: false
    };
    const { data, error } = await supabase.from('memory_rooms').insert(roomData).select().maybeSingle();
    setCreating(false);
    if (data && !error) onJoinRoom(data.id);
  }

  async function handleJoinRoom(room) {
    if (room.status !== 'waiting') return;
    // Permite reentrar se já está em algum slot
    if ([room.player1, room.player2, room.player3, room.player4].includes(user.id)) {
      onJoinRoom(room.id);
      return;
    }
    // Encontra o próximo slot disponível
    let slot = !room.player2 ? 'player2' : (!room.player3 ? 'player3' : (!room.player4 ? 'player4' : null));
    if (!slot) return;
    let nameSlot = slot + '_name';
    // Apenas adiciona o jogador ao slot, mantendo status 'waiting'
    await supabase.from('memory_rooms').update({ [slot]: user.id, [nameSlot]: user.user_metadata?.name || user.email }).eq('id', room.id);
    onJoinRoom(room.id);
  }

  async function handleJoinById() {
    if (!roomIdInput) return;
    setLoading(true);
    setActionRoomId('byid');
    const { data, error } = await supabase
      .from('memory_rooms')
      .select('*')
      .eq('id', roomIdInput)
      .maybeSingle();
    setLoading(false);
    setActionRoomId(null);
    if (error || !data) return;
    handleJoinRoom(data);
  }

  return (
    <div
      style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--color1)', padding: 0, margin: 0, transition: 'background 0.3s' }}
      className={window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'ion-dark' : 'ion-light'}
    >
      <div style={{ background: 'var(--color2)', borderRadius: 24, boxShadow: '0 8px 32px 0 var(--color3)44', padding: '48px 32px 32px 32px', maxWidth: 480, width: '100%', textAlign: 'center', color: 'var(--color5)', transition: 'background 0.3s, color 0.3s' }}>
        <h2 style={{ fontSize: 28, fontWeight: 700, color: 'var(--color5)', marginBottom: 8, letterSpacing: 1 }}>Salas do Jogo da Memória</h2>
        <div style={{ marginBottom: 12 }}>
          <button
            onClick={handleCreateRoom}
            disabled={loading || creating || actionRoomId === 'creating'}
            style={{
              marginBottom: 0,
              background: 'linear-gradient(90deg, var(--color3) 0%, var(--color4) 100%)',
              color: 'var(--color1)',
              border: '2px solid var(--color5)',
              borderRadius: 12,
              fontSize: 18,
              fontWeight: 600,
              padding: '12px 32px',
              cursor: 'pointer',
              boxShadow: '0 2px 8px var(--color3)22',
              transition: 'transform 0.08s, background 0.2s, border 0.2s',
            }}
            onMouseDown={e => e.currentTarget.style.transform = 'scale(0.97)'}
            onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
          >
            {actionRoomId === 'creating' || creating ? 'Criando...' : 'Criar Sala'}
          </button>
          <span style={{ marginLeft: 12, color: 'var(--color5)', fontSize: 13 }}>
            Crie uma sala para desafiar outros jogadores!
          </span>
        </div>
        {/* Campo para acessar sala por ID */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 16, marginTop: 18, alignItems: 'center', justifyContent: 'center' }}>
          <input
            type="text"
            placeholder="ID da sala"
            value={roomIdInput}
            onChange={e => setRoomIdInput(e.target.value)}
            style={{ padding: 6, borderRadius: 4, border: '1px solid var(--color4)', background: 'var(--color1)', color: 'var(--color5)', minWidth: 120 }}
          />
          <button
            onClick={handleJoinById}
            disabled={loading || !roomIdInput || actionRoomId === 'byid'}
            style={{
              background: 'linear-gradient(90deg, var(--color4) 0%, var(--color3) 100%)',
              color: 'var(--color1)',
              border: '2px solid var(--color5)',
              borderRadius: 8,
              fontSize: 15,
              fontWeight: 600,
              padding: '8px 18px',
              cursor: loading || !roomIdInput || actionRoomId === 'byid' ? 'not-allowed' : 'pointer',
              opacity: loading || !roomIdInput || actionRoomId === 'byid' ? 0.7 : 1,
              boxShadow: '0 2px 8px var(--color4)22',
              transition: 'background 0.2s, border 0.2s',
            }}
          >
            {actionRoomId === 'byid' ? 'Acessando...' : 'Acessar Sala'}
          </button>
          <span style={{ color: 'var(--color5)', fontSize: 13 }}>
            Digite o ID completo para acessar diretamente uma sala
          </span>
        </div>
        {loading ? <div style={{ color: 'var(--color5)' }}>Carregando...</div> : (
          <div style={{ marginTop: 16 }}>
            {rooms.length === 0 && <div style={{ color: 'var(--color5)' }}>Nenhuma sala disponível.</div>}
            {rooms.map(room => (
              <div key={room.id} style={{
                background: 'var(--color1)',
                color: 'var(--color5)',
                borderRadius: 10,
                margin: '12px 0',
                padding: 16,
                boxShadow: '0 2px 8px var(--color1)99',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                opacity: room.status !== 'waiting' ? 0.7 : 1,
                transition: 'background 0.3s, color 0.3s',
              }}>
                <div style={{ fontWeight: 600, fontSize: 18 }}>Sala #{room.id}</div>
                <div style={{ margin: '8px 0' }}>
                  Jogadores: {[room.player1_name, room.player2_name, room.player3_name, room.player4_name].filter(Boolean).join(', ')}
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button
                    onClick={() => handleJoinRoom(room)}
                    disabled={room.status !== 'waiting' || (room.player2 && room.player3 && room.player4)}
                    style={{
                      background: 'linear-gradient(90deg, var(--color4) 0%, var(--color3) 100%)',
                      color: 'var(--color1)',
                      border: '2px solid var(--color5)',
                      borderRadius: 8,
                      fontSize: 16,
                      fontWeight: 600,
                      padding: '8px 28px',
                      marginTop: 8,
                      cursor: room.status !== 'waiting' ? 'not-allowed' : 'pointer',
                      opacity: room.status !== 'waiting' ? 0.7 : 1,
                      boxShadow: '0 2px 8px var(--color4)22',
                      transition: 'background 0.2s, border 0.2s',
                    }}
                  >
                    Entrar
                  </button>
                  {/* Botão de excluir sala, só para o criador */}
                  {room.player1 === user.id && (
                    <button
                      onClick={() => {
                        setRoomToDelete(room.id);
                        setConfirmOpen(true);
                      }}
                      style={{
                        color: 'var(--color1)',
                        background: 'linear-gradient(90deg, var(--color3) 0%, var(--color4) 100%)',
                        border: '2px solid var(--color5)',
                        borderRadius: 8,
                        fontSize: 16,
                        marginTop: 8,
                        padding: '8px 18px',
                        cursor: 'pointer',
                        opacity: 0.95,
                        fontWeight: 600,
                        boxShadow: '0 2px 8px var(--color3)22',
                        transition: 'background 0.2s, border 0.2s',
                      }}
                    >
                      Excluir
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      {/* Popup de confirmação de exclusão */}
      <ConfirmDialog
        open={confirmOpen}
        roomId={roomToDelete}
        onConfirm={async () => {
          await supabase.from('memory_rooms').delete().eq('id', roomToDelete);
          await supabase.from('memory_game_states').delete().eq('room_id', roomToDelete);
          setConfirmOpen(false);
          setRoomToDelete(null);
          fetchRooms();
        }}
        onCancel={() => { setConfirmOpen(false); setRoomToDelete(null); }}
      />
    </div>
  );
}
