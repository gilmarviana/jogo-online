import { useState, useEffect } from 'react';
import './MemoryGame.css';

const CARD_IMAGES = [
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f436.png', matched: false }, // Dog
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f431.png', matched: false }, // Cat
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f42d.png', matched: false }, // Mouse
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f439.png', matched: false }, // Hamster
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f430.png', matched: false }, // Rabbit
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f98a.png', matched: false }, // Fox
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f43c.png', matched: false }, // Panda
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f428.png', matched: false }, // Koala
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f42f.png', matched: false }, // Tiger
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f981.png', matched: false }, // Lion
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f42e.png', matched: false }, // Cow
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f437.png', matched: false }, // Pig
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f43d.png', matched: false }, // Pig Nose
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f438.png', matched: false }, // Frog
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f435.png', matched: false }, // Monkey
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f648.png', matched: false }, // See-No-Evil Monkey
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f649.png', matched: false }, // Hear-No-Evil Monkey
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f64a.png', matched: false }, // Speak-No-Evil Monkey
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f41d.png', matched: false }, // Bee
  { src: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f41b.png', matched: false }, // Bug
];

function shuffleCards(pairsCount) {
  const selected = CARD_IMAGES.slice(0, pairsCount);
  const shuffled = [...selected, ...selected]
    .map(card => ({ ...card, id: Math.random() }))
    .sort(() => Math.random() - 0.5);
  return shuffled;
}

// Jogadores agora usam cores de destaque diferentes do tema
const PLAYER_COLORS = [
  '#e11d48', // vermelho destaque
  '#f59e42', // laranja destaque
  '#38bdf8', // azul claro destaque
  '#22c55e'  // verde destaque
];
const DEFAULT_AVATARS = [
  'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f600.png', // 😀
  'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f60a.png', // 😊
  'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f60e.png', // 😎
  'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f609.png', // 😉
];

function MemoryGame() {
  // Detecta o tema atual
  const [theme, setTheme] = useState(() => {
    if (typeof window !== 'undefined') {
      return document.body.classList.contains('theme-white') ? 'white' : 'dark';
    }
    return 'dark';
  });
  useEffect(() => {
    const observer = new MutationObserver(() => {
      setTheme(document.body.classList.contains('theme-white') ? 'white' : 'dark');
    });
    observer.observe(document.body, { attributes: true, attributeFilter: ['class'] });
    return () => observer.disconnect();
  }, []);

  const [cards, setCards] = useState([]);
  const [turns, setTurns] = useState(0);
  const [choiceOne, setChoiceOne] = useState(null);
  const [choiceTwo, setChoiceTwo] = useState(null);
  const [disabled, setDisabled] = useState(false);
  const [pairsCount, setPairsCount] = useState(3); // valor inicial
  const [gameStarted, setGameStarted] = useState(false);
  const [players, setPlayers] = useState(2); // novo: número de jogadores
  const [currentPlayer, setCurrentPlayer] = useState(0); // novo: índice do jogador atual
  const [scores, setScores] = useState([0, 0, 0, 0]); // novo: placar dos jogadores
  const [playerNames, setPlayerNames] = useState(['Jogador 1', 'Jogador 2', 'Jogador 3', 'Jogador 4']);
  const [playerAvatars, setPlayerAvatars] = useState(DEFAULT_AVATARS);

  // Inicia ou reinicia o jogo
  const startGame = () => {
    setCards(shuffleCards(pairsCount));
    setTurns(0);
    setChoiceOne(null);
    setChoiceTwo(null);
    setDisabled(false);
    setGameStarted(true);
    setCurrentPlayer(0);
    setScores(Array(players).fill(0));
  };

  // Handle card choice
  const handleChoice = (card) => {
    if (!disabled && !(card === choiceOne || card === choiceTwo || card.matched)) {
      choiceOne ? setChoiceTwo(card) : setChoiceOne(card);
    }
  };

  // Compare two selected cards
  useEffect(() => {
    if (choiceOne && choiceTwo) {
      setDisabled(true);
      if (choiceOne.src === choiceTwo.src) {
        setCards(prevCards => prevCards.map(card =>
          card.src === choiceOne.src ? { ...card, matched: true } : card
        ));
        setScores(prev => {
          const newScores = [...prev];
          newScores[currentPlayer] += 1;
          return newScores;
        });
        setTimeout(() => {
          resetTurn(true); // acerto, mantém o jogador
        }, 800);
      } else {
        setTimeout(() => {
          resetTurn(false); // erro, passa a vez
        }, 1000);
      }
    }
  }, [choiceOne, choiceTwo]);

  // Reset choices & increase turn
  const resetTurn = (keepPlayer) => {
    setChoiceOne(null);
    setChoiceTwo(null);
    setTurns(t => t + 1);
    setDisabled(false);
    if (!keepPlayer) {
      setCurrentPlayer(p => (p + 1) % players);
    }
  };

  // Verifica se todas as cartas foram encontradas
  const isGameFinished = cards.length > 0 && cards.every(card => card.matched);

  // Quando mudar a quantidade de pares ou jogadores, reseta o jogo
  useEffect(() => {
    setGameStarted(false);
    setCards([]);
    setTurns(0);
    setChoiceOne(null);
    setChoiceTwo(null);
    setDisabled(false);
    setCurrentPlayer(0);
    setScores(Array(players).fill(0));
    // Ajusta nomes e avatares para o número de jogadores
    setPlayerNames(prev => prev.slice(0, players).concat(Array(players).fill('').map((_,i) => `Jogador ${i+1}`)).slice(0,4));
    setPlayerAvatars(prev => prev.slice(0, players).concat(DEFAULT_AVATARS).slice(0,4));
  }, [pairsCount, players]);

  // Manipuladores para editar nome/avatar
  const handleNameChange = (idx, value) => {
    setPlayerNames(prev => prev.map((n, i) => i === idx ? value : n));
  };
  const handleAvatarChange = (idx, value) => {
    setPlayerAvatars(prev => prev.map((a, i) => i === idx ? value : a));
  };

  return (
    <div
      className={window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'ion-dark' : 'ion-light'}
      style={{
        background: 'var(--color1)',
        minHeight: '100vh',
        transition: 'background 0.3s',
        paddingBottom: 32
      }}
    >
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginTop: 24 }}>
        <h1 style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--color5)', marginBottom: 12, textShadow: '0 2px 8px var(--color2)' }}>Jogo da Memória</h1>
        <div style={{ marginBottom: '1rem', display: 'flex', flexWrap: 'wrap', gap: 16, justifyContent: 'center' }}>
          {[...Array(players)].map((_, i) => (
            <div key={i} style={{
              background: 'var(--color2)',
              borderRadius: 10,
              padding: 8,
              minWidth: 120,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              border: `2px solid ${PLAYER_COLORS[i]}`,
              boxShadow: i === currentPlayer ? `0 0 8px ${PLAYER_COLORS[i]}` : 'none',
              opacity: isGameFinished || i === currentPlayer ? 1 : 0.8,
              color: PLAYER_COLORS[i],
              fontWeight: 700
            }}>
              <input
                style={{
                  fontWeight: 'bold',
                  color: PLAYER_COLORS[i],
                  textAlign: 'center',
                  border: 'none',
                  background: 'transparent',
                  fontSize: 16,
                  marginBottom: 4,
                  outline: 'none',
                  width: 90
                }}
                value={playerNames[i]}
                onChange={e => handleNameChange(i, e.target.value)}
                maxLength={16}
              />
              <img
                src={playerAvatars[i]}
                alt={playerNames[i]}
                style={{ width: 36, height: 36, borderRadius: '50%', border: `2px solid ${PLAYER_COLORS[i]}`, background: 'var(--color1)', marginBottom: 4 }}
                onClick={() => {
                  const url = prompt('URL da imagem do avatar:', playerAvatars[i]);
                  if (url) handleAvatarChange(i, url);
                }}
                title="Clique para trocar o avatar"
              />
              <span style={{ color: PLAYER_COLORS[i], fontWeight: 'bold', fontSize: 18 }}>{scores[i]} ponto{scores[i] !== 1 ? 's' : ''}</span>
              <span style={{ fontSize: 12, color: 'var(--color5)' }}>{i === currentPlayer && !isGameFinished ? 'Sua vez!' : ''}</span>
            </div>
          ))}
        </div>
        <div style={{ marginBottom: '1rem', color: 'var(--color5)', width: '100%', maxWidth: 480, display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 8, justifyContent: 'center' }}>
          <label htmlFor="players">Jogadores: </label>
          <select
            id="players"
            value={players}
            onChange={e => setPlayers(Number(e.target.value))}
            style={{ background: 'var(--color1)', color: 'var(--color5)', border: '2px solid var(--color3)', borderRadius: 6, padding: '2px 8px', marginRight: 8 }}
          >
            {[1,2,3,4].map(n => (
              <option key={n} value={n}>{n}</option>
            ))}
          </select>
          <label htmlFor="pairs" style={{ marginLeft: '1rem' }}>Pares: </label>
          <select
            id="pairs"
            value={pairsCount}
            onChange={e => setPairsCount(Number(e.target.value))}
            style={{ background: 'var(--color1)', color: 'var(--color5)', border: '2px solid var(--color3)', borderRadius: 6, padding: '2px 8px' }}
          >
            {[...Array(20)].map((_, i) => (
              <option key={i+1} value={i+1}>{i+1}</option>
            ))}
          </select>
          <button onClick={startGame} style={{
            marginLeft: '1rem',
            background: 'var(--color3)',
            color: 'var(--color5)',
            border: '2px solid var(--color4)',
            borderRadius: 8,
            padding: '4px 16px',
            fontWeight: 'bold',
            boxShadow: '0 2px 8px var(--color1)',
            cursor: 'pointer',
            transition: 'transform 0.1s, border 0.2s',
          }}
          onMouseDown={e => e.currentTarget.style.transform = 'scale(0.96)'}
          onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
          >
            {gameStarted ? 'Reiniciar' : 'Iniciar'}
          </button>
        </div>
        {gameStarted && (
          <>
            <div style={{ fontSize: 18, fontWeight: 600, color: 'var(--color5)', marginBottom: 12 }}>
              {isGameFinished ? 'Partida finalizada!' : `É a vez de ${playerNames[currentPlayer]}`}
            </div>
            <p style={{ color: 'var(--color5)' }}>Turnos: {turns}</p>
            <div className="card-grid" style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(4, 1fr)',
              gap: 12,
              width: '100%',
              maxWidth: 480,
              margin: '0 auto'
            }}>
              {cards.map((card, idx) => {
                const flipped = card === choiceOne || card === choiceTwo || card.matched;
                return (
                  <div
                    className={`card ${flipped ? 'flipped' : ''}`}
                    key={card.id}
                    onClick={() => handleChoice(card)}
                    style={{
                      position: 'relative',
                      width: '100%',
                      paddingTop: '100%',
                      border: '2px solid var(--color4)',
                      background: flipped ? 'var(--color1)' : 'var(--color2)',
                      borderRadius: 12,
                      transition: 'box-shadow 0.2s, background 0.2s, transform 0.1s, border 0.2s',
                      overflow: 'hidden',
                      cursor: disabled ? 'not-allowed' : 'pointer',
                      opacity: card.matched ? 0.6 : 1,
                      pointerEvents: card.matched ? 'none' : 'auto',
                    }}
                  >
                    {flipped ? (
                      <img src={card.src} alt="emoji" style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', objectFit: 'cover', borderRadius: 12 }} />
                    ) : (
                      <div className="back" style={{
                        color: 'var(--color5)',
                        fontWeight: 'bold',
                        fontSize: 28,
                        background: 'var(--color3)',
                        borderRadius: 12,
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        width: '100%',
                        height: '100%',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        textShadow: '0 2px 4px rgba(0,0,0,0.8)',
                        transition: 'transform 0.2s',
                        transform: card.matched ? 'scale(1.05)' : 'scale(1)',
                        border: '2px solid var(--color4)'
                      }}>?</div>
                    )}
                  </div>
                );
              })}
            </div>
            {isGameFinished && (
              <div className="game-finished" style={{
                background: 'var(--color2)',
                color: 'var(--color5)',
                borderRadius: 12,
                margin: '24px auto 0',
                padding: 24,
                maxWidth: 400,
                boxShadow: '0 2px 16px var(--color1)',
                textAlign: 'center',
              }}>
                <div>Parabéns! Você encontrou todos os pares em {turns} turnos!</div>
                <div style={{ marginTop: 8 }}>
                  <strong>Placar final:</strong><br />
                  {Array.from({ length: players }).map((_, i) => (
                    <span key={i} style={{ marginRight: 16, color: PLAYER_COLORS[i], fontWeight: 'bold', display: 'inline-flex', alignItems: 'center' }}>
                      <img src={playerAvatars[i]} alt={playerNames[i]} style={{ width: 20, height: 20, borderRadius: '50%', verticalAlign: 'middle', marginRight: 4, border: `1.5px solid ${PLAYER_COLORS[i]}` }} />
                      {playerNames[i]}: {scores[i]}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

export default MemoryGame;
