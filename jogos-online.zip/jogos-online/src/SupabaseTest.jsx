import React, { useEffect, useState } from 'react';
import { supabase } from './supabaseClient';

export default function SupabaseTest() {
  const [status, setStatus] = useState('Testando conexão...');

  useEffect(() => {
    async function testConnection() {
      try {
        const { data, error } = await supabase.from('rooms').select('*').limit(1);
        if (error) setStatus('Erro: ' + error.message);
        else setStatus('Conexão com Supabase OK!');
      } catch (e) {
        setStatus('Erro inesperado: ' + e.message);
      }
    }
    testConnection();
  }, []);

  return (
    <div style={{ margin: 24, padding: 16, background: '#23272b', color: '#fff', borderRadius: 8 }}>
      <b>Teste de conexão Supabase:</b> {status}
    </div>
  );
}
