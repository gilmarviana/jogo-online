import React, { useState, useEffect } from 'react';
import TicTacToeRoomListV2 from './TicTacToeRoomListV2';
import TicTacToeOnlineGame from './TicTacToeOnlineGame';

const emptyBoard = () => Array(3).fill(null).map(() => Array(3).fill(null));

function checkWinner(board) {
  // Linhas, colunas e diagonais
  for (let i = 0; i < 3; i++) {
    if (board[i][0] && board[i][0] === board[i][1] && board[i][1] === board[i][2]) return board[i][0];
    if (board[0][i] && board[0][i] === board[1][i] && board[1][i] === board[2][i]) return board[0][i];
  }
  if (board[0][0] && board[0][0] === board[1][1] && board[1][1] === board[2][2]) return board[0][0];
  if (board[0][2] && board[0][2] === board[1][1] && board[1][1] === board[2][0]) return board[0][2];
  return null;
}

function isFull(board) {
  return board.every(row => row.every(cell => cell));
}

// Função Minimax para AI difícil
function minimax(board, depth, isMaximizing, aiMark, humanMark) {
  const winner = checkWinner(board);
  if (winner === aiMark) return 10 - depth;
  if (winner === humanMark) return depth - 10;
  if (isFull(board)) return 0;

  if (isMaximizing) {
    let bestScore = -Infinity;
    for (let i = 0; i < 3; i++) {
      for (let j = 0; j < 3; j++) {
        if (!board[i][j]) {
          board[i][j] = aiMark;
          const score = minimax(board, depth + 1, false, aiMark, humanMark);
          board[i][j] = null;
          bestScore = Math.max(score, bestScore);
        }
      }
    }
    return bestScore;
  } else {
    let bestScore = Infinity;
    for (let i = 0; i < 3; i++) {
      for (let j = 0; j < 3; j++) {
        if (!board[i][j]) {
          board[i][j] = humanMark;
          const score = minimax(board, depth + 1, true, aiMark, humanMark);
          board[i][j] = null;
          bestScore = Math.min(score, bestScore);
        }
      }
    }
    return bestScore;
  }
}

function getAIMove(board, level = 'hard') {
  if (level === 'easy') {
    // Movimento aleatório
    const empty = [];
    for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) if (!board[i][j]) empty.push([i, j]);
    if (empty.length === 0) return null;
    return empty[Math.floor(Math.random() * empty.length)];
  } else if (level === 'medium') {
    // Tenta ganhar, senão bloqueia, senão aleatório
    // 1. Ganhar
    for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) {
      if (!board[i][j]) {
        board[i][j] = 'O';
        if (checkWinner(board) === 'O') { board[i][j] = null; return [i, j]; }
        board[i][j] = null;
      }
    }
    // 2. Bloquear
    for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) {
      if (!board[i][j]) {
        board[i][j] = 'X';
        if (checkWinner(board) === 'X') { board[i][j] = null; return [i, j]; }
        board[i][j] = null;
      }
    }
    // 3. Aleatório
    const empty = [];
    for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) if (!board[i][j]) empty.push([i, j]);
    if (empty.length === 0) return null;
    return empty[Math.floor(Math.random() * empty.length)];
  } else {
    // Difícil: Minimax
    let bestScore = -Infinity;
    let move = null;
    for (let i = 0; i < 3; i++) {
      for (let j = 0; j < 3; j++) {
        if (!board[i][j]) {
          board[i][j] = 'O';
          const score = minimax(board, 0, false, 'O', 'X');
          board[i][j] = null;
          if (score > bestScore) {
            bestScore = score;
            move = [i, j];
          }
        }
      }
    }
    return move;
  }
}

export default function TicTacToeGame({ mode = 'local', playerName1 = 'Jogador 1', playerName2 = 'Jogador 2', user }) {
  const [tab, setTab] = useState('local'); // 'local', 'ai', 'online'
  const [onlineRoomId, setOnlineRoomId] = useState(null);
  const [board, setBoard] = useState(emptyBoard());
  const [current, setCurrent] = useState('X');
  const [winner, setWinner] = useState(null);
  const [vsAI, setVsAI] = useState(mode === 'ai');
  const [aiLevel, setAiLevel] = useState('hard');
  const [showLevelModal, setShowLevelModal] = useState(false);

  function handleClick(i, j) {
    if (board[i][j] || winner) return;
    const newBoard = board.map(row => [...row]);
    newBoard[i][j] = current;
    setBoard(newBoard);
    const win = checkWinner(newBoard);
    if (win) {
      setWinner(win);
    } else if (isFull(newBoard)) {
      setWinner('Empate');
    } else {
      setCurrent(current === 'X' ? 'O' : 'X');
    }
  }

  useEffect(() => {
    if (vsAI && current === 'O' && !winner) {
      const [aiI, aiJ] = getAIMove(board, aiLevel) || [];
      if (aiI !== undefined) {
        setTimeout(() => {
          handleClick(aiI, aiJ);
        }, 400);
      }
    }
    // eslint-disable-next-line
  }, [board, current, vsAI, winner, aiLevel]);

  function reset() {
    setBoard(emptyBoard());
    setCurrent('X');
    setWinner(null);
    if (vsAI) setShowLevelModal(true);
    else setShowLevelModal(false);
  }

  function handleVsAI() {
    setShowLevelModal(true);
    setVsAI(true);
  }

  function startVsAI(level) {
    setAiLevel(level);
    setShowLevelModal(false);
    setBoard(emptyBoard());
    setCurrent('X');
    setWinner(null);
  }

  function LevelModal() {
    return (
      <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(38,13,51,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
        <div style={{ background: 'var(--color2)', padding: 32, borderRadius: 14, boxShadow: '0 4px 24px var(--color1)', minWidth: 260, textAlign: 'center', border: '2px solid var(--color3)' }}>
          <h3 style={{ color: 'var(--color5)', marginBottom: 18 }}>Escolha o nível do Computador</h3>
          <button onClick={() => startVsAI('easy')} style={{ margin: 8, padding: '8px 22px', borderRadius: 8, border: '1.5px solid var(--color3)', background: 'var(--color3)', color: 'var(--color5)', fontWeight: 700, fontSize: 16, cursor: 'pointer', transition: 'background 0.15s' }}>Fácil</button>
          <button onClick={() => startVsAI('medium')} style={{ margin: 8, padding: '8px 22px', borderRadius: 8, border: '1.5px solid var(--color4)', background: 'var(--color4)', color: 'var(--color5)', fontWeight: 700, fontSize: 16, cursor: 'pointer', transition: 'background 0.15s' }}>Médio</button>
          <button onClick={() => startVsAI('hard')} style={{ margin: 8, padding: '8px 22px', borderRadius: 8, border: '1.5px solid var(--color2)', background: 'var(--color2)', color: 'var(--color5)', fontWeight: 700, fontSize: 16, cursor: 'pointer', transition: 'background 0.15s' }}>Difícil</button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ background: 'var(--color1)', borderRadius: 16, padding: 32, maxWidth: 400, margin: '0 auto', color: 'var(--color5)', boxShadow: '0 4px 24px var(--color2)', position: 'relative', transition: 'background 0.3s' }}>
      <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginBottom: 18 }}>
        <button onClick={() => setTab('local')} style={{ background: tab === 'local' ? 'var(--color3)' : 'var(--color2)', color: tab === 'local' ? 'var(--color1)' : 'var(--color5)', border: '1.5px solid var(--color3)', borderRadius: 8, padding: '8px 14px', fontWeight: 700, cursor: 'pointer', transition: 'background 0.15s' }}>2 Jogadores</button>
        <button onClick={() => { setTab('ai'); setShowLevelModal(true); setVsAI(true); }} style={{ background: tab === 'ai' ? 'var(--color3)' : 'var(--color2)', color: tab === 'ai' ? 'var(--color1)' : 'var(--color5)', border: '1.5px solid var(--color3)', borderRadius: 8, padding: '8px 14px', fontWeight: 700, cursor: 'pointer', transition: 'background 0.15s' }}>Contra o Computador</button>
        </div>
      {tab === 'local' && (
        <>
          <h2 style={{ textAlign: 'center', color: 'var(--color5)', fontWeight: 800, fontSize: 28 }}>Jogo da Velha</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 70px)', gap: 8, justifyContent: 'center', margin: '0 auto 18px auto' }}>
            {board.map((row, i) => row.map((cell, j) => (
              <button
                key={i + '-' + j}
                onClick={() => handleClick(i, j)}
                style={{
                  width: 70,
                  height: 70,
                  fontSize: 36,
                  fontWeight: 800,
                  background: 'var(--color2)',
                  border: '2.5px solid var(--color5)',
                  borderRadius: 10,
                  cursor: cell || winner ? 'not-allowed' : 'pointer',
                  transition: 'background 0.15s, color 0.15s, border 0.15s',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  padding: 0
                }}
              >
                {cell === 'X' && (
                  <span style={{ color: '#ff3333', fontSize: 36, fontWeight: 800, lineHeight: 1 }}>X</span>
                )}
                {cell === 'O' && (
                  <span style={{
                    display: 'inline-block',
                    width: 36,
                    height: 36,
                    borderRadius: '50%',
                    background: '#111',
                  }}></span>
                )}
                {cell !== 'X' && cell !== 'O' && ''}
              </button>
            )))}
          </div>
          <div style={{ textAlign: 'center', minHeight: 32, fontSize: 20, fontWeight: 700, color: 'var(--color5)' }}>
            {winner ? (
              winner === 'Empate' ? 'Empate!' : `Vencedor: ${winner}`
            ) : (
              vsAI && current === 'O' ? 'Vez do Computador...' : `Vez de: ${current === 'X' ? playerName1 : playerName2}`
            )}
          </div>
          <div style={{ display: 'flex', justifyContent: 'center', marginTop: 18 }}>
            <button onClick={reset} style={{ background: 'var(--color4)', color: 'var(--color5)', border: '1.5px solid var(--color3)', borderRadius: 8, padding: '8px 22px', fontWeight: 700, fontSize: '1rem', cursor: 'pointer', transition: 'background 0.15s' }}>Reiniciar</button>
          </div>
          {showLevelModal && vsAI && <LevelModal />}
        </>
      )}
      {tab === 'ai' && (
        <>
          {showLevelModal && vsAI && <LevelModal />}
          <h2 style={{ textAlign: 'center', color: 'var(--color5)', fontWeight: 800, fontSize: 28 }}>Jogo da Velha - AI</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 70px)', gap: 8, justifyContent: 'center', margin: '0 auto 18px auto' }}>
            {board.map((row, i) => row.map((cell, j) => (
              <button
                key={i + '-' + j}
                onClick={() => handleClick(i, j)}
                style={{
                  width: 70,
                  height: 70,
                  fontSize: 36,
                  fontWeight: 800,
                  background: 'var(--color2)',
                  border: '2.5px solid var(--color5)',
                  borderRadius: 10,
                  cursor: cell || winner ? 'not-allowed' : 'pointer',
                  transition: 'background 0.15s, color 0.15s, border 0.15s',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  padding: 0
                }}
              >
                {cell === 'X' && (
                  <span style={{ color: '#ff3333', fontSize: 36, fontWeight: 800, lineHeight: 1 }}>X</span>
                )}
                {cell === 'O' && (
                  <span style={{
                    display: 'inline-block',
                    width: 36,
                    height: 36,
                    borderRadius: '50%',
                    background: '#111',
                  }}></span>
                )}
                {cell !== 'X' && cell !== 'O' && ''}
              </button>
            )))}
          </div>
          <div style={{ textAlign: 'center', minHeight: 32, fontSize: 20, fontWeight: 700, color: 'var(--color5)' }}>
            {winner ? (
              winner === 'Empate' ? 'Empate!' : `Vencedor: ${winner}`
            ) : (
              vsAI && current === 'O' ? 'Vez do Computador...' : `Vez de: ${current === 'X' ? playerName1 : playerName2}`
            )}
          </div>
          <div style={{ display: 'flex', justifyContent: 'center', marginTop: 18 }}>
            <button onClick={reset} style={{ background: 'var(--color4)', color: 'var(--color5)', border: '1.5px solid var(--color3)', borderRadius: 8, padding: '8px 22px', fontWeight: 700, fontSize: '1rem', cursor: 'pointer', transition: 'background 0.15s' }}>Reiniciar</button>
          </div>
        </>
      )}
    </div>
  );
}
