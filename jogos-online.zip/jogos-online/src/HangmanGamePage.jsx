import React, { useEffect, useState } from 'react';
import HangmanGame from './HangmanGame';

export default function HangmanGamePage({ onBack }) {
  // Detecta o tema atual
  const [theme, setTheme] = useState(() => {
    if (typeof window !== 'undefined') {
      return document.body.classList.contains('theme-white') ? 'white' : 'dark';
    }
    return 'dark';
  });
  useEffect(() => {
    const observer = new MutationObserver(() => {
      setTheme(document.body.classList.contains('theme-white') ? 'white' : 'dark');
    });
    observer.observe(document.body, { attributes: true, attributeFilter: ['class'] });
    return () => observer.disconnect();
  }, []);

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, var(--color2) 60%, var(--color5) 100%)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ width: '100%', maxWidth: 900, margin: '0 auto', padding: '32px 0' }}>
        <button
          onClick={onBack}
          style={{
            marginBottom: 24,
            background: 'linear-gradient(90deg,var(--color4) 60%,var(--color3) 100%)',
            color: theme === 'white' ? '#222' : 'var(--color1)',
            border: 'none',
            borderRadius: 8,
            padding: '10px 28px',
            fontWeight: 700,
            fontSize: '1.08rem',
            cursor: 'pointer',
            boxShadow: '0 2px 8px var(--color4)44',
            transition: 'background 0.2s'
          }}
        >
          Voltar
        </button>
        <HangmanGame />
      </div>
    </div>
  );
}
