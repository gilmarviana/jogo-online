import React, { useEffect, useState, useRef } from 'react';
import supabase from './supabaseClient';

export default function JokenpoRoom({ user, roomId, onLeave, onStart }) {
  const [room, setRoom] = useState(null);
  const [loading, setLoading] = useState(true);

  // Busca dados da sala e escuta mudanças em tempo real
  useEffect(() => {
    fetchRoom();
    const channel = supabase.channel('jokenpo-room-' + roomId)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'jokenpo_rooms', filter: `id=eq.${roomId}` }, payload => {
        if (payload.new) setRoom(payload.new);
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [roomId]);

  async function fetchRoom() {
    setLoading(true);
    const { data, error } = await supabase.from('jokenpo_rooms').select('*').eq('id', roomId).maybeSingle();
    if (!error) setRoom(data);
    setLoading(false);
  }

  // Se a sala estiver em status 'playing', inicia o jogo
  useEffect(() => {
    if (room && room.status === 'playing') {
      onStart && onStart(roomId);
    }
  }, [room?.status, onStart, roomId]);

  // Exibe tela de lobby apenas se status for 'waiting'
  const [countdown, setCountdown] = useState(null);
  const countdownRef = useRef(null);

  useEffect(() => {
    if (!room || room.status !== 'waiting') {
      setCountdown(null);
      if (countdownRef.current) {
        clearInterval(countdownRef.current);
        countdownRef.current = null;
      }
      return;
    }
    const slots = ['player1', 'player2'];
    const players = slots.map(slot => ({
      id: room[slot],
      name: room[slot + '_name'],
      ready: room[slot + '_ready']
    }));
    const allReady = players.every(p => p.id && p.ready);
    const isOwner = room && user && room.player1 === user.id;
    const playersCount = players.filter(p => p.id).length;
    if (playersCount === 2 && allReady) {
      if (countdown === null && !countdownRef.current) {
        setCountdown(5);
        let c = 5;
        countdownRef.current = setInterval(() => {
          c--;
          setCountdown(c);
          if (c === 0) {
            clearInterval(countdownRef.current);
            countdownRef.current = null;
            setCountdown(null);
            if (isOwner) {
              supabase.from('jokenpo_rooms').update({ status: 'playing' }).eq('id', roomId);
            }
          }
        }, 1000);
      }
    } else {
      setCountdown(null);
      if (countdownRef.current) {
        clearInterval(countdownRef.current);
        countdownRef.current = null;
      }
    }
    return () => {
      if (countdownRef.current) {
        clearInterval(countdownRef.current);
        countdownRef.current = null;
      }
    };
  }, [room, user, countdown]);

  if (loading || !room) return <div style={{ color: 'var(--color5)', textAlign: 'center', marginTop: 40 }}>Carregando sala...</div>;

  if (room.status === 'waiting') {
    const slots = ['player1', 'player2'];
    const players = slots.map(slot => ({
      id: room[slot],
      name: room[slot + '_name'],
      ready: room[slot + '_ready']
    }));
    const isOwner = room && user && room.player1 === user.id;
    const mySlot = slots.findIndex(slot => room[slot] === user.id);
    const allReady = players.every(p => p.id && p.ready);
    async function handleReady() {
      if (mySlot === -1) return;
      const field = slots[mySlot] + '_ready';
      await supabase.from('jokenpo_rooms').update({ [field]: !room[field] }).eq('id', roomId);
    }
    async function handleStart() {
      await supabase.from('jokenpo_rooms').update({ status: 'playing' }).eq('id', roomId);
    }
    return (
      <div
        style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--color1)', padding: 0, margin: 0, transition: 'background 0.3s' }}
        className={window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'ion-dark' : 'ion-light'}
      >
        <div style={{ background: 'var(--color2)', borderRadius: 24, boxShadow: '0 8px 32px 0 var(--color3)44', padding: '48px 32px 32px 32px', maxWidth: 420, width: '100%', textAlign: 'center', color: 'var(--color5)', transition: 'background 0.3s, color 0.3s' }}>
          <h2 style={{ fontSize: 28, fontWeight: 700, color: 'var(--color5)', marginBottom: 8, letterSpacing: 1 }}>Sala #{roomId}</h2>
          <div style={{ marginBottom: 18, color: 'var(--color5)', fontSize: 18 }}>
            Jogadores: {players.map(p => p.name).join(', ')}
          </div>
          <div style={{ display: 'flex', gap: 16, justifyContent: 'center', marginBottom: 24 }}>
            <button
              onClick={onLeave}
              style={{
                background: 'none',
                color: 'var(--color5)',
                border: '2px solid var(--color5)',
                borderRadius: 8,
                fontSize: 16,
                fontWeight: 600,
                padding: '8px 28px',
                cursor: 'pointer',
                transition: 'background 0.15s, color 0.15s, border 0.2s',
              }}
            >
              Sair da sala
            </button>
            {isOwner && (
              <button
                onClick={handleStart}
                disabled={players.filter(p => p.id).length < 2}
                style={{
                  background: players.filter(p => p.id).length === 2 ? 'linear-gradient(90deg, var(--color3) 0%, var(--color4) 100%)' : '#888',
                  color: 'var(--color1)',
                  border: '2px solid var(--color5)',
                  borderRadius: 8,
                  fontSize: 16,
                  fontWeight: 700,
                  padding: '8px 28px',
                  cursor: players.filter(p => p.id).length === 2 ? 'pointer' : 'not-allowed',
                  boxShadow: players.filter(p => p.id).length === 2 ? '0 2px 8px var(--color3)22' : 'none',
                  transition: 'background 0.2s, border 0.2s',
                  opacity: players.filter(p => p.id).length === 2 ? 1 : 0.7
                }}
              >
                Iniciar Jogo
              </button>
            )}
          </div>
          {/* Contagem regressiva visual */}
          {allReady && countdown !== null && (
            <div style={{ color: '#f59e42', fontWeight: 800, fontSize: 22, marginTop: 14, letterSpacing: 1 }}>
              Começando em {countdown}...
            </div>
          )}
          <div style={{ color: 'var(--color5)', fontSize: 15, marginTop: 18 }}>
            Aguarde ambos jogadores entrarem e ficarem prontos para iniciar.
          </div>
        </div>
      </div>
    );
  }

  // Se a sala estiver em status 'playing', exija ready dos jogadores antes de prosseguir
  if (room.status === 'playing') {
    const slots = ['player1', 'player2'];
    const players = slots.map(slot => ({
      id: room[slot],
      name: room[slot + '_name'],
      ready: room[slot + '_ready_playing']
    }));
    const mySlot = slots.findIndex(slot => room[slot] === user.id);
    const allReady = players.every(p => p.id && p.ready);
    async function handleReadyPlaying() {
      if (mySlot === -1) return;
      const field = slots[mySlot] + '_ready_playing';
      await supabase.from('jokenpo_rooms').update({ [field]: !room[field] }).eq('id', roomId);
    }
    if (!allReady) {
      return (
        <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--color1)', padding: 0, margin: 0 }}>
          <div style={{ background: 'var(--color2)', borderRadius: 24, boxShadow: '0 8px 32px 0 var(--color3)44', padding: '48px 32px 32px 32px', maxWidth: 420, width: '100%', textAlign: 'center', color: 'var(--color5)' }}>
            <h2 style={{ fontSize: 28, fontWeight: 700, color: 'var(--color5)', marginBottom: 8 }}>Preparar para a partida</h2>
            <div style={{ marginBottom: 18, color: 'var(--color5)', fontSize: 18 }}>
              Jogadores: {players.map(p => p.name).join(', ')}
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16, alignItems: 'center', marginBottom: 24 }}>
              {players.map((p, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <span style={{ fontWeight: 600 }}>{p.name}</span>
                  <span style={{ color: p.ready ? '#22c55e' : '#f7c873', fontWeight: 700 }}>
                    {p.ready ? '✅ Pronto' : '⏳ Aguardando'}
                  </span>
                  {p.id === user.id && (
                    <button
                      onClick={handleReadyPlaying}
                      style={{
                        marginLeft: 10,
                        background: p.ready ? 'linear-gradient(90deg,#38bdf8 60%,#22c55e 100%)' : 'linear-gradient(90deg,#38bdf8 60%,#2d8cff 100%)',
                        color: p.ready ? '#23283a' : '#fff',
                        border: 'none', borderRadius: 7, padding: '7px 22px', fontSize: '1rem', fontWeight: 700, cursor: 'pointer', boxShadow: p.ready ? '0 2px 8px #22c55e44' : '0 2px 8px #38bdf844', transition: 'background 0.2s, color 0.2s',
                      }}
                    >
                      {p.ready ? 'Cancelar' : 'Pronto'}
                    </button>
                  )}
                </div>
              ))}
            </div>
            <div style={{ color: 'var(--color5)', fontSize: 15, marginTop: 18 }}>
              Todos devem clicar em "Pronto" para iniciar a rodada.
            </div>
          </div>
        </div>
      );
    }
  }

  // Se não for waiting, não exibe nada (ou pode exibir children, se desejar)
  return null;
}
