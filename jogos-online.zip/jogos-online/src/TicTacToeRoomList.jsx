import React, { useEffect, useRef, useState } from 'react';
import supabase from './supabaseClient';

export default function TicTacToeRoomList({ user, onEnterRoom, onBack }) {
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [joining, setJoining] = useState(null);
  const [countdownRoomId, setCountdownRoomId] = useState(null);
  const [countdown, setCountdown] = useState(null);
  const countdownInterval = useRef();

  useEffect(() => {
    fetchRooms();
    const channel = supabase.channel('tic-tac-toe-rooms')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tic_tac_toe_rooms' }, payload => {
        fetchRooms();
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  // Inicia contagem regressiva localmente quando ambos estão prontos
  useEffect(() => {
    if (!rooms) return;
    const room = rooms.find(r => r.id === countdownRoomId);
    if (!room) return;
    if (room.player1_ready && room.player2_ready && !countdown) {
      setCountdown(3);
      countdownInterval.current = setInterval(() => {
        setCountdown(prev => {
          if (prev === 1) {
            clearInterval(countdownInterval.current);
            setCountdownRoomId(null);
            setCountdown(null);
            return null;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(countdownInterval.current);
  }, [rooms, countdownRoomId, countdown]);

  async function fetchRooms() {
    setLoading(true);
    const { data, error } = await supabase
      .from('tic_tac_toe_rooms')
      .select('*')
      .order('created_at', { ascending: false });
    if (!error) setRooms(data);
    setLoading(false);
  }

  async function handleCreateRoom() {
    const { data, error } = await supabase.from('tic_tac_toe_rooms').insert({
      name: '',
      owner_id: user.id,
      status: 'waiting',
      player1: user.id,
      player1_name: user.name || 'Jogador 1',
      player1_ready: false,
      player2_ready: false,
    }).select().maybeSingle();
    console.log('DEBUG insert sala:', data, error);
    if (data && data.id) {
      onEnterRoom(data.id);
    } else {
      if (error) {
        console.error('Erro ao criar sala:', error.message || error);
        alert('Erro ao criar sala: ' + (error.message || error));
      } else {
        alert('Erro ao criar sala. Não foi possível obter o ID da sala. Veja o console para detalhes.');
      }
      console.error('Retorno do insert:', data);
    }
  }

  async function handleEnterRoom(room) {
    setJoining(room.id);
    // Se já é player1 ou player2, apenas entra
    if (room.player1 === user.id || room.player2 === user.id) {
      onEnterRoom(room.id);
      setJoining(null);
      return;
    }
    // Se slot player2 está vazio, entra como player2
    if (!room.player2) {
      const { data, error } = await supabase.from('tic_tac_toe_rooms').update({
        player2: user.id,
        player2_name: user.name || 'Jogador 2',
        player2_ready: false,
      }).eq('id', room.id).select().maybeSingle();
      if (data) {
        onEnterRoom(room.id);
      }
      setJoining(null);
      return;
    }
    // Caso contrário, não pode entrar
    alert('A sala já está cheia.');
    setJoining(null);
  }

  async function handleReady(room, player) {
    const readyField = player === 1 ? 'player1_ready' : 'player2_ready';
    await supabase.from('tic_tac_toe_rooms').update({ [readyField]: true }).eq('id', room.id);
    setCountdownRoomId(room.id);
  }

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #23283a 60%, #7dd3fc 100%)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ background: 'rgba(35,40,58,0.98)', borderRadius: 18, padding: '36px 32px 28px', maxWidth: 440, width: '100%', boxShadow: '0 4px 32px #000a' }}>
        <h2 style={{ color: '#7dd3fc', fontWeight: 800, fontSize: 28, marginBottom: 18, textAlign: 'center' }}>Salas de Jogo da Velha Online</h2>
        <div style={{ display: 'flex', gap: 10, marginBottom: 18 }}>
          <button onClick={handleCreateRoom} style={{ background: '#7dd3fc', color: '#23283a', border: 'none', borderRadius: 8, padding: '8px 18px', fontWeight: 700, fontSize: 16, cursor: 'pointer', width: '100%' }}>Criar Jogo TicToe</button>
        </div>
        {loading ? <div style={{ color: '#fff' }}>Carregando...</div> : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {rooms.length === 0 && <div style={{ color: '#fff' }}>Nenhuma sala encontrada.</div>}
            {rooms.map(room => {
              const isPlayer1 = room.player1 === user.id;
              const isPlayer2 = room.player2 === user.id;
              const isInRoom = isPlayer1 || isPlayer2;
              const canReady = isInRoom && ((isPlayer1 && !room.player1_ready) || (isPlayer2 && !room.player2_ready));
              const showCountdown = countdownRoomId === room.id && countdown !== null;
              return (
                <div key={room.id} style={{ background: '#23283a', borderRadius: 10, padding: '12px 18px', display: 'flex', flexDirection: 'column', gap: 6, border: '2px solid #7dd3fc55', boxShadow: '0 2px 8px #7dd3fc22' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <span style={{ color: '#7dd3fc', fontWeight: 700, fontSize: 17 }}>{room.name}</span>
                    <button
                      onClick={() => handleEnterRoom(room)}
                      disabled={joining === room.id || (room.player1 && room.player2 && !isInRoom)}
                      style={{ background: '#38bdf8', color: '#23283a', border: 'none', borderRadius: 8, padding: '6px 16px', fontWeight: 700, fontSize: 15, cursor: 'pointer', opacity: joining === room.id ? 0.7 : 1 }}
                    >
                      {joining === room.id ? 'Entrando...' : (isInRoom ? 'Voltar' : 'Entrar')}
                    </button>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
                    <span style={{ color: '#fff', fontSize: 15 }}>
                      {room.player1_name || 'Aguardando...'} {room.player1_ready ? '✅' : ''}
                    </span>
                    <span style={{ color: '#fff', fontSize: 15 }}>
                      {room.player2_name || 'Aguardando...'} {room.player2_ready ? '✅' : ''}
                    </span>
                  </div>
                  {canReady && (
                    <button
                      onClick={() => handleReady(room, isPlayer1 ? 1 : 2)}
                      style={{ marginTop: 6, background: '#22d3ee', color: '#23283a', border: 'none', borderRadius: 8, padding: '6px 16px', fontWeight: 700, fontSize: 15, cursor: 'pointer' }}
                    >
                      Pronto
                    </button>
                  )}
                  {showCountdown && (
                    <div style={{ marginTop: 8, color: '#7dd3fc', fontWeight: 700, fontSize: 18, textAlign: 'center' }}>
                      Começando em {countdown}...
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
        <button onClick={onBack} style={{ marginTop: 18, background: 'none', color: '#7dd3fc', border: '1.5px solid #7dd3fc', borderRadius: 8, padding: '8px 22px', fontWeight: 600, fontSize: '1rem', cursor: 'pointer', width: '100%' }}>Voltar</button>
      </div>
    </div>
  );
}
