import React, { useState, useEffect, Suspense, lazy } from 'react';
import './App.css';
import supabase from './supabaseClient';
import Auth from './Auth';
import Header from './Header';

const Minesweeper = lazy(() => import('./Minesweeper'));
const RoomList = lazy(() => import('./RoomList'));
const OnlineGame = lazy(() => import('./OnlineGame'));
const MemoryGame = lazy(() => import('./MemoryGame'));
const MemoryModeSelect = lazy(() => import('./MemoryModeSelect'));
const MemoryRoomList = lazy(() => import('./MemoryRoomList'));
const MemoryOnlineGame = lazy(() => import('./MemoryOnlineGame'));
const HangmanGamePage = React.lazy(() => import('./HangmanGamePage'));
const TicTacToeModeSelect = React.lazy(() => import('./TicTacToeModeSelect'));
const TicTacToeGame = React.lazy(() => import('./TicTacToeGame'));
const TicTacToeRoomListV2 = React.lazy(() => import('./TicTacToeRoomListV2'));
const TicTacToeOnlineGame = React.lazy(() => import('./TicTacToeOnlineGame'));
const JokenpoModeSelect = React.lazy(() => import('./JokenpoModeSelect'));
const JokenpoLocal = React.lazy(() => import('./JokenpoLocal'));
const JokenpoOnline = React.lazy(() => import('./JokenpoOnline'));
const JokenpoRoomList = React.lazy(() => import('./JokenpoRoomList'));
const JokenpoRoom = React.lazy(() => import('./JokenpoRoom'));

function Dashboard({ onSelectGame, onLogout, user }) {
  // Detecta o tema atual (dark/white) do body
  const [theme, setTheme] = React.useState(() => {
    if (typeof window !== 'undefined') {
      return document.body.classList.contains('theme-white') ? 'white' : 'dark';
    }
    return 'dark';
  });
  React.useEffect(() => {
    const observer = new MutationObserver(() => {
      setTheme(document.body.classList.contains('theme-white') ? 'white' : 'dark');
    });
    observer.observe(document.body, { attributes: true, attributeFilter: ['class'] });
    return () => observer.disconnect();
  }, []);

  // Paleta dinâmica
  const palette = theme === 'dark'
    ? {
        bg: '#260d33',
        card: '#003f69',
        cardText: '#b3aca4',
        btn1: 'linear-gradient(90deg, #106b87 0%, #157a8c 100%)',
        btn2: 'linear-gradient(90deg, #157a8c 0%, #b3aca4 100%)',
        btn3: '#106b87',
        btn4: 'linear-gradient(90deg, #b3aca4 0%, #106b87 100%)',
        btnText1: '#b3aca4',
        btnText2: '#260d33',
        btnText3: '#b3aca4',
        btnText4: '#260d33',
        border: '#157a8c',
        logout: '#157a8c',
        logoutBg: '#106b8722',
      }
    : {
        bg: '#eaf3fa',
        card: '#fff',
        cardText: '#003f69',
        btn1: 'linear-gradient(90deg, #b3aca4 0%, #157a8c 100%)',
        btn2: 'linear-gradient(90deg, #106b87 0%, #b3aca4 100%)',
        btn3: '#eaf3fa',
        btn4: 'linear-gradient(90deg, #157a8c 0%, #003f69 100%)',
        btnText1: '#003f69',
        btnText2: '#003f69',
        btnText3: '#003f69',
        btnText4: '#fff',
        border: '#157a8c',
        logout: '#157a8c',
        logoutBg: '#157a8c22',
      };

  return (
    <div style={{
      minHeight: '100vh',
      background: palette.bg,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 0,
      margin: 0,
    }}>
      <div style={{
        background: palette.card,
        borderRadius: 24,
        boxShadow: theme === 'dark' ? '0 8px 32px 0 rgba(16, 107, 135, 0.18)' : '0 8px 32px 0 #b3aca433',
        padding: '40px 32px 32px 32px',
        maxWidth: 480,
        width: '100%',
        textAlign: 'center',
        margin: '32px 0',
      }}>
        <h2 style={{ fontSize: 32, fontWeight: 800, color: palette.cardText, marginBottom: 8, letterSpacing: 1 }}>
          Bem-vindo{user?.email ? `, ${user.email}` : ''}!
        </h2>
        <p style={{ color: palette.cardText, fontSize: 18, marginBottom: 32 }}>Selecione o jogo para acessar:</p>
        <div style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: 28,
          marginBottom: 32,
        }}>
          <button
            onClick={() => onSelectGame('minesweeper-mode')}
            style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8,
              background: palette.btn1,
              color: palette.btnText1, border: 'none', borderRadius: 16, fontSize: 20, fontWeight: 700,
              padding: '32px 8px', cursor: 'pointer', boxShadow: '0 2px 8px #157a8c33', transition: 'transform 0.08s',
            }}
            onMouseDown={e => e.currentTarget.style.transform = 'scale(0.97)'}
            onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
          >
            <span style={{ fontSize: 38 }}>💣</span>
            Campo Minado
          </button>
          <button
            onClick={() => onSelectGame('memory-mode')}
            style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8,
              background: palette.btn2,
              color: palette.btnText2, border: 'none', borderRadius: 16, fontSize: 20, fontWeight: 700,
              padding: '32px 8px', cursor: 'pointer', boxShadow: '0 2px 8px #b3aca433', transition: 'transform 0.08s',
            }}
            onMouseDown={e => e.currentTarget.style.transform = 'scale(0.97)'}
            onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
          >
            <span style={{ fontSize: 38 }}>🧠</span>
            Jogo da Memória
          </button>
          <button
            onClick={() => onSelectGame('hangman')}
            style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8,
              background: palette.btn3,
              color: palette.btnText3, border: 'none', borderRadius: 16, fontSize: 20, fontWeight: 700,
              padding: '32px 8px', cursor: 'pointer', boxShadow: '0 2px 8px #106b8744', transition: 'transform 0.08s',
            }}
            onMouseDown={e => e.currentTarget.style.transform = 'scale(0.97)'}
            onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
          >
            <span style={{ fontSize: 38 }}>🔤</span>
            Jogo da Forca
          </button>
          <button
            onClick={() => onSelectGame('tic-tac-toe')}
            style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8,
              background: palette.btn4,
              color: palette.btnText4, border: 'none', borderRadius: 16, fontSize: 20, fontWeight: 700,
              padding: '32px 8px', cursor: 'pointer', boxShadow: '0 2px 8px #b3aca444', transition: 'transform 0.08s',
            }}
            onMouseDown={e => e.currentTarget.style.transform = 'scale(0.97)'}
            onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
          >
            <span style={{ fontSize: 38 }}>⭕️❌</span>
            Jogo da Velha
          </button>
          <button
            onClick={() => onSelectGame('jokenpo-mode')}
            style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8,
              background: 'linear-gradient(90deg, #38bdf8 0%, #b3aca4 100%)',
              color: palette.btnText1, border: 'none', borderRadius: 16, fontSize: 20, fontWeight: 700,
              padding: '32px 8px', cursor: 'pointer', boxShadow: '0 2px 8px #38bdf833', transition: 'transform 0.08s',
            }}
            onMouseDown={e => e.currentTarget.style.transform = 'scale(0.97)'}
            onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
          >
            <span style={{ fontSize: 38 }}>✊✋✌️</span>
            Jokenpô
          </button>
        </div>
        <button
          onClick={onLogout}
          style={{ color: palette.logout, background: 'none', border: `1.5px solid ${palette.logout}`, padding: '8px 28px', borderRadius: 8, fontWeight: 700, fontSize: 16, marginTop: 8, cursor: 'pointer', opacity: 0.85, transition: 'background 0.15s' }}
          onMouseOver={e => e.currentTarget.style.background = palette.logoutBg}
          onMouseOut={e => e.currentTarget.style.background = 'none'}
        >
          Sair
        </button>
      </div>
    </div>
  );
}

function MinesweeperModeSelect({ onSelectMode, onBack }) {
  // Detecta o tema Ionic
  const [theme, setTheme] = React.useState(() => {
    if (typeof window !== 'undefined') {
      return document.body.classList.contains('theme-white') ? 'white' : 'dark';
    }
    return 'dark';
  });
  React.useEffect(() => {
    const observer = new MutationObserver(() => {
      setTheme(document.body.classList.contains('theme-white') ? 'white' : 'dark');
    });
    observer.observe(document.body, { attributes: true, attributeFilter: ['class'] });
    return () => observer.disconnect();
  }, []);

  // Paleta Ionic
  const palette = theme === 'dark'
    ? {
        color1: '#260d33',
        color2: '#003f69',
        color3: '#106b87',
        color4: '#157a8c',
        color5: '#b3aca4',
        text: '#b3aca4',
        cardText: '#b3aca4',
        btnText: '#b3aca4',
        border: '#157a8c',
      }
    : {
        color1: '#eaf3fa', // fallback para body
        color2: '#fff',
        color3: '#106b87',
        color4: '#157a8c',
        color5: '#003f69',
        text: '#003f69',
        cardText: '#003f69',
        btnText: '#003f69',
        border: '#157a8c',
      };

  return (
    <div
      className={theme === 'dark' ? 'ion-dark' : 'ion-light'}
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: palette.color1,
        padding: 0,
        margin: 0,
        transition: 'background 0.3s',
      }}
    >
      <div
        style={{
          background: palette.color2,
          borderRadius: 24,
          boxShadow: theme === 'dark' ? '0 8px 32px 0 #0008' : '0 8px 32px 0 #b3aca433',
          padding: '48px 32px 32px 32px',
          maxWidth: 420,
          width: '100%',
          textAlign: 'center',
          border: `2px solid ${palette.color4}`,
        }}
      >
        <h2 style={{ fontSize: 32, fontWeight: 700, color: palette.color5, marginBottom: 8, letterSpacing: 1 }}>Campo Minado</h2>
        <p style={{ color: palette.cardText, fontSize: 18, marginBottom: 32 }}>Escolha o modo de jogo:</p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
          <button
            onClick={() => onSelectMode('minesweeper-solo')}
            style={{
              display: 'flex', alignItems: 'center', gap: 16,
              background: palette.color3,
              color: palette.color5,
              border: `2px solid ${palette.color4}`,
              borderRadius: 12,
              fontSize: 22,
              fontWeight: 600,
              padding: '18px 32px',
              cursor: 'pointer',
              boxShadow: '0 2px 8px #0002',
              transition: 'transform 0.08s, border 0.2s',
            }}
            onMouseDown={e => e.currentTarget.style.transform = 'scale(0.97)'}
            onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
          >
            <span style={{ fontSize: 28, display: 'flex', alignItems: 'center' }}>👤</span>
            <span style={{ textAlign: 'left' }}>
              Solo<br />
              <span style={{ fontSize: 15, fontWeight: 400, color: palette.color5 }}>Jogue sozinho e desafie-se!</span>
            </span>
          </button>
          <button
            onClick={() => onSelectMode('minesweeper-online')}
            style={{
              display: 'flex', alignItems: 'center', gap: 16,
              background: palette.color4,
              color: palette.color2,
              border: `2px solid ${palette.color5}`,
              borderRadius: 12,
              fontSize: 22,
              fontWeight: 600,
              padding: '18px 32px',
              cursor: 'pointer',
              boxShadow: '0 2px 8px #0002',
              transition: 'transform 0.08s, border 0.2s',
            }}
            onMouseDown={e => e.currentTarget.style.transform = 'scale(0.97)'}
            onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
          >
            <span style={{ fontSize: 28, display: 'flex', alignItems: 'center' }}>🌐</span>
            <span style={{ textAlign: 'left' }}>
              Online<br />
              <span style={{ fontSize: 15, fontWeight: 400, color: palette.color2 }}>Jogue com amigos ou desafie outros jogadores!</span>
            </span>
          </button>
        </div>
        <div style={{ marginTop: 40 }}>
          <button
            onClick={onBack}
            style={{
              color: palette.color5,
              background: 'none',
              border: `2px solid ${palette.color5}`,
              padding: '8px 28px',
              borderRadius: 8,
              fontSize: 16,
              marginTop: 8,
              cursor: 'pointer',
              opacity: 0.85,
              transition: 'background 0.15s, border 0.2s',
            }}
            onMouseOver={e => e.currentTarget.style.background = theme === 'dark' ? '#b3aca41a' : '#003f6911'}
            onMouseOut={e => e.currentTarget.style.background = 'none'}
          >
            Voltar
          </button>
        </div>
      </div>
    </div>
  );
}

function App() {
  const [user, setUser] = useState(null);
  const [screen, setScreen] = useState('dashboard');
  const [roomId, setRoomId] = useState(null); // Mantém o estado da sala online
  const [jokenpoPlaying, setJokenpoPlaying] = useState(false); // NOVO: controla se está jogando Jokenpo

  // Checa usuário logado ao carregar o app
  useEffect(() => {
    // Para supabase-js v2
    if (supabase.auth.getSession) {
      supabase.auth.getSession().then(({ data: { session } }) => {
        if (session && session.user) {
          setUser(session.user);
          setScreen('dashboard');
        }
      });
    } else if (supabase.auth.session) { // Para supabase-js v1
      const session = supabase.auth.session();
      if (session && session.user) {
        setUser(session.user);
        setScreen('dashboard');
      }
    }
  }, []);

  function handleLogout() {
    setUser(null);
    setScreen('dashboard');
    setRoomId(null);
    supabase.auth.signOut();
  }

  function handleUpdateName(newName) {
    // Atualiza o nome no Supabase e no estado local
    if (user) {
      supabase.auth.updateUser({ data: { name: newName } });
      setUser({ ...user, user_metadata: { ...user.user_metadata, name: newName } });
      // Atualiza o nome na sala online, se estiver em uma
      if (roomId) {
        // Descobre se é player1 ou player2
        supabase.from('rooms').select('player1,player2').eq('id', roomId).maybeSingle().then(({ data }) => {
          if (!data) return;
          if (data.player1 === user.id) {
            supabase.from('rooms').update({ player1_name: newName }).eq('id', roomId);
          } else if (data.player2 === user.id) {
            supabase.from('rooms').update({ player2_name: newName }).eq('id', roomId);
          }
        });
      }
    }
  }

  if (!user) {
    return <Auth onAuth={setUser} />;
  }

  // Renderiza o Header em todas as telas, exceto login/cadastro
  return (
    <div>
      <Header user={user} onLogout={handleLogout} onUpdateName={handleUpdateName} />
      {screen === 'dashboard' && (
        <Dashboard user={user} onSelectGame={setScreen} onLogout={handleLogout} />
      )}
      {screen === 'minesweeper-mode' && (
        <MinesweeperModeSelect onSelectMode={setScreen} onBack={() => setScreen('dashboard')} />
      )}
      {screen === 'minesweeper-solo' && (
        <Suspense fallback={<div>Carregando...</div>}>
          <div>
            <button onClick={() => setScreen('minesweeper-mode')} style={{ margin: 16 }}>Voltar</button>
            <Minesweeper />
          </div>
        </Suspense>
      )}
      {screen === 'memory-mode' && (
        <Suspense fallback={<div>Carregando...</div>}>
          <MemoryModeSelect onSelectMode={setScreen} onBack={() => setScreen('dashboard')} />
        </Suspense>
      )}
      {screen === 'memory-local' && (
        <Suspense fallback={<div>Carregando...</div>}>
          <div>
            <button onClick={() => setScreen('memory-mode')} style={{ margin: 16 }}>Voltar</button>
            <MemoryGame />
          </div>
        </Suspense>
      )}
      {screen === 'memory-online' && (
        !roomId ? (
          <Suspense fallback={<div>Carregando...</div>}>
            <div>
              <button onClick={() => setScreen('memory-mode')} style={{ margin: 16 }}>Voltar</button>
              <MemoryRoomList user={user} onJoinRoom={setRoomId} />
            </div>
          </Suspense>
        ) : (
          <Suspense fallback={<div>Carregando...</div>}>
            <MemoryOnlineGame user={user} roomId={roomId} onLeave={() => { setRoomId(null); setScreen('memory-online'); }} />
          </Suspense>
        )
      )}
      {screen === 'hangman' && (
        <Suspense fallback={<div>Carregando...</div>}>
          <HangmanGamePage onBack={() => setScreen('dashboard')} />
        </Suspense>
      )}
      {screen === 'tic-tac-toe' && (
        <Suspense fallback={<div>Carregando...</div>}>
          <TicTacToeModeSelect onSelectMode={setScreen} onBack={() => setScreen('dashboard')} />
        </Suspense>
      )}
      {screen === 'tic-tac-toe-local' && (
        <Suspense fallback={<div>Carregando...</div>}>
          <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #23283a 60%, #7dd3fc 100%)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ width: '100%', maxWidth: 500, margin: '0 auto', padding: '32px 0' }}>
              <button onClick={() => setScreen('tic-tac-toe')} style={{ marginBottom: 24, background: 'linear-gradient(90deg,#e11d48 60%,#f472b6 100%)', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 28px', fontWeight: 700, fontSize: '1.08rem', cursor: 'pointer', boxShadow: '0 2px 8px #e11d4844', transition: 'background 0.2s' }}>Voltar</button>
              <TicTacToeGame />
            </div>
          </div>
        </Suspense>
      )}
      {screen === 'tic-tac-toe-online' && (
        !roomId ? (
          <Suspense fallback={<div>Carregando...</div>}>
            <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #23283a 60%, #7dd3fc 100%)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
              <div style={{ width: '100%', maxWidth: 500, margin: '0 auto', padding: '32px 0' }}>
                <button onClick={() => setScreen('tic-tac-toe')} style={{ marginBottom: 24, background: 'linear-gradient(90deg,#e11d48 60%,#f472b6 100%)', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 28px', fontWeight: 700, fontSize: '1.08rem', cursor: 'pointer', boxShadow: '0 2px 8px #e11d4844', transition: 'background 0.2s' }}>Voltar</button>
                <TicTacToeRoomListV2 user={user} onJoinRoom={setRoomId} />
              </div>
            </div>
          </Suspense>
        ) : (
          <Suspense fallback={<div>Carregando...</div>}>
            <TicTacToeOnlineGame user={user} roomId={roomId} onLeave={() => { setRoomId(null); setScreen('tic-tac-toe-online'); }} />
          </Suspense>
        )
      )}
      {screen === 'minesweeper-online' && (
        !roomId ? (
          <Suspense fallback={<div>Carregando...</div>}>
            <div>
              <button onClick={() => setScreen('minesweeper-mode')} style={{ margin: 16 }}>Voltar</button>
              <RoomList user={user} onJoinRoom={setRoomId} />
            </div>
          </Suspense>
        ) : (
          <Suspense fallback={<div>Carregando...</div>}>
            <OnlineGame user={user} roomId={roomId} onLeave={() => setRoomId(null)} />
          </Suspense>
        )
      )}
      {screen === 'jokenpo-mode' && (
        <Suspense fallback={<div>Carregando...</div>}>
          <JokenpoModeSelect onSelectMode={setScreen} onBack={() => setScreen('dashboard')} />
        </Suspense>
      )}
      {screen === 'jokenpo-local' && (
        <Suspense fallback={<div>Carregando...</div>}>
          <div>
            <button onClick={() => setScreen('jokenpo-mode')} style={{ margin: 16 }}>Voltar</button>
            <JokenpoLocal />
          </div>
        </Suspense>
      )}
      {screen === 'jokenpo-online' && (
        !roomId ? (
          <Suspense fallback={<div>Carregando...</div>}>
            <div>
              <button onClick={() => setScreen('jokenpo-mode')} style={{ margin: 16 }}>Voltar</button>
              <JokenpoRoomList user={user} onJoinRoom={setRoomId} onBack={() => setScreen('jokenpo-mode')} />
            </div>
          </Suspense>
        ) : !jokenpoPlaying ? (
          <Suspense fallback={<div>Carregando...</div>}>
            <JokenpoRoom
              user={user}
              roomId={roomId}
              onLeave={() => { setRoomId(null); setScreen('jokenpo-online'); setJokenpoPlaying(false); }}
              onStart={() => setJokenpoPlaying(true)}
            />
          </Suspense>
        ) : (
          <Suspense fallback={<div>Carregando...</div>}>
            <JokenpoOnline
              user={user}
              roomId={roomId}
              onLeave={() => { setRoomId(null); setScreen('jokenpo-online'); setJokenpoPlaying(false); }}
            />
          </Suspense>
        )
      )}
    </div>
  );
}

export default App;