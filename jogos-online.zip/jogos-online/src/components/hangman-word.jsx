import styled from "styled-components";

const Wrapper = styled.div`
  display: flex;
  justify-content: center;
  gap: 0.5rem;
  font-size: 4rem;
  text-transform: uppercase;
  color: #fff;
  font-weight: bold;
  font-family: sans-serif;
  @media (max-width: 768px) {
    font-size: 3rem;
    gap: 0.3rem;
  }
  @media (max-width: 480px) {
    font-size: 2rem;
    gap: 0.2rem;
  }
`;

export default function HangmanWord({ word, guessedLetters }) {
  return (
    <Wrapper>
      {word.split('').map((letter, index) => (
        <span
          style={{
            borderBottom: '0.1em solid white',
            height: '80px',
            minWidth: '40px',
            display: 'inline-block'
          }}
          key={index}
        >
          <span
            style={{
              visibility: guessedLetters.includes(letter) ? 'visible' : 'hidden'
            }}
          >
            {letter}
          </span>
        </span>
      ))}
    </Wrapper>
  );
}
