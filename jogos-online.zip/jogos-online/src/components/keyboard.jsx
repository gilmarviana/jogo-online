import styled from "styled-components";

const Keys = [
  'A', 'B', 'C', 'D', 'E', 'F', 'G',
  'H', 'I', 'J', 'K', 'L', 'M',
  'N', 'O', 'P', 'Q', 'R', 'S',
  'T', 'U', 'V', 'W', 'X', 'Y',
  'Z'
];

const Wrapper = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(60px, 1fr));
  gap: 0.5rem;
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
  @media (max-width: 900px) {
    max-width: 100vw;
    grid-template-columns: repeat(auto-fit, minmax(48px, 1fr));
    gap: 0.4rem;
  }
  @media (max-width: 380px) {
    grid-template-columns: repeat(6, 1fr);
    gap: 0.22rem;
    padding: 0 0vw;
  }
  @media (max-width: 400px) {
    grid-template-columns: repeat(5, 1fr);
    gap: 0.12rem;
    padding: 0 1vw;
  }
`;

const Button = styled.button`
  width: 100%;
  border: 3px solid white;
  background: none;
  aspect-ratio: 1 / 1;
  font-size: 2.5rem;
  text-transform: uppercase;
  padding: .5rem;
  font-weight: bold;
  cursor: pointer;
  color: white;
  transition: background 0.2s, border 0.2s, font-size 0.2s, padding 0.2s;
  opacity: ${props => props.isActive ? 1 : 0.3};
  background-color: ${props => props.isCorrect ? '#28a745' : props.isIncorrect ? '#dc3545' : 'none'};
  border-color: ${props => props.isCorrect ? '#28a745' : props.isIncorrect ? '#dc3545' : 'white'};
  &:hover:not(:disabled),
  &:focus:not(:disabled) {
    background-color: #555;
    border-color: #555;
  }
  &:disabled {
    cursor: not-allowed;
  }
  @media (max-width: 900px) {
    font-size: 2rem;
    padding: .3rem;
    border-width: 2.5px;
  }
  @media (max-width: 600px) {
    font-size: 1.2rem;
    padding: .15rem;
    border-width: 2px;
  }
  @media (max-width: 400px) {
    font-size: 0.9rem;
    padding: .08rem;
    border-width: 1.5px;
  }
`;

export default function Keyboard({
  activeLetters,
  inactiveLetters,
  addGuessedLetters,
  wordToGuess,
  guessedLetters,
  disabled = false,
}) {
  return (
    <Wrapper>
      {Keys.map((letter) => {
        const isCorrect = wordToGuess.includes(letter) && guessedLetters.includes(letter);
        const isIncorrect = !wordToGuess.includes(letter) && guessedLetters.includes(letter);
        const isDisabledButton = guessedLetters.includes(letter) || disabled;
        return (
          <Button
            onClick={() => addGuessedLetters(letter)}
            isCorrect={isCorrect}
            isIncorrect={isIncorrect}
            isActive={!isDisabledButton}
            disabled={isDisabledButton}
            key={letter}
          >
            {letter}
          </Button>
        );
      })}
    </Wrapper>
  );
}
