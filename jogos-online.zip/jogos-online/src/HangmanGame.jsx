import React, { useCallback, useEffect, useState } from 'react';
import styled from 'styled-components';
import HangmanDrawing from './components/hangman-drawing';
import HangmanWord from './components/hangman-word';
import Keyboard from './components/keyboard';

const HangmanPart = styled.div`
  display: flex;
  gap: 1.5rem;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 100%;
  padding: 2rem 1rem 1rem 1rem;
  box-sizing: border-box;
  @media (max-width: 900px) {
    gap: 1rem;
    padding: 1.2rem 0.5rem 0.5rem 0.5rem;
  }
  @media (max-width: 600px) {
    gap: 0.6rem;
    padding: 0.7rem 0.2rem 0.2rem 0.2rem;
  }
  @media (max-width: 400px) {
    gap: 0.5rem;
    padding: 0.2rem;
  }
`;

const Wrapper = styled.div`
  display: flex;
  gap: 3em;
  flex-direction: column;
  align-items: center;
  width: 90vw;
  max-width: 900px;
  margin: 0 auto;
  padding: 2rem 0 1rem 0;
  box-sizing: border-box;
  background: rgba(35, 40, 58, 0.97); /* fundo escuro suave para toda a forca */
  border-radius: 18px;
  box-shadow: 0 4px 32px #000a;
  @media (max-width: 900px) {
    gap: 2em;
    width: 98vw;
    max-width: 100vw;
    padding: 1rem 0 0.5rem 0;
  }
  @media (max-width: 400px) {
    gap: 0.2em;
    width: 100vw;
    max-width: 100vw;
    padding: 0.5rem 0 0.2rem 0;
  }
`;

const categories = {
  'Livros Bíblicos': [
    'GENESIS', 'EXODOS', 'LEVITICO', 'NUMEROS', 'DEUTERONOMIO',
    'JOSUE', 'JUIZES', 'RUTE', 'SAMUEL',
    'REIS', 'CRONICAS', 'ESDRAS',
    'NEEMIAS', 'ESTER', 'JOVEM', 'SALMOS', 'PROVÉRBIOS',
    'ECLESIASTES', 'CANTARES', 'ISAIAS',
    'JEREMIAS', 'LAMENTACOES', 'EZEQUIEL', 'DANIEL', 'OSEIAS',
    'JOEL', 'AMOS', 'OBADIAS', 'JONAS',
    'MIQUEIAS', 'NAUM', 'HABACUQUE', 'SOFONIAS', 'AGEU',
    'ZACARIAS', 'MALAQUIAS', 'MATEUS', 'MARCO', 'LUCAS',
    'JOAO', 'ATOS', 'ROMANOS', 'CORINTIOS',
    'GALATAS', 'EFESIOS', 'FILIPENSES',
    'COLOSSENSES', 'TESSALONICENSES', 'TIMOTEO',
    'TITO', 'FILEMON', 'HEBREUS', 'TIAGO', 'PEDRO', 'JOAO', 'JUDAS',
    'APOCALIPSE'
  ],
  'Frutas': ['BANANA', 'MACA', 'UVA', 'LARANJA', 'ABACAXI', 'MELANCIA', 'MORANGO', 'PESSEGO', 'KIWI', 'LIMA', 'LIMAO', 'COCO', 'MANGA', 'PAPAYA', 'TANGERINA', 'CABELUCA'],
  'Animais': ['CACHORRO', 'GATO', 'ELEFANTE', 'LEAO', 'TIGRE', 'URSO', 'PANDA', 'ZEBRA', 'CAVALO', 'CANGURU', 'GIRAFA', 'HIPOPOTAMO', 'RINOCERONTE', 'COELHO', 'LAGARTO', 'TARTARUGA'],
  'Cores': ['VERMELHO', 'AZUL', 'VERDE', 'AMARELO', 'ROXO', 'LARANJA', 'PRETO', 'BRANCO', 'CINZA', 'MARROM', 'BEGE', 'PINK', 'VIOLETA', 'TURQUESA', 'MAGENTA', 'CINZENTO'],
  'Países': ['BRASIL', 'ARGENTINA', 'CHILE', 'CANADA', 'ESTADOS UNIDOS', 'ALEMANHA', 'FRANCA', 'INGLATERRA', 'ESPANHA', 'ITALIA', 'JAPAO', 'CHINA', 'RUSSIA', 'AUSTRALIA', 'INDIA', 'MEXICO'],
  'Linguagens de Programação': ['JAVASCRIPT', 'PYTHON', 'JAVA', 'CPLUSPLUS', 'C', 'RUBY', 'PHP', 'SWIFT', 'KOTLIN', 'GO', 'TYPESCRIPT', 'HTML', 'CSS', 'SQL', 'RUST', 'DART']
};

export default function HangmanGame() {
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [wordToGuess, setWordToGuess] = useState(null);
  const [guessedLetters, setGuessedLetters] = useState([]);
  // Detecta o tema atual
  const [theme, setTheme] = useState(() => {
    if (typeof window !== 'undefined') {
      return document.body.classList.contains('theme-white') ? 'white' : 'dark';
    }
    return 'dark';
  });
  useEffect(() => {
    const observer = new MutationObserver(() => {
      setTheme(document.body.classList.contains('theme-white') ? 'white' : 'dark');
    });
    observer.observe(document.body, { attributes: true, attributeFilter: ['class'] });
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (selectedCategory) {
      const wordsList = categories[selectedCategory];
      setWordToGuess(wordsList[Math.floor(Math.random() * wordsList.length)]);
    }
  }, [selectedCategory]);

  const incorrectGuesses = guessedLetters.filter(
    (letter) => wordToGuess && !wordToGuess.includes(letter)
  );
  const correctGuesses = guessedLetters.filter(
    (letter) => wordToGuess && wordToGuess.includes(letter)
  );
  const isLoser = wordToGuess ? incorrectGuesses.length >= 7 : false;
  const isWinner = wordToGuess ? wordToGuess.split('').every((letter) => guessedLetters.includes(letter)) : false;

  const addGuessedLetters = useCallback((letter) => {
    if (guessedLetters.includes(letter) || isLoser || isWinner) return;
    setGuessedLetters((currentLetters) => [...currentLetters, letter]);
  }, [guessedLetters, isLoser, isWinner]);

  useEffect(() => {
    if (!wordToGuess) return;
    const handler = (e) => {
      const key = e.key.toUpperCase();
      if (!key.match(/^[A-Z]$/) || guessedLetters.includes(key) || isLoser || isWinner) return;
      e.preventDefault();
      addGuessedLetters(key);
    };
    document.addEventListener('keypress', handler);
    return () => {
      document.removeEventListener('keypress', handler);
    };
  }, [guessedLetters, addGuessedLetters, isLoser, isWinner, wordToGuess]);

  if (!selectedCategory) {
    return (
      <Wrapper>
        <HangmanPart>
          <h1 style={{ color: theme === 'white' ? '#222' : 'var(--color5)', fontSize: '2rem', textAlign: 'center' }}>Selecione uma categoria</h1>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', width: '100%', maxWidth: 400 }}>
            {Object.keys(categories).map((cat) => (
              <button
                key={cat}
                style={{
                  padding: '1rem',
                  fontSize: '1.2rem',
                  borderRadius: 8,
                  border: `2px solid var(--color3)`,
                  cursor: 'pointer',
                  background: 'var(--color2)',
                  color: theme === 'white' ? '#222' : 'var(--color5)',
                  fontWeight: 700,
                  boxShadow: '0 2px 8px var(--color3)11',
                  transition: 'transform 0.13s, box-shadow 0.13s',
                }}
                onMouseOver={e => {
                  e.currentTarget.style.transform = 'scale(1.04)';
                  e.currentTarget.style.boxShadow = '0 4px 16px var(--color3)22';
                }}
                onMouseOut={e => {
                  e.currentTarget.style.transform = 'none';
                  e.currentTarget.style.boxShadow = '0 2px 8px var(--color3)11';
                }}
                onClick={() => setSelectedCategory(cat)}
              >
                {cat}
              </button>
            ))}
          </div>
        </HangmanPart>
      </Wrapper>
    );
  }

  if (!wordToGuess) return null;

  return (
    <Wrapper>
      <HangmanPart>
        <div style={{ display: 'flex', gap: '1rem', justifyContent: 'flex-start', width: '100%', maxWidth: 500, margin: '0 auto 1rem auto' }}>
          <button
            style={{
              padding: '0.5rem 1.2rem',
              fontSize: '1rem',
              borderRadius: 8,
              border: `2px solid var(--color4)`,
              cursor: 'pointer',
              background: 'var(--color3)',
              color: theme === 'white' ? '#222' : 'var(--color5)',
              fontWeight: 700,
              boxShadow: '0 2px 8px var(--color3)11',
              transition: 'transform 0.13s, box-shadow 0.13s',
            }}
            onMouseOver={e => {
              e.currentTarget.style.transform = 'scale(1.04)';
              e.currentTarget.style.boxShadow = '0 4px 16px var(--color3)22';
            }}
            onMouseOut={e => {
              e.currentTarget.style.transform = 'none';
              e.currentTarget.style.boxShadow = '0 2px 8px var(--color3)11';
            }}
            onClick={() => {
              if (selectedCategory) {
                const wordsList = categories[selectedCategory];
                setGuessedLetters([]);
                setWordToGuess(wordsList[Math.floor(Math.random() * wordsList.length)]);
              }
            }}
          >
            Repetir
          </button>
          <button
            style={{
              padding: '0.5rem 1.2rem',
              fontSize: '1rem',
              borderRadius: 8,
              border: `2px solid var(--color3)`,
              cursor: 'pointer',
              background: 'var(--color2)',
              color: theme === 'white' ? '#222' : 'var(--color5)',
              fontWeight: 700,
              boxShadow: '0 2px 8px var(--color3)11',
              transition: 'transform 0.13s, box-shadow 0.13s',
            }}
            onMouseOver={e => {
              e.currentTarget.style.transform = 'scale(1.04)';
              e.currentTarget.style.boxShadow = '0 4px 16px var(--color3)22';
            }}
            onMouseOut={e => {
              e.currentTarget.style.transform = 'none';
              e.currentTarget.style.boxShadow = '0 2px 8px var(--color3)11';
            }}
            onClick={() => {
              setSelectedCategory(null);
              setGuessedLetters([]);
              setWordToGuess(null);
            }}
          >
            Voltar ao menu
          </button>
        </div>
        {isLoser && <div style={{ color: theme === 'white' ? '#b30000' : 'var(--color4)', fontSize: '2rem', textAlign: 'center', wordBreak: 'break-word', maxWidth: '100%', fontWeight: 700 }}>Você perdeu!</div>}
        {isWinner && <div style={{ color: theme === 'white' ? '#106b87' : 'var(--color3)', fontSize: '2rem', textAlign: 'center', wordBreak: 'break-word', maxWidth: '100%', fontWeight: 700 }}>Você ganhou!</div>}
        <h1 style={{ color: '#fff', fontSize: '2rem', textAlign: 'center', wordBreak: 'break-word', margin: 0, maxWidth: '100%' }}>
          {isLoser ? 'A palavra era: ' + wordToGuess : isWinner ? 'Você adivinhou a palavra!' : 'Adivinhe a palavra!'}
        </h1>
        <h2 style={{ color: '#fff', fontSize: '1.3rem', textAlign: 'center', wordBreak: 'break-word', margin: 0, maxWidth: '100%' }}>
          {isLoser ? 'Tente novamente!' : isWinner ? 'Parabéns!' : 'Quantas letras você consegue adivinhar?'}
        </h2>
        <div style={{ width: '100%', maxWidth: 400, minHeight: 180, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          <HangmanDrawing numberOfGuesses={incorrectGuesses.length} />
        </div>
        <div style={{ width: '100%', maxWidth: 400 }}>
          <HangmanWord guessedLetters={guessedLetters} word={wordToGuess} textColor={theme === 'white' ? '#222' : undefined} />
        </div>
      </HangmanPart>
      <div style={{ alignSelf: 'stretch', width: '100%', maxWidth: 500, margin: '0 auto' }}>
        <Keyboard
          activeLetters={correctGuesses}
          inactiveLetters={incorrectGuesses}
          addGuessedLetters={addGuessedLetters}
          wordToGuess={wordToGuess}
          guessedLetters={guessedLetters}
          disabled={isWinner || isLoser}
          textColor={theme === 'white' ? '#222' : undefined}
        />
      </div>
    </Wrapper>
  );
}
